﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AddressBookDTO.AddressDTO;
using AddressBookDSL.AddressDL;
using System.Data;
using AddressBookDSL.Helper;

namespace AddressBookBLL.AddressBL
{
	public class AddressBLL
	{
		public static int AddressBookInsert(AddressBook objAddressBook)
		{
			int output = 0;
			try
			{
				output = AddressDSL.AddressBookInsert(objAddressBook);
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine(" Error : AddressBLL : AddressBookInsert() " + ex.Message.ToString());
			}
			return output;
		}
		public static int AddressBookEdit(AddressBook objAddressBook)
		{
			int output = 0;
			try
			{
				output = AddressDSL.AddressBookEdit(objAddressBook);
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine(" Error : AddressBLL : AddressBookEdit() " + ex.Message.ToString());
			}
			return output;
		}
		public static int AddressBookDelete(string contactId)
		{
			int output = 0;
			try
			{
				output = AddressDSL.AddressBookDelete(contactId);
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine(" Error : AddressBLL : AddressBookDelete() " + ex.Message.ToString());
			}
			return output;
		}
		public static DataSet GetAddressBook()
		{
			DataSet dsAddressBook = null ;
			try
			{
				dsAddressBook = AddressDSL.GetAddressBook();
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine(" Error : AddressBLL : GetAddressBook() " + ex.Message.ToString());
			}
			return dsAddressBook;
		}
		public static DataSet GetAddressBookLike(string contactId,string like)
		{
			DataSet dsAddressBook = null;
			try
			{
				dsAddressBook = AddressDSL.GetAddressBookLike(contactId,like);
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine(" Error : AddressBLL : GetAddressBookLike() " + ex.Message.ToString());
			}
			return dsAddressBook;
		}
		public static DataSet GetAddressBookIds()
		{
			DataSet dsAddressBooks = null;
			try
			{
				dsAddressBooks = AddressDSL.GetAddressBook();
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine(" Error : AddressBLL : GetAddressBookIds() " + ex.Message.ToString());
			}
			return dsAddressBooks;
		}
		public static AddressBook GetAddressBookByIds(string contactId)
		{
			AddressBook objAddressBook = null;
			try
			{
				objAddressBook = AddressDSL.GetAddressBookByIds(contactId);
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine(" Error : AddressBLL : GetAddressBookIds() " + ex.Message.ToString());
			}
			return objAddressBook;
		}
		public static string GetNewContactId()
		{

			string lastContactId = null;
			string newContactId = null;
			try
			{
				lastContactId = AddressDSL.GetLastContactId();
				if (lastContactId != null)
				{
					newContactId = UtilityHelper.GenerateId(lastContactId);
				}
				else
				{
					newContactId = "ADB101";
				}
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine("Error : AddressBLL : GetNewContactId() " + ex.Message.ToString());
			}
			return newContactId;
		}
	}
}
