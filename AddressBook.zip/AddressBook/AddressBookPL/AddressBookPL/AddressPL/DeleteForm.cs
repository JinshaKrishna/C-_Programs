﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AddressBookDTO.AddressDTO;
using AddressBookBLL.AddressBL;

namespace AddressBookPL.AddressPL
{
	public partial class DeleteForm : Form
	{
		public DeleteForm()
		{
			InitializeComponent();
		}

		private void buttonBack_Click(object sender, EventArgs e)
		{
			this.Visible = false;
			AddressBookPLayer s = new AddressBookPLayer();
			s.Visible = true;
		}
		private void LoadAddressBookIds()
		{
			DataSet dsAddressBookIds = null;
			try
			{
				dsAddressBookIds = AddressBLL.GetAddressBookIds();
				if (dsAddressBookIds != null)
				{
					comboBoxId.DataSource = dsAddressBookIds.Tables[0];
					comboBoxId.ValueMember = "contactId";
					comboBoxId.DisplayMember = "contactId";
				}
				else
				{
					labelDeleteMessage.Text = "No Details Available in Address Book";
				}
			}
			catch(Exception ex)
			{
				Console.Out.WriteLine(ex.Message.ToString());
			}
		}

		private void buttonEdit_Click(object sender, EventArgs e)
		{
			if (comboBoxId.Text == string.Empty)
			{
				labelDeleteMessage.Text = "Please select a Contact Id for delete.";
			}
			else
			{
				int output = 0;
				try
				{
					if (MessageBox.Show("Do you want to Delete", "S I S", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
					{
						output = AddressBLL.AddressBookDelete(comboBoxId.Text);
						if (output > 0)
						{
							labelDeleteMessage.Text = "DATA DELETED SUCCESSULLY";
							LoadAddressBookIds();
						}
						else
						{
							labelDeleteMessage.Text = "TRY AGAIN LATER";
						}
					}
				}
				catch (Exception ex)
				{
					Console.Out.WriteLine(ex.Message.ToString());
				}
			}
		}

		private void DeleteForm_Load(object sender, EventArgs e)
		{
			LoadAddressBookIds();
		}
	}
}
