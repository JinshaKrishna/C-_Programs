﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AddressBookDTO.AddressDTO;
using AddressBookBLL.AddressBL;

namespace AddressBookPL.AddressPL
{
	public partial class ViewForm : Form
	{
		public ViewForm()
		{
			InitializeComponent();
		}

		private void panelView_Paint(object sender, PaintEventArgs e)
		{

		}

		private void ViewForm_Load(object sender, EventArgs e)
		{
			LoadAddressBook();
		}
		private void LoadAddressBook()
		{
			DataSet dsAddressBook = null;
			try
			{
				dsAddressBook = AddressBLL.GetAddressBook();
				if (dsAddressBook != null)
				{
					dataGridViewAddressBook.DataSource = dsAddressBook.Tables[0];
				}
				else
				{
					labelViewMessage.Text = "No Details Available in Address Book";
				}
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine(ex.Message.ToString());
			}
		}

		private void buttonBack_Click(object sender, EventArgs e)
		{
			this.Visible = false;
			AddressBookPLayer s = new AddressBookPLayer();
			s.Visible = true;
		}
	}
}
