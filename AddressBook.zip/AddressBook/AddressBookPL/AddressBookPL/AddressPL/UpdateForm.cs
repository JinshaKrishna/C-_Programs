﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AddressBookBLL.AddressBL;
using AddressBookDTO.AddressDTO;

namespace AddressBookPL.AddressPL
{
	public partial class UpdateForm : Form
	{
		public UpdateForm()
		{
			InitializeComponent();
		}

		private void buttonEdit_Click(object sender, EventArgs e)
		{
			LoadAddressBook();
			if (comboBoxId.Text == string.Empty && textBoxNameEdit.Text == string.Empty && textBoxEmailEdit.Text == string.Empty && textBoxMobileEdit.Text == "" && comboBoxState.Text == string.Empty && textBoxAddressEdit.Text == string.Empty)
			{
				labelUpdateMessage.Text = "All data are mandatory. Please provide it.";
			}
			else if (comboBoxId.Text == string.Empty)
			{
				labelUpdateMessage.Text = "Please Enter Contact Id.";
			}
			else if (textBoxNameEdit.Text == string.Empty)
			{
				labelUpdateMessage.Text = "Please Enter Contact Name.";
			}
			else if (dateTimePickerDOBEdit.Text == string.Empty)
			{
				labelUpdateMessage.Text = "Please Enter Date Of Birth.";
			}
			else if (textBoxEmailEdit.Text == string.Empty)
			{
				labelUpdateMessage.Text = "Please Enter Email Id.";
			}
			else if (textBoxMobileEdit.Text == string.Empty)
			{
				labelUpdateMessage.Text = "Please Enter Mobile No.";
			}
			else if (comboBoxState.Text == string.Empty)
			{
				labelUpdateMessage.Text = "Please Select one from States.";
			}
			else if (textBoxAddressEdit.Text == string.Empty)
			{
				labelUpdateMessage.Text = "Please Enter Contact Address.";
			}
			else if (!radioButtonFemaleEdit.Checked && !radioButtonMaleEdit.Checked)
			{
				labelUpdateMessage.Text = "Please check one from Gender.";
			}
			else if (!textBoxEmailEdit.Text.Contains("@"))
			{
				labelUpdateMessage.Text = "Please Enter a valid Email Id.";
			}
			else
			{
				AddressBook objAddressBook = null;
				int output = 0;
				try
				{
					objAddressBook = new AddressBook();
					objAddressBook.ContactId = comboBoxId.Text;
					objAddressBook.ContactName = textBoxNameEdit.Text;
					objAddressBook.DOB = dateTimePickerDOBEdit.Value.ToString("yyyy-mm-dd");
					objAddressBook.Email = textBoxEmailEdit.Text;
					objAddressBook.MobileNo = Convert.ToInt32(textBoxMobileEdit.Text);
					objAddressBook.State = comboBoxState.Text;
					if (radioButtonFemaleEdit.Checked)
					{
						objAddressBook.Gender = radioButtonFemaleEdit.Text;
					}
					else
					{
						objAddressBook.Gender = radioButtonMaleEdit.Text;
					}
					objAddressBook.Address = textBoxAddressEdit.Text;

					output = AddressBLL.AddressBookEdit(objAddressBook);

					if (output > 0)
					{
						labelUpdateMessage.Text = "DATA EDITED SUCCESSFULLY";
					}
					else
					{
						labelUpdateMessage.Text = "EDITING FAILED";
					}
				}
				catch (Exception ex)
				{
					labelUpdateMessage.Text = ex.Message.ToString();
				}
			}
		}

		private void buttonBack_Click(object sender, EventArgs e)
		{
			this.Visible = false;
			AddressBookPLayer s = new AddressBookPLayer();
			s.Visible = true;
		}
		private void LoadAddressBookIds()
		{
			DataSet dsAddressBookIds = null;
			try
			{
				dsAddressBookIds = AddressBLL.GetAddressBookIds();
				if (dsAddressBookIds != null)
				{
					comboBoxId.DataSource = dsAddressBookIds.Tables[0];
					comboBoxId.ValueMember = "contactId";
					comboBoxId.DisplayMember = "contactId";
				}
				else
				{
					labelUpdateMessage.Text = "No Details Available in Address Book";
				}
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine(ex.Message.ToString());
			}
		}
		private void UpdateForm_Load(object sender, EventArgs e)
		{
			comboBoxState.Items.Add("KERALA");
			comboBoxState.Items.Add("TAMIL NADU");
			comboBoxState.Items.Add("KARNATAKA");
			comboBoxState.Items.Add("ANDHRA PRADESH");
			comboBoxState.Items.Add("GUJARATH");
			comboBoxState.Items.Add("ARUNACHAL PRADESH");
			LoadAddressBookIds();
			LoadAddressBook();
		}

		private void comboBoxId_SelectedIndexChanged(object sender, EventArgs e)
		{
			AddressBook objAddressBook = null;
			try
			{
				objAddressBook = AddressBLL.GetAddressBookByIds(comboBoxId.Text);

				if (objAddressBook != null)
				{
					textBoxNameEdit.Text = objAddressBook.ContactName;
					textBoxEmailEdit.Text = objAddressBook.Email;
					textBoxMobileEdit.Text = objAddressBook.MobileNo.ToString();
					comboBoxState.Text = objAddressBook.State;
					if (objAddressBook.Gender == "Female")
					{
						radioButtonFemaleEdit.Checked = true;
					}
					else
					{
						radioButtonMaleEdit.Checked = true;
					}
					textBoxAddressEdit.Text = objAddressBook.Address;
				}
			}
			catch(Exception ex)
			{
				labelUpdateMessage.Text = ex.Message.ToString();
			}
		}
		private void LoadAddressBook()
		{
			DataSet dsAddressBook = null;
			try
			{
				dsAddressBook = AddressBLL.GetAddressBook();
				if (dsAddressBook != null)
				{
					dataGridViewAddressBook.DataSource = dsAddressBook.Tables[0];
				}
				else
				{
					labelUpdateMessage.Text = "No Details Available in Address Book";
				}
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine(ex.Message.ToString());
			}
		}
		private void dataGridViewAddressBook_SelectionChanged(object sender, EventArgs e)
		{
			string contactId, contactName, dob, email, mobileNo, state, gender, addres;
			if (dataGridViewAddressBook.SelectedCells.Count > 0)
			{
				int selectedRowIndex = dataGridViewAddressBook.SelectedCells[0].RowIndex;
				DataGridViewRow selectedRow = dataGridViewAddressBook.Rows[selectedRowIndex];

				contactId = Convert.ToString(selectedRow.Cells["contactId"].Value);
				contactName = Convert.ToString(selectedRow.Cells["contactName"].Value);
				dob = Convert.ToString(selectedRow.Cells["dob"].Value);
				email = Convert.ToString(selectedRow.Cells["email"].Value);
				mobileNo = Convert.ToString(selectedRow.Cells["mobileNo"].Value);
				state = Convert.ToString(selectedRow.Cells["state"].Value);
				gender = Convert.ToString(selectedRow.Cells["gender"].Value);
				addres = Convert.ToString(selectedRow.Cells["addres"].Value);

			}

		}
	}
}
