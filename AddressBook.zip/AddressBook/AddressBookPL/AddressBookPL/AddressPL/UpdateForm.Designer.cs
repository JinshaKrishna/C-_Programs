﻿namespace AddressBookPL.AddressPL
{
	partial class UpdateForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.panelUpdate = new System.Windows.Forms.Panel();
			this.comboBoxId = new System.Windows.Forms.ComboBox();
			this.buttonBack = new System.Windows.Forms.Button();
			this.labelUpdateMessage = new System.Windows.Forms.Label();
			this.buttonEdit = new System.Windows.Forms.Button();
			this.label11 = new System.Windows.Forms.Label();
			this.radioButtonMaleEdit = new System.Windows.Forms.RadioButton();
			this.radioButtonFemaleEdit = new System.Windows.Forms.RadioButton();
			this.dateTimePickerDOBEdit = new System.Windows.Forms.DateTimePicker();
			this.textBoxAddressEdit = new System.Windows.Forms.TextBox();
			this.textBoxMobileEdit = new System.Windows.Forms.TextBox();
			this.textBoxEmailEdit = new System.Windows.Forms.TextBox();
			this.textBoxNameEdit = new System.Windows.Forms.TextBox();
			this.label12 = new System.Windows.Forms.Label();
			this.label13 = new System.Windows.Forms.Label();
			this.label14 = new System.Windows.Forms.Label();
			this.label15 = new System.Windows.Forms.Label();
			this.label16 = new System.Windows.Forms.Label();
			this.label17 = new System.Windows.Forms.Label();
			this.label18 = new System.Windows.Forms.Label();
			this.label19 = new System.Windows.Forms.Label();
			this.comboBoxState = new System.Windows.Forms.ComboBox();
			this.dataGridViewAddressBook = new System.Windows.Forms.DataGridView();
			this.panelUpdate.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridViewAddressBook)).BeginInit();
			this.SuspendLayout();
			// 
			// panelUpdate
			// 
			this.panelUpdate.Controls.Add(this.comboBoxState);
			this.panelUpdate.Controls.Add(this.comboBoxId);
			this.panelUpdate.Controls.Add(this.buttonBack);
			this.panelUpdate.Controls.Add(this.labelUpdateMessage);
			this.panelUpdate.Controls.Add(this.buttonEdit);
			this.panelUpdate.Controls.Add(this.label11);
			this.panelUpdate.Controls.Add(this.radioButtonMaleEdit);
			this.panelUpdate.Controls.Add(this.radioButtonFemaleEdit);
			this.panelUpdate.Controls.Add(this.dateTimePickerDOBEdit);
			this.panelUpdate.Controls.Add(this.textBoxAddressEdit);
			this.panelUpdate.Controls.Add(this.textBoxMobileEdit);
			this.panelUpdate.Controls.Add(this.textBoxEmailEdit);
			this.panelUpdate.Controls.Add(this.textBoxNameEdit);
			this.panelUpdate.Controls.Add(this.label12);
			this.panelUpdate.Controls.Add(this.label13);
			this.panelUpdate.Controls.Add(this.label14);
			this.panelUpdate.Controls.Add(this.label15);
			this.panelUpdate.Controls.Add(this.label16);
			this.panelUpdate.Controls.Add(this.label17);
			this.panelUpdate.Controls.Add(this.label18);
			this.panelUpdate.Controls.Add(this.label19);
			this.panelUpdate.Location = new System.Drawing.Point(152, 12);
			this.panelUpdate.Name = "panelUpdate";
			this.panelUpdate.Size = new System.Drawing.Size(504, 520);
			this.panelUpdate.TabIndex = 32;
			// 
			// comboBoxId
			// 
			this.comboBoxId.FormattingEnabled = true;
			this.comboBoxId.Location = new System.Drawing.Point(232, 93);
			this.comboBoxId.Name = "comboBoxId";
			this.comboBoxId.Size = new System.Drawing.Size(226, 21);
			this.comboBoxId.TabIndex = 26;
			this.comboBoxId.SelectedIndexChanged += new System.EventHandler(this.comboBoxId_SelectedIndexChanged);
			// 
			// buttonBack
			// 
			this.buttonBack.BackColor = System.Drawing.Color.Black;
			this.buttonBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.buttonBack.ForeColor = System.Drawing.Color.White;
			this.buttonBack.Location = new System.Drawing.Point(205, 464);
			this.buttonBack.Name = "buttonBack";
			this.buttonBack.Size = new System.Drawing.Size(75, 43);
			this.buttonBack.TabIndex = 23;
			this.buttonBack.Text = "BACK";
			this.buttonBack.UseVisualStyleBackColor = false;
			this.buttonBack.Click += new System.EventHandler(this.buttonBack_Click);
			// 
			// labelUpdateMessage
			// 
			this.labelUpdateMessage.AutoSize = true;
			this.labelUpdateMessage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.labelUpdateMessage.Location = new System.Drawing.Point(184, 51);
			this.labelUpdateMessage.Name = "labelUpdateMessage";
			this.labelUpdateMessage.Size = new System.Drawing.Size(0, 13);
			this.labelUpdateMessage.TabIndex = 22;
			// 
			// buttonEdit
			// 
			this.buttonEdit.BackColor = System.Drawing.Color.Black;
			this.buttonEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.buttonEdit.ForeColor = System.Drawing.Color.White;
			this.buttonEdit.Location = new System.Drawing.Point(286, 464);
			this.buttonEdit.Name = "buttonEdit";
			this.buttonEdit.Size = new System.Drawing.Size(75, 43);
			this.buttonEdit.TabIndex = 21;
			this.buttonEdit.Text = "EDIT";
			this.buttonEdit.UseVisualStyleBackColor = false;
			this.buttonEdit.Click += new System.EventHandler(this.buttonEdit_Click);
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label11.ForeColor = System.Drawing.Color.Purple;
			this.label11.Location = new System.Drawing.Point(213, 13);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(88, 16);
			this.label11.TabIndex = 20;
			this.label11.Text = "EDIT DATA";
			// 
			// radioButtonMaleEdit
			// 
			this.radioButtonMaleEdit.AutoSize = true;
			this.radioButtonMaleEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.radioButtonMaleEdit.Location = new System.Drawing.Point(313, 362);
			this.radioButtonMaleEdit.Name = "radioButtonMaleEdit";
			this.radioButtonMaleEdit.Size = new System.Drawing.Size(48, 17);
			this.radioButtonMaleEdit.TabIndex = 19;
			this.radioButtonMaleEdit.TabStop = true;
			this.radioButtonMaleEdit.Text = "Male";
			this.radioButtonMaleEdit.UseVisualStyleBackColor = true;
			// 
			// radioButtonFemaleEdit
			// 
			this.radioButtonFemaleEdit.AutoSize = true;
			this.radioButtonFemaleEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.radioButtonFemaleEdit.Location = new System.Drawing.Point(232, 362);
			this.radioButtonFemaleEdit.Name = "radioButtonFemaleEdit";
			this.radioButtonFemaleEdit.Size = new System.Drawing.Size(59, 17);
			this.radioButtonFemaleEdit.TabIndex = 18;
			this.radioButtonFemaleEdit.TabStop = true;
			this.radioButtonFemaleEdit.Text = "Female";
			this.radioButtonFemaleEdit.UseVisualStyleBackColor = true;
			// 
			// dateTimePickerDOBEdit
			// 
			this.dateTimePickerDOBEdit.Location = new System.Drawing.Point(232, 181);
			this.dateTimePickerDOBEdit.MaxDate = new System.DateTime(9997, 10, 21, 0, 0, 0, 0);
			this.dateTimePickerDOBEdit.Name = "dateTimePickerDOBEdit";
			this.dateTimePickerDOBEdit.Size = new System.Drawing.Size(215, 20);
			this.dateTimePickerDOBEdit.TabIndex = 17;
			// 
			// textBoxAddressEdit
			// 
			this.textBoxAddressEdit.Location = new System.Drawing.Point(232, 402);
			this.textBoxAddressEdit.Multiline = true;
			this.textBoxAddressEdit.Name = "textBoxAddressEdit";
			this.textBoxAddressEdit.Size = new System.Drawing.Size(215, 56);
			this.textBoxAddressEdit.TabIndex = 15;
			// 
			// textBoxMobileEdit
			// 
			this.textBoxMobileEdit.Location = new System.Drawing.Point(232, 270);
			this.textBoxMobileEdit.Name = "textBoxMobileEdit";
			this.textBoxMobileEdit.Size = new System.Drawing.Size(215, 20);
			this.textBoxMobileEdit.TabIndex = 12;
			// 
			// textBoxEmailEdit
			// 
			this.textBoxEmailEdit.Location = new System.Drawing.Point(232, 226);
			this.textBoxEmailEdit.Name = "textBoxEmailEdit";
			this.textBoxEmailEdit.Size = new System.Drawing.Size(215, 20);
			this.textBoxEmailEdit.TabIndex = 11;
			// 
			// textBoxNameEdit
			// 
			this.textBoxNameEdit.Location = new System.Drawing.Point(232, 135);
			this.textBoxNameEdit.Name = "textBoxNameEdit";
			this.textBoxNameEdit.Size = new System.Drawing.Size(215, 20);
			this.textBoxNameEdit.TabIndex = 9;
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label12.Location = new System.Drawing.Point(23, 402);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(58, 15);
			this.label12.TabIndex = 7;
			this.label12.Text = "Address";
			// 
			// label13
			// 
			this.label13.AutoSize = true;
			this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label13.Location = new System.Drawing.Point(23, 364);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(54, 15);
			this.label13.TabIndex = 6;
			this.label13.Text = "Gender";
			// 
			// label14
			// 
			this.label14.AutoSize = true;
			this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label14.Location = new System.Drawing.Point(23, 324);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(40, 15);
			this.label14.TabIndex = 5;
			this.label14.Text = "State";
			// 
			// label15
			// 
			this.label15.AutoSize = true;
			this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label15.Location = new System.Drawing.Point(23, 275);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(77, 15);
			this.label15.TabIndex = 4;
			this.label15.Text = "Mobile No.";
			// 
			// label16
			// 
			this.label16.AutoSize = true;
			this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label16.Location = new System.Drawing.Point(23, 231);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(49, 15);
			this.label16.TabIndex = 3;
			this.label16.Text = "E-mail";
			// 
			// label17
			// 
			this.label17.AutoSize = true;
			this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label17.Location = new System.Drawing.Point(23, 186);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(89, 15);
			this.label17.TabIndex = 2;
			this.label17.Text = "Date Of Birth";
			// 
			// label18
			// 
			this.label18.AutoSize = true;
			this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label18.Location = new System.Drawing.Point(23, 140);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(97, 15);
			this.label18.TabIndex = 1;
			this.label18.Text = "Contact Name";
			// 
			// label19
			// 
			this.label19.AutoSize = true;
			this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label19.Location = new System.Drawing.Point(23, 99);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(73, 15);
			this.label19.TabIndex = 0;
			this.label19.Text = "Contact ID";
			// 
			// comboBoxState
			// 
			this.comboBoxState.FormattingEnabled = true;
			this.comboBoxState.Location = new System.Drawing.Point(232, 318);
			this.comboBoxState.Name = "comboBoxState";
			this.comboBoxState.Size = new System.Drawing.Size(215, 21);
			this.comboBoxState.TabIndex = 27;
			// 
			// dataGridViewAddressBook
			// 
			this.dataGridViewAddressBook.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridViewAddressBook.Location = new System.Drawing.Point(684, 73);
			this.dataGridViewAddressBook.Name = "dataGridViewAddressBook";
			this.dataGridViewAddressBook.Size = new System.Drawing.Size(525, 382);
			this.dataGridViewAddressBook.TabIndex = 33;
			this.dataGridViewAddressBook.SelectionChanged += new System.EventHandler(this.dataGridViewAddressBook_SelectionChanged);
			// 
			// UpdateForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1221, 542);
			this.Controls.Add(this.dataGridViewAddressBook);
			this.Controls.Add(this.panelUpdate);
			this.Name = "UpdateForm";
			this.Text = "UpdateForm";
			this.Load += new System.EventHandler(this.UpdateForm_Load);
			this.panelUpdate.ResumeLayout(false);
			this.panelUpdate.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridViewAddressBook)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Panel panelUpdate;
		private System.Windows.Forms.Button buttonBack;
		private System.Windows.Forms.Label labelUpdateMessage;
		private System.Windows.Forms.Button buttonEdit;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.RadioButton radioButtonMaleEdit;
		private System.Windows.Forms.RadioButton radioButtonFemaleEdit;
		private System.Windows.Forms.DateTimePicker dateTimePickerDOBEdit;
		private System.Windows.Forms.TextBox textBoxAddressEdit;
		private System.Windows.Forms.TextBox textBoxMobileEdit;
		private System.Windows.Forms.TextBox textBoxEmailEdit;
		private System.Windows.Forms.TextBox textBoxNameEdit;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.Label label18;
		private System.Windows.Forms.Label label19;
		private System.Windows.Forms.ComboBox comboBoxId;
		private System.Windows.Forms.ComboBox comboBoxState;
		private System.Windows.Forms.DataGridView dataGridViewAddressBook;
	}
}