﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AddressBookDTO.AddressDTO;
using AddressBookBLL.AddressBL;

namespace AddressBookPL.AddressPL
{
	public partial class AddressBookPLayer : Form
	{
		public AddressBookPLayer()
		{
			InitializeComponent();
		}

		private void buttonSave_Click(object sender, EventArgs e)
		{			
			
		}

		private void buttonEdit_Click(object sender, EventArgs e)
		{
			//AddressBook objAddressBook = null;
			//int output = 0;
			//try
			//{
			//	objAddressBook = new AddressBook();
			//	objAddressBook.ContactId = textBoxId.Text;
			//	objAddressBook.ContactName = textBoxName.Text;
			//	objAddressBook.DOB = dateTimePickerDOB.Value.ToString("yyyy-mm-dd");
			//	objAddressBook.Email = textBoxEmail.Text;
			//	objAddressBook.MobileNo = Convert.ToInt32(textBoxMobile.Text);
			//	objAddressBook.State = textBoxState.Text;
			//	if (radioButtonFemale.Checked)
			//	{
			//		objAddressBook.Gender = radioButtonFemale.Text;
			//	}
			//	else
			//	{
			//		objAddressBook.Gender = radioButtonMale.Text;
			//	}
			//	objAddressBook.Address = textBoxAddress.Text;

			//	output = AddressBLL.AddressBookEdit(objAddressBook);

			//	if (output > 0)
			//	{
			//		labelMessage.Text = "DATA EDITED SUCCESSFULLY";
			//	}
			//	else
			//	{
			//		labelMessage.Text = "EDITING FAILED";
			//	}
			//}
			//catch (Exception ex)
			//{
			//	labelMessage.Text = ex.Message.ToString();
			//}		
		}

		private void AddressBookPLayer_Load(object sender, EventArgs e)
		{
			panelMenu.Visible = true;
			panelWelcome.Visible = true;

		}

		private void dateTimePickerDOB_ValueChanged(object sender, EventArgs e)
		{
			
		}

		private void buttonDelete_Click(object sender, EventArgs e)
		{
			this.Visible = false;
			DeleteForm s = new DeleteForm();
			s.Visible = true;
			//int output = 0;
			//try
			//{
			//	if (MessageBox.Show("Do you want to Delete", "S I S", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
			//	{
			//		output = AddressBLL.AddressBookDelete(textBoxId.Text);
			//		if (output > 0)
			//		{
			//			labelMessage.Text = "DATA DELETED SUCCESSULLY";
			//		}
			//		else
			//		{
			//			labelMessage.Text = "TRY AGAIN LATER";
			//		}
			//	}
			//}
			//catch(Exception ex)
			//{
			//	Console.Out.WriteLine(ex.Message.ToString());
			//}
		}
		private void buttonSearch_Click(object sender, EventArgs e)
		{
			
		}

		private void button1Search1_Click(object sender, EventArgs e)
		{
			this.Visible = false;
			SearchForm s = new SearchForm();
			s.Visible = true;
		}

		private void buttonInsert_Click(object sender, EventArgs e)
		{
			
			this.Visible = false;   
			InsertForm s = new InsertForm();  
			s.Visible = true;
		}

		private void buttonView_Click(object sender, EventArgs e)
		{
			this.Visible = false;
			ViewForm s = new ViewForm();
			s.Visible = true;
		}

		private void label2_Click(object sender, EventArgs e)
		{

		}

		private void label6_Click(object sender, EventArgs e)
		{

		}

		private void buttonUpdate_Click(object sender, EventArgs e)
		{
			this.Visible = false;
			UpdateForm s = new UpdateForm();
			s.Visible = true;
		}
	}
}
