﻿namespace AddressBookPL.AddressPL
{
	partial class AddressBookPLayer
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.labelMessage = new System.Windows.Forms.Label();
			this.pageSetupDialog1 = new System.Windows.Forms.PageSetupDialog();
			this.buttonDelete = new System.Windows.Forms.Button();
			this.panelMenu = new System.Windows.Forms.Panel();
			this.button1Search1 = new System.Windows.Forms.Button();
			this.buttonInsert = new System.Windows.Forms.Button();
			this.buttonView = new System.Windows.Forms.Button();
			this.panelWelcome = new System.Windows.Forms.Panel();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.buttonUpdate = new System.Windows.Forms.Button();
			this.panelMenu.SuspendLayout();
			this.panelWelcome.SuspendLayout();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label1.Location = new System.Drawing.Point(244, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(191, 25);
			this.label1.TabIndex = 0;
			this.label1.Text = "ADDRESS BOOK";
			// 
			// labelMessage
			// 
			this.labelMessage.AutoSize = true;
			this.labelMessage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.labelMessage.Location = new System.Drawing.Point(216, 74);
			this.labelMessage.Name = "labelMessage";
			this.labelMessage.Size = new System.Drawing.Size(0, 13);
			this.labelMessage.TabIndex = 1;
			// 
			// buttonDelete
			// 
			this.buttonDelete.BackColor = System.Drawing.Color.Maroon;
			this.buttonDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.buttonDelete.ForeColor = System.Drawing.Color.White;
			this.buttonDelete.Location = new System.Drawing.Point(50, 282);
			this.buttonDelete.Name = "buttonDelete";
			this.buttonDelete.Size = new System.Drawing.Size(75, 43);
			this.buttonDelete.TabIndex = 21;
			this.buttonDelete.Text = "DELETE";
			this.buttonDelete.UseVisualStyleBackColor = false;
			this.buttonDelete.Click += new System.EventHandler(this.buttonDelete_Click);
			// 
			// panelMenu
			// 
			this.panelMenu.Controls.Add(this.buttonUpdate);
			this.panelMenu.Controls.Add(this.buttonView);
			this.panelMenu.Controls.Add(this.buttonInsert);
			this.panelMenu.Controls.Add(this.button1Search1);
			this.panelMenu.Controls.Add(this.buttonDelete);
			this.panelMenu.Location = new System.Drawing.Point(16, 101);
			this.panelMenu.Name = "panelMenu";
			this.panelMenu.Size = new System.Drawing.Size(200, 428);
			this.panelMenu.TabIndex = 25;
			// 
			// button1Search1
			// 
			this.button1Search1.BackColor = System.Drawing.Color.Maroon;
			this.button1Search1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button1Search1.ForeColor = System.Drawing.Color.White;
			this.button1Search1.Location = new System.Drawing.Point(50, 352);
			this.button1Search1.Name = "button1Search1";
			this.button1Search1.Size = new System.Drawing.Size(75, 43);
			this.button1Search1.TabIndex = 22;
			this.button1Search1.Text = "SEARCH";
			this.button1Search1.UseVisualStyleBackColor = false;
			this.button1Search1.Click += new System.EventHandler(this.button1Search1_Click);
			// 
			// buttonInsert
			// 
			this.buttonInsert.BackColor = System.Drawing.Color.Maroon;
			this.buttonInsert.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.buttonInsert.ForeColor = System.Drawing.Color.White;
			this.buttonInsert.Location = new System.Drawing.Point(50, 53);
			this.buttonInsert.Name = "buttonInsert";
			this.buttonInsert.Size = new System.Drawing.Size(75, 43);
			this.buttonInsert.TabIndex = 23;
			this.buttonInsert.Text = "INSERT";
			this.buttonInsert.UseVisualStyleBackColor = false;
			this.buttonInsert.Click += new System.EventHandler(this.buttonInsert_Click);
			// 
			// buttonView
			// 
			this.buttonView.BackColor = System.Drawing.Color.Maroon;
			this.buttonView.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.buttonView.ForeColor = System.Drawing.Color.White;
			this.buttonView.Location = new System.Drawing.Point(50, 126);
			this.buttonView.Name = "buttonView";
			this.buttonView.Size = new System.Drawing.Size(75, 43);
			this.buttonView.TabIndex = 24;
			this.buttonView.Text = "VIEW";
			this.buttonView.UseVisualStyleBackColor = false;
			this.buttonView.Click += new System.EventHandler(this.buttonView_Click);
			// 
			// panelWelcome
			// 
			this.panelWelcome.Controls.Add(this.label7);
			this.panelWelcome.Controls.Add(this.label6);
			this.panelWelcome.Controls.Add(this.label5);
			this.panelWelcome.Controls.Add(this.label4);
			this.panelWelcome.Controls.Add(this.label3);
			this.panelWelcome.Controls.Add(this.label2);
			this.panelWelcome.Location = new System.Drawing.Point(249, 101);
			this.panelWelcome.Name = "panelWelcome";
			this.panelWelcome.Size = new System.Drawing.Size(453, 428);
			this.panelWelcome.TabIndex = 28;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
			this.label2.Location = new System.Drawing.Point(77, 89);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(301, 24);
			this.label2.TabIndex = 0;
			this.label2.Text = "Welcome To ADDRESS BOOK.";
			this.label2.Click += new System.EventHandler(this.label2_Click);
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.ForeColor = System.Drawing.Color.Purple;
			this.label3.Location = new System.Drawing.Point(78, 150);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(192, 15);
			this.label3.TabIndex = 1;
			this.label3.Text = "1. Click INSERT to add data. ";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label4.ForeColor = System.Drawing.Color.Purple;
			this.label4.Location = new System.Drawing.Point(78, 183);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(199, 15);
			this.label4.TabIndex = 2;
			this.label4.Text = "2. Click VIEW to view all data. ";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label5.ForeColor = System.Drawing.Color.Purple;
			this.label5.Location = new System.Drawing.Point(78, 215);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(196, 15);
			this.label5.TabIndex = 3;
			this.label5.Text = "3. Click UPDATE to edit data. ";
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label6.ForeColor = System.Drawing.Color.Purple;
			this.label6.Location = new System.Drawing.Point(78, 248);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(211, 15);
			this.label6.TabIndex = 4;
			this.label6.Text = "4. Click DELETE to delete data. ";
			this.label6.Click += new System.EventHandler(this.label6_Click);
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label7.ForeColor = System.Drawing.Color.Purple;
			this.label7.Location = new System.Drawing.Point(78, 281);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(249, 15);
			this.label7.TabIndex = 5;
			this.label7.Text = "5. Click SEARCH to search for a data. ";
			// 
			// buttonUpdate
			// 
			this.buttonUpdate.BackColor = System.Drawing.Color.Maroon;
			this.buttonUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.buttonUpdate.ForeColor = System.Drawing.Color.White;
			this.buttonUpdate.Location = new System.Drawing.Point(50, 203);
			this.buttonUpdate.Name = "buttonUpdate";
			this.buttonUpdate.Size = new System.Drawing.Size(75, 43);
			this.buttonUpdate.TabIndex = 25;
			this.buttonUpdate.Text = "UPDATE";
			this.buttonUpdate.UseVisualStyleBackColor = false;
			this.buttonUpdate.Click += new System.EventHandler(this.buttonUpdate_Click);
			// 
			// AddressBookPLayer
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(795, 555);
			this.Controls.Add(this.panelWelcome);
			this.Controls.Add(this.panelMenu);
			this.Controls.Add(this.labelMessage);
			this.Controls.Add(this.label1);
			this.Name = "AddressBookPLayer";
			this.Text = "AddressBookPLayer";
			this.Load += new System.EventHandler(this.AddressBookPLayer_Load);
			this.panelMenu.ResumeLayout(false);
			this.panelWelcome.ResumeLayout(false);
			this.panelWelcome.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label labelMessage;
		private System.Windows.Forms.PageSetupDialog pageSetupDialog1;
		private System.Windows.Forms.Button buttonDelete;
		private System.Windows.Forms.Panel panelMenu;
		private System.Windows.Forms.Button button1Search1;
		private System.Windows.Forms.Button buttonInsert;
		private System.Windows.Forms.Button buttonView;
		private System.Windows.Forms.Panel panelWelcome;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Button buttonUpdate;
		private System.Windows.Forms.Label label7;
	}
}