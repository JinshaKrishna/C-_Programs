﻿namespace AddressBookPL.AddressPL
{
	partial class InsertForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.panelSave = new System.Windows.Forms.Panel();
			this.comboBoxState = new System.Windows.Forms.ComboBox();
			this.buttonBack = new System.Windows.Forms.Button();
			this.labelInsertMessage = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.radioButtonMale = new System.Windows.Forms.RadioButton();
			this.radioButtonFemale = new System.Windows.Forms.RadioButton();
			this.buttonSave = new System.Windows.Forms.Button();
			this.dateTimePickerDOB = new System.Windows.Forms.DateTimePicker();
			this.textBoxAddress = new System.Windows.Forms.TextBox();
			this.textBoxMobile = new System.Windows.Forms.TextBox();
			this.textBoxEmail = new System.Windows.Forms.TextBox();
			this.textBoxName = new System.Windows.Forms.TextBox();
			this.textBoxId = new System.Windows.Forms.TextBox();
			this.labelAddress = new System.Windows.Forms.Label();
			this.labelGender = new System.Windows.Forms.Label();
			this.labelState = new System.Windows.Forms.Label();
			this.labelMobile = new System.Windows.Forms.Label();
			this.labelEmail = new System.Windows.Forms.Label();
			this.labelDOB = new System.Windows.Forms.Label();
			this.labelContactName = new System.Windows.Forms.Label();
			this.labelContactId = new System.Windows.Forms.Label();
			this.panelSave.SuspendLayout();
			this.SuspendLayout();
			// 
			// panelSave
			// 
			this.panelSave.Controls.Add(this.comboBoxState);
			this.panelSave.Controls.Add(this.buttonBack);
			this.panelSave.Controls.Add(this.labelInsertMessage);
			this.panelSave.Controls.Add(this.label8);
			this.panelSave.Controls.Add(this.radioButtonMale);
			this.panelSave.Controls.Add(this.radioButtonFemale);
			this.panelSave.Controls.Add(this.buttonSave);
			this.panelSave.Controls.Add(this.dateTimePickerDOB);
			this.panelSave.Controls.Add(this.textBoxAddress);
			this.panelSave.Controls.Add(this.textBoxMobile);
			this.panelSave.Controls.Add(this.textBoxEmail);
			this.panelSave.Controls.Add(this.textBoxName);
			this.panelSave.Controls.Add(this.textBoxId);
			this.panelSave.Controls.Add(this.labelAddress);
			this.panelSave.Controls.Add(this.labelGender);
			this.panelSave.Controls.Add(this.labelState);
			this.panelSave.Controls.Add(this.labelMobile);
			this.panelSave.Controls.Add(this.labelEmail);
			this.panelSave.Controls.Add(this.labelDOB);
			this.panelSave.Controls.Add(this.labelContactName);
			this.panelSave.Controls.Add(this.labelContactId);
			this.panelSave.Location = new System.Drawing.Point(126, 12);
			this.panelSave.Name = "panelSave";
			this.panelSave.Size = new System.Drawing.Size(504, 542);
			this.panelSave.TabIndex = 1;
			// 
			// comboBoxState
			// 
			this.comboBoxState.FormattingEnabled = true;
			this.comboBoxState.Location = new System.Drawing.Point(232, 304);
			this.comboBoxState.Name = "comboBoxState";
			this.comboBoxState.Size = new System.Drawing.Size(215, 21);
			this.comboBoxState.TabIndex = 22;
			// 
			// buttonBack
			// 
			this.buttonBack.BackColor = System.Drawing.Color.Black;
			this.buttonBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.buttonBack.ForeColor = System.Drawing.Color.White;
			this.buttonBack.Location = new System.Drawing.Point(119, 478);
			this.buttonBack.Name = "buttonBack";
			this.buttonBack.Size = new System.Drawing.Size(75, 43);
			this.buttonBack.TabIndex = 21;
			this.buttonBack.Text = "BACK";
			this.buttonBack.UseVisualStyleBackColor = false;
			this.buttonBack.Click += new System.EventHandler(this.buttonBack_Click);
			// 
			// labelInsertMessage
			// 
			this.labelInsertMessage.AutoSize = true;
			this.labelInsertMessage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.labelInsertMessage.Location = new System.Drawing.Point(157, 47);
			this.labelInsertMessage.Name = "labelInsertMessage";
			this.labelInsertMessage.Size = new System.Drawing.Size(0, 13);
			this.labelInsertMessage.TabIndex = 2;
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label8.ForeColor = System.Drawing.Color.Purple;
			this.label8.Location = new System.Drawing.Point(213, 13);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(85, 16);
			this.label8.TabIndex = 20;
			this.label8.Text = "ADD DATA";
			// 
			// radioButtonMale
			// 
			this.radioButtonMale.AutoSize = true;
			this.radioButtonMale.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.radioButtonMale.Location = new System.Drawing.Point(317, 350);
			this.radioButtonMale.Name = "radioButtonMale";
			this.radioButtonMale.Size = new System.Drawing.Size(48, 17);
			this.radioButtonMale.TabIndex = 19;
			this.radioButtonMale.TabStop = true;
			this.radioButtonMale.Text = "Male";
			this.radioButtonMale.UseVisualStyleBackColor = true;
			// 
			// radioButtonFemale
			// 
			this.radioButtonFemale.AutoSize = true;
			this.radioButtonFemale.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.radioButtonFemale.Location = new System.Drawing.Point(232, 352);
			this.radioButtonFemale.Name = "radioButtonFemale";
			this.radioButtonFemale.Size = new System.Drawing.Size(59, 17);
			this.radioButtonFemale.TabIndex = 18;
			this.radioButtonFemale.TabStop = true;
			this.radioButtonFemale.Text = "Female";
			this.radioButtonFemale.UseVisualStyleBackColor = true;
			// 
			// buttonSave
			// 
			this.buttonSave.BackColor = System.Drawing.Color.Black;
			this.buttonSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.buttonSave.ForeColor = System.Drawing.Color.White;
			this.buttonSave.Location = new System.Drawing.Point(232, 478);
			this.buttonSave.Name = "buttonSave";
			this.buttonSave.Size = new System.Drawing.Size(75, 43);
			this.buttonSave.TabIndex = 16;
			this.buttonSave.Text = "NEW";
			this.buttonSave.UseVisualStyleBackColor = false;
			this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
			// 
			// dateTimePickerDOB
			// 
			this.dateTimePickerDOB.Location = new System.Drawing.Point(232, 171);
			this.dateTimePickerDOB.MaxDate = new System.DateTime(9997, 10, 21, 0, 0, 0, 0);
			this.dateTimePickerDOB.Name = "dateTimePickerDOB";
			this.dateTimePickerDOB.Size = new System.Drawing.Size(215, 20);
			this.dateTimePickerDOB.TabIndex = 17;
			this.dateTimePickerDOB.ValueChanged += new System.EventHandler(this.dateTimePickerDOB_ValueChanged);
			// 
			// textBoxAddress
			// 
			this.textBoxAddress.Location = new System.Drawing.Point(232, 399);
			this.textBoxAddress.Multiline = true;
			this.textBoxAddress.Name = "textBoxAddress";
			this.textBoxAddress.Size = new System.Drawing.Size(215, 56);
			this.textBoxAddress.TabIndex = 15;
			// 
			// textBoxMobile
			// 
			this.textBoxMobile.Location = new System.Drawing.Point(232, 265);
			this.textBoxMobile.Name = "textBoxMobile";
			this.textBoxMobile.Size = new System.Drawing.Size(215, 20);
			this.textBoxMobile.TabIndex = 12;
			// 
			// textBoxEmail
			// 
			this.textBoxEmail.Location = new System.Drawing.Point(232, 217);
			this.textBoxEmail.Name = "textBoxEmail";
			this.textBoxEmail.Size = new System.Drawing.Size(215, 20);
			this.textBoxEmail.TabIndex = 11;
			// 
			// textBoxName
			// 
			this.textBoxName.Location = new System.Drawing.Point(232, 126);
			this.textBoxName.Name = "textBoxName";
			this.textBoxName.Size = new System.Drawing.Size(215, 20);
			this.textBoxName.TabIndex = 9;
			// 
			// textBoxId
			// 
			this.textBoxId.Location = new System.Drawing.Point(232, 84);
			this.textBoxId.Name = "textBoxId";
			this.textBoxId.Size = new System.Drawing.Size(215, 20);
			this.textBoxId.TabIndex = 8;
			// 
			// labelAddress
			// 
			this.labelAddress.AutoSize = true;
			this.labelAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.labelAddress.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.labelAddress.Location = new System.Drawing.Point(23, 399);
			this.labelAddress.Name = "labelAddress";
			this.labelAddress.Size = new System.Drawing.Size(58, 15);
			this.labelAddress.TabIndex = 7;
			this.labelAddress.Text = "Address";
			// 
			// labelGender
			// 
			this.labelGender.AutoSize = true;
			this.labelGender.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.labelGender.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.labelGender.Location = new System.Drawing.Point(23, 354);
			this.labelGender.Name = "labelGender";
			this.labelGender.Size = new System.Drawing.Size(54, 15);
			this.labelGender.TabIndex = 6;
			this.labelGender.Text = "Gender";
			// 
			// labelState
			// 
			this.labelState.AutoSize = true;
			this.labelState.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.labelState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.labelState.Location = new System.Drawing.Point(23, 310);
			this.labelState.Name = "labelState";
			this.labelState.Size = new System.Drawing.Size(40, 15);
			this.labelState.TabIndex = 5;
			this.labelState.Text = "State";
			// 
			// labelMobile
			// 
			this.labelMobile.AutoSize = true;
			this.labelMobile.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.labelMobile.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.labelMobile.Location = new System.Drawing.Point(23, 270);
			this.labelMobile.Name = "labelMobile";
			this.labelMobile.Size = new System.Drawing.Size(77, 15);
			this.labelMobile.TabIndex = 4;
			this.labelMobile.Text = "Mobile No.";
			// 
			// labelEmail
			// 
			this.labelEmail.AutoSize = true;
			this.labelEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.labelEmail.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.labelEmail.Location = new System.Drawing.Point(23, 222);
			this.labelEmail.Name = "labelEmail";
			this.labelEmail.Size = new System.Drawing.Size(49, 15);
			this.labelEmail.TabIndex = 3;
			this.labelEmail.Text = "E-mail";
			// 
			// labelDOB
			// 
			this.labelDOB.AutoSize = true;
			this.labelDOB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.labelDOB.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.labelDOB.Location = new System.Drawing.Point(23, 176);
			this.labelDOB.Name = "labelDOB";
			this.labelDOB.Size = new System.Drawing.Size(89, 15);
			this.labelDOB.TabIndex = 2;
			this.labelDOB.Text = "Date Of Birth";
			// 
			// labelContactName
			// 
			this.labelContactName.AutoSize = true;
			this.labelContactName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.labelContactName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.labelContactName.Location = new System.Drawing.Point(23, 131);
			this.labelContactName.Name = "labelContactName";
			this.labelContactName.Size = new System.Drawing.Size(97, 15);
			this.labelContactName.TabIndex = 1;
			this.labelContactName.Text = "Contact Name";
			// 
			// labelContactId
			// 
			this.labelContactId.AutoSize = true;
			this.labelContactId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.labelContactId.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.labelContactId.Location = new System.Drawing.Point(23, 89);
			this.labelContactId.Name = "labelContactId";
			this.labelContactId.Size = new System.Drawing.Size(73, 15);
			this.labelContactId.TabIndex = 0;
			this.labelContactId.Text = "Contact ID";
			// 
			// InsertForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 566);
			this.Controls.Add(this.panelSave);
			this.Name = "InsertForm";
			this.Text = "InsertForm";
			this.Load += new System.EventHandler(this.InsertForm_Load);
			this.panelSave.ResumeLayout(false);
			this.panelSave.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Panel panelSave;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.RadioButton radioButtonMale;
		private System.Windows.Forms.RadioButton radioButtonFemale;
		private System.Windows.Forms.Button buttonSave;
		private System.Windows.Forms.DateTimePicker dateTimePickerDOB;
		private System.Windows.Forms.TextBox textBoxAddress;
		private System.Windows.Forms.TextBox textBoxMobile;
		private System.Windows.Forms.TextBox textBoxEmail;
		private System.Windows.Forms.TextBox textBoxName;
		private System.Windows.Forms.TextBox textBoxId;
		private System.Windows.Forms.Label labelAddress;
		private System.Windows.Forms.Label labelGender;
		private System.Windows.Forms.Label labelState;
		private System.Windows.Forms.Label labelMobile;
		private System.Windows.Forms.Label labelEmail;
		private System.Windows.Forms.Label labelDOB;
		private System.Windows.Forms.Label labelContactName;
		private System.Windows.Forms.Label labelContactId;
		private System.Windows.Forms.Label labelInsertMessage;
		private System.Windows.Forms.Button buttonBack;
		private System.Windows.Forms.ComboBox comboBoxState;
	}
}