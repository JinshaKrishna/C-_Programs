﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AddressBookBLL.AddressBL;
using AddressBookDTO.AddressDTO;

namespace AddressBookPL.AddressPL
{
	public partial class InsertForm : Form
	{
		public InsertForm()
		{
			InitializeComponent();
		}

		private void InsertForm_Load(object sender, EventArgs e)
		{
			comboBoxState.Items.Add("KERALA");
			comboBoxState.Items.Add("TAMIL NADU");
			comboBoxState.Items.Add("KARNATAKA");
			comboBoxState.Items.Add("ANDHRA PRADESH");
			comboBoxState.Items.Add("GUJARATH");
			comboBoxState.Items.Add("ARUNACHAL PRADESH");
		}

		private void buttonSave_Click(object sender, EventArgs e)
		{
			if (buttonSave.Text == "NEW")
			{
				buttonSave.Text = "SAVE";
				ClearControl();
				textBoxId.Text = AddressBLL.GetNewContactId();
			}
			else
			{

				if (textBoxId.Text == string.Empty && textBoxName.Text == string.Empty && textBoxEmail.Text == string.Empty && textBoxMobile.Text == "" && comboBoxState.Text == string.Empty && textBoxAddress.Text == string.Empty)
				{
					labelInsertMessage.Text = "All data are mandatory. Please provide it.";
				}
				else if (textBoxId.Text == string.Empty)
				{
					labelInsertMessage.Text = "Please Enter Contact Id.";
				}
				else if (textBoxName.Text == string.Empty)
				{
					labelInsertMessage.Text = "Please Enter Contact Name.";
				}
				else if (dateTimePickerDOB.Text == string.Empty)
				{
					labelInsertMessage.Text = "Please Enter Date Of Birth.";
				}
				else if (textBoxEmail.Text == string.Empty)
				{
					labelInsertMessage.Text = "Please Enter Email Id.";
				}
				else if (textBoxMobile.Text == string.Empty)
				{
					labelInsertMessage.Text = "Please Enter Mobile No.";
				}
				else if (comboBoxState.Text == string.Empty)
				{
					labelInsertMessage.Text = "Please Select one from States.";
				}
				else if (textBoxAddress.Text == string.Empty)
				{
					labelInsertMessage.Text = "Please Enter Contact Address.";
				}
				else if (!radioButtonFemale.Checked && !radioButtonMale.Checked)
				{
					labelInsertMessage.Text = "Please check one from Gender.";
				}
				else if (!textBoxEmail.Text.Contains("@"))
				{
					labelInsertMessage.Text = "Please Enter a valid Email Id.";
				}
				else
				{
					AddressBook objAddressBook = null;
					int output = 0;
					try
					{
						objAddressBook = new AddressBook();
						objAddressBook.ContactId = textBoxId.Text;
						objAddressBook.ContactName = textBoxName.Text;
						objAddressBook.DOB = dateTimePickerDOB.Value.ToString("yyyy-MM-dd");
						objAddressBook.Email = textBoxEmail.Text;
						objAddressBook.MobileNo = Convert.ToInt64(textBoxMobile.Text);
						objAddressBook.State = comboBoxState.Text;
						if (radioButtonFemale.Checked)
						{
							objAddressBook.Gender = radioButtonFemale.Text;
						}
						else
						{
							objAddressBook.Gender = radioButtonMale.Text;
						}
						objAddressBook.Address = textBoxAddress.Text;

						output = AddressBLL.AddressBookInsert(objAddressBook);

						if (output > 0)
						{
							labelInsertMessage.Text = "DATA ADDED SUCCESSFULLY";
						}
						else
						{
							labelInsertMessage.Text = "INSERTION FAILED";
						}
						//LoadAddressBook();

					}
					catch (Exception ex)
					{
						labelInsertMessage.Text = ex.Message.ToString();
					}
				}
			}
		}

		private void buttonBack_Click(object sender, EventArgs e)
		{
			this.Visible = false;
			AddressBookPLayer s = new AddressBookPLayer();
			s.Visible = true;
		}
		public void ClearControl()
		{
			textBoxName.Text = "";

		}

		private void dateTimePickerDOB_ValueChanged(object sender, EventArgs e)
		{
			dateTimePickerDOB.MaxDate = new DateTime(2008, 1, 31);
			dateTimePickerDOB.MinDate = new DateTime(1995, 1, 1);
		}
	}
}
