﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AddressBookDTO.AddressDTO;
using AddressBookBLL.AddressBL;

namespace AddressBookPL.AddressPL
{
	public partial class SearchForm : Form
	{
		public SearchForm()
		{
			InitializeComponent();
		}

		private void buttonSearch_Click(object sender, EventArgs e)
		{
			if (comboBoxSearch.Text == string.Empty)
			{
				labelSearchMessage.Text = "Please select an option to search.";
			}
			else if (textBoxSearch.Text == string.Empty)
			{
				labelSearchMessage.Text = "Please Enter atleast first character.";
			}
			else
			{
				DataSet dsAddressBook = null;
				string contactId = null;
				try
				{
					if (comboBoxSearch.Text == "Contact ID")
					{
						contactId = "contactId";
					}
					if (comboBoxSearch.Text == "Contact Name")
					{
						contactId = "contactName";
					}
					if (comboBoxSearch.Text == "Date Of Birth")
					{
						contactId = "dob";
					}
					if (comboBoxSearch.Text == "Email")
					{
						contactId = "email";
					}
					if (comboBoxSearch.Text == "Mobile No")
					{
						contactId = "mobileNo";
					}
					if (comboBoxSearch.Text == "Gender")
					{
						contactId = "gender";
					}
					if (comboBoxSearch.Text == "Address")
					{
						contactId = "address";
					}
					string like = textBoxSearch.Text;
					dsAddressBook = AddressBLL.GetAddressBookLike(contactId, like);
					if (dsAddressBook != null)
					{
						dataGridViewSearch.DataSource = dsAddressBook.Tables[0];
					}
					else
					{
						labelSearchMessage.Text = "No Details Available in Address Book";
					}
				}
				catch (Exception ex)
				{
					Console.Out.WriteLine(ex.Message.ToString());
				}
			}
		}

		private void panelSearch_Paint(object sender, PaintEventArgs e)
		{
			
		}

		private void buttonBack_Click(object sender, EventArgs e)
		{
			this.Visible = false;
			AddressBookPLayer s = new AddressBookPLayer();
			s.Visible = true;
		}

		private void SearchForm_Load(object sender, EventArgs e)
		{
			comboBoxSearch.Items.Add("Contact ID");
			comboBoxSearch.Items.Add("Contact Name");
			comboBoxSearch.Items.Add("Date Of Birth");
			comboBoxSearch.Items.Add("Email");
			comboBoxSearch.Items.Add("Mobile No");
			comboBoxSearch.Items.Add("State");
			comboBoxSearch.Items.Add("Gender");
			comboBoxSearch.Items.Add("Address");
		}
	}
}
