﻿namespace AddressBookPL.AddressPL
{
	partial class DeleteForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.panelDelete = new System.Windows.Forms.Panel();
			this.buttonDelete = new System.Windows.Forms.Button();
			this.buttonBack = new System.Windows.Forms.Button();
			this.comboBoxId = new System.Windows.Forms.ComboBox();
			this.label19 = new System.Windows.Forms.Label();
			this.labelDeleteMessage = new System.Windows.Forms.Label();
			this.label11 = new System.Windows.Forms.Label();
			this.panelDelete.SuspendLayout();
			this.SuspendLayout();
			// 
			// panelDelete
			// 
			this.panelDelete.Controls.Add(this.buttonDelete);
			this.panelDelete.Controls.Add(this.buttonBack);
			this.panelDelete.Controls.Add(this.comboBoxId);
			this.panelDelete.Controls.Add(this.label19);
			this.panelDelete.Controls.Add(this.labelDeleteMessage);
			this.panelDelete.Controls.Add(this.label11);
			this.panelDelete.Location = new System.Drawing.Point(42, 12);
			this.panelDelete.Name = "panelDelete";
			this.panelDelete.Size = new System.Drawing.Size(594, 412);
			this.panelDelete.TabIndex = 0;
			// 
			// buttonDelete
			// 
			this.buttonDelete.BackColor = System.Drawing.Color.Black;
			this.buttonDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.buttonDelete.ForeColor = System.Drawing.Color.White;
			this.buttonDelete.Location = new System.Drawing.Point(317, 352);
			this.buttonDelete.Name = "buttonDelete";
			this.buttonDelete.Size = new System.Drawing.Size(75, 43);
			this.buttonDelete.TabIndex = 27;
			this.buttonDelete.Text = "DELETE";
			this.buttonDelete.UseVisualStyleBackColor = false;
			this.buttonDelete.Click += new System.EventHandler(this.buttonEdit_Click);
			// 
			// buttonBack
			// 
			this.buttonBack.BackColor = System.Drawing.Color.Black;
			this.buttonBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.buttonBack.ForeColor = System.Drawing.Color.White;
			this.buttonBack.Location = new System.Drawing.Point(205, 352);
			this.buttonBack.Name = "buttonBack";
			this.buttonBack.Size = new System.Drawing.Size(75, 43);
			this.buttonBack.TabIndex = 26;
			this.buttonBack.Text = "BACK";
			this.buttonBack.UseVisualStyleBackColor = false;
			this.buttonBack.Click += new System.EventHandler(this.buttonBack_Click);
			// 
			// comboBoxId
			// 
			this.comboBoxId.FormattingEnabled = true;
			this.comboBoxId.Location = new System.Drawing.Point(226, 122);
			this.comboBoxId.Name = "comboBoxId";
			this.comboBoxId.Size = new System.Drawing.Size(226, 21);
			this.comboBoxId.TabIndex = 25;
			// 
			// label19
			// 
			this.label19.AutoSize = true;
			this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label19.Location = new System.Drawing.Point(68, 128);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(73, 15);
			this.label19.TabIndex = 24;
			this.label19.Text = "Contact ID";
			// 
			// labelDeleteMessage
			// 
			this.labelDeleteMessage.AutoSize = true;
			this.labelDeleteMessage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.labelDeleteMessage.Location = new System.Drawing.Point(202, 59);
			this.labelDeleteMessage.Name = "labelDeleteMessage";
			this.labelDeleteMessage.Size = new System.Drawing.Size(0, 13);
			this.labelDeleteMessage.TabIndex = 23;
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label11.ForeColor = System.Drawing.Color.Purple;
			this.label11.Location = new System.Drawing.Point(232, 20);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(112, 16);
			this.label11.TabIndex = 21;
			this.label11.Text = "DELETE DATA";
			// 
			// DeleteForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 450);
			this.Controls.Add(this.panelDelete);
			this.Name = "DeleteForm";
			this.Text = "DeleteForm";
			this.Load += new System.EventHandler(this.DeleteForm_Load);
			this.panelDelete.ResumeLayout(false);
			this.panelDelete.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Panel panelDelete;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label labelDeleteMessage;
		private System.Windows.Forms.ComboBox comboBoxId;
		private System.Windows.Forms.Label label19;
		private System.Windows.Forms.Button buttonBack;
		private System.Windows.Forms.Button buttonDelete;
	}
}