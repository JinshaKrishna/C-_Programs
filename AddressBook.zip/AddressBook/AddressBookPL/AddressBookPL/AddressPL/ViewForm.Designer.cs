﻿namespace AddressBookPL.AddressPL
{
	partial class ViewForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.panelView = new System.Windows.Forms.Panel();
			this.buttonBack = new System.Windows.Forms.Button();
			this.labelViewMessage = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			this.dataGridViewAddressBook = new System.Windows.Forms.DataGridView();
			this.panelView.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridViewAddressBook)).BeginInit();
			this.SuspendLayout();
			// 
			// panelView
			// 
			this.panelView.Controls.Add(this.buttonBack);
			this.panelView.Controls.Add(this.labelViewMessage);
			this.panelView.Controls.Add(this.label10);
			this.panelView.Controls.Add(this.dataGridViewAddressBook);
			this.panelView.Location = new System.Drawing.Point(33, 12);
			this.panelView.Name = "panelView";
			this.panelView.Size = new System.Drawing.Size(740, 565);
			this.panelView.TabIndex = 28;
			this.panelView.Paint += new System.Windows.Forms.PaintEventHandler(this.panelView_Paint);
			// 
			// buttonBack
			// 
			this.buttonBack.BackColor = System.Drawing.Color.Black;
			this.buttonBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.buttonBack.ForeColor = System.Drawing.Color.White;
			this.buttonBack.Location = new System.Drawing.Point(261, 502);
			this.buttonBack.Name = "buttonBack";
			this.buttonBack.Size = new System.Drawing.Size(75, 43);
			this.buttonBack.TabIndex = 29;
			this.buttonBack.Text = "BACK";
			this.buttonBack.UseVisualStyleBackColor = false;
			this.buttonBack.Click += new System.EventHandler(this.buttonBack_Click);
			// 
			// labelViewMessage
			// 
			this.labelViewMessage.AutoSize = true;
			this.labelViewMessage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.labelViewMessage.Location = new System.Drawing.Point(185, 54);
			this.labelViewMessage.Name = "labelViewMessage";
			this.labelViewMessage.Size = new System.Drawing.Size(0, 13);
			this.labelViewMessage.TabIndex = 28;
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label10.ForeColor = System.Drawing.Color.Purple;
			this.label10.Location = new System.Drawing.Point(245, 13);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(91, 16);
			this.label10.TabIndex = 27;
			this.label10.Text = "VIEW DATA";
			// 
			// dataGridViewAddressBook
			// 
			this.dataGridViewAddressBook.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridViewAddressBook.Location = new System.Drawing.Point(20, 97);
			this.dataGridViewAddressBook.Name = "dataGridViewAddressBook";
			this.dataGridViewAddressBook.Size = new System.Drawing.Size(703, 382);
			this.dataGridViewAddressBook.TabIndex = 3;
			// 
			// ViewForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 589);
			this.Controls.Add(this.panelView);
			this.Name = "ViewForm";
			this.Text = "ViewForm";
			this.Load += new System.EventHandler(this.ViewForm_Load);
			this.panelView.ResumeLayout(false);
			this.panelView.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridViewAddressBook)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Panel panelView;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.DataGridView dataGridViewAddressBook;
		private System.Windows.Forms.Label labelViewMessage;
		private System.Windows.Forms.Button buttonBack;
	}
}