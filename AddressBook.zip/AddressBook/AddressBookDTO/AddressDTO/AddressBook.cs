﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AddressBookDTO.AddressDTO
{
	public class AddressBook
	{
		private string contactId;

		public string ContactId
		{
			get { return contactId; }
			set { contactId = value; }
		}
		private string contactName;

		public string ContactName
		{
			get { return contactName; }
			set { contactName = value; }
		}
		private string dob;

		public string DOB
		{
			get { return dob; }
			set { dob = value; }
		}
		private string email;

		public string Email
		{
			get { return email; }
			set { email = value; }
		}
		private double mobileNo;

		public double MobileNo
		{
			get { return mobileNo; }
			set { mobileNo = value; }
		}
		private string state;

		public string State
		{
			get { return state; }
			set { state = value; }
		}
		private string gender;

		public string Gender
		{
			get { return gender; }
			set { gender = value; }
		}
		private string address;

		public string Address
		{
			get { return address; }
			set { address = value; }
		}

	}
}
