﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AddressBookDTO.AddressDTO;
using AddressBookDSL.Helper;
using System.Data;

namespace AddressBookDSL.AddressDL
{
	public class AddressDSL
	{
		public static int AddressBookInsert(AddressBook objAddressBook)
		{
			int output = 0;
			string sql = "";
			SqlConnection con = null;
			SqlCommand cmd = null;
			try
			{
				sql = "insert into AddressBookDetails(contactId,contactName,dob,email,mobileNo,state,gender,address) values(";
				sql = sql + "'" + objAddressBook.ContactId + "',";
				sql = sql + "'" + objAddressBook.ContactName + "',";
				sql = sql + "'" + objAddressBook.DOB + "',";
				sql = sql + "'" + objAddressBook.Email + "',";
				sql = sql + "" + objAddressBook.MobileNo + ",";
				sql = sql + "'" + objAddressBook.State + "',";
				sql = sql + "'" + objAddressBook.Gender + "',";
				sql = sql + "'" + objAddressBook.Address + "')";

				con = DBHelper.GetConnection();
				con.Open();
				cmd = new SqlCommand(sql, con);
				output = cmd.ExecuteNonQuery();
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine("Error : AddressDSL : AddressBookInsert() " + ex.Message.ToString());
			}
			finally
			{
				con.Close();
				cmd.Dispose();
			}
			return output;
		}
		public static int AddressBookEdit(AddressBook objAddressBook)
		{
			int output = 0;
			string sql = "";
			SqlConnection con = null;
			SqlCommand cmd = null;
			try
			{
				sql = "update AddressBookDetails set ";
				sql = sql + "contactName='" + objAddressBook.ContactName + "',";
				sql = sql + "dob='" + objAddressBook.DOB + "',";
				sql = sql + "email='" + objAddressBook.Email + "',";
				sql = sql + "mobileNo=" + objAddressBook.MobileNo + ",";
				sql = sql + "state='" + objAddressBook.State + "',";
				sql = sql + "gender='" + objAddressBook.Gender + "',";
				sql = sql + "address='" + objAddressBook.Address + "' ";
				sql = sql + "where contactId='" + objAddressBook.ContactId + "'";

				con = DBHelper.GetConnection();
				con.Open();
				cmd = new SqlCommand(sql, con);

				output = cmd.ExecuteNonQuery();


			}
			catch (Exception ex)
			{
				Console.Out.WriteLine("Error : AddressDSL : AddressBookEdit() " + ex.Message.ToString());
			}
			finally
			{
				con.Close();
				cmd.Dispose();
			}
			return output;
		}
		public static int AddressBookDelete(string contactId)
		{
			int output = 0;
			string sql = "";
			SqlConnection con = null;
			SqlCommand cmd = null;
			try
			{
				sql = "delete from AddressBookDetails where contactId='" + contactId + "'";

				con = DBHelper.GetConnection();
				con.Open();
				cmd = new SqlCommand(sql, con);
				output = cmd.ExecuteNonQuery();

			}
			catch (Exception ex)
			{
				Console.Out.WriteLine("Error : AddressDSL : AddressBookDelete() " + ex.Message.ToString());
			}
			finally
			{
				con.Close();
				cmd.Dispose();
			}
			return output;
		}
		public static DataSet GetAddressBook()
		{
			string sql = "";
			SqlConnection con = null;
			SqlDataAdapter adapter = null;
			DataSet dsAddressBook = null;
			try
			{
				sql = "select * from AddressBookDetails";

				con = DBHelper.GetConnection();
				con.Open();
				dsAddressBook = new DataSet();
				adapter = new SqlDataAdapter(sql, con);
				adapter.Fill(dsAddressBook);
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine(" Error : AddressDSL : GetAddressBook() " + ex.Message.ToString());
			}
			finally
			{
				con.Close();
				adapter.Dispose();
			}
			return dsAddressBook;
		}
		public static DataSet GetAddressBookLike(string contactId, string like)
		{
			string sql = "";
			SqlConnection con = null;
			SqlDataAdapter adapter = null;
			DataSet dsAddressBook = null;
			try
			{
				sql = "select * from AddressBookDetails where " + contactId + " like '" + like + "%'";

				con = DBHelper.GetConnection();
				con.Open();
				dsAddressBook = new DataSet();
				adapter = new SqlDataAdapter(sql, con);
				adapter.Fill(dsAddressBook);
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine(" Error : AddressDSL : GetAddressBook() " + ex.Message.ToString());
			}
			finally
			{
				con.Close();
				adapter.Dispose();
			}
			return dsAddressBook;
		}
		public static DataSet GetAddressBookIds()
		{
			string sql = "";
			SqlConnection con = null;
			SqlDataAdapter adapter = null;
			DataSet dsAddressBooks = null;
			try
			{
				sql = "select contactId from AddressBookDetails";

				con = DBHelper.GetConnection();
				con.Open();
				dsAddressBooks = new DataSet();
				adapter = new SqlDataAdapter(sql, con);
				adapter.Fill(dsAddressBooks);
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine(" Error : AddressDSL : GetAddressBookIds() " + ex.Message.ToString());
			}
			finally
			{
				con.Close();
				adapter.Dispose();
			}
			return dsAddressBooks;
		}
		public static AddressBook GetAddressBookByIds(string contactId)
		{
			string sql = "";
			SqlConnection con = null;
			SqlDataAdapter adapter = null;
			DataSet dsAddressBook = null;
			AddressBook objAddressBooks = null;
			try
			{
				sql = "select * from AddressBookDetails where contactId='" + contactId + "'";

				con = DBHelper.GetConnection();
				con.Open();
				
				dsAddressBook = new DataSet();
				adapter = new SqlDataAdapter(sql, con);
				adapter.Fill(dsAddressBook);

				Object[] Data = null;

				if (dsAddressBook.Tables[0].Rows.Count > 0)
				{
					Data = dsAddressBook.Tables[0].Rows[0].ItemArray;
					objAddressBooks = new AddressBook();
					objAddressBooks.ContactId = Data[0].ToString();
					objAddressBooks.ContactName = Data[1].ToString();
					//objAddressBooks.DOB = Data[2].ToString();
					objAddressBooks.Email = Data[3].ToString();
					objAddressBooks.MobileNo = Convert.ToInt64(Data[4].ToString());
					objAddressBooks.State = Data[5].ToString();
					if (Data[6].ToString() == "Female")
					{
						objAddressBooks.Gender = "Female";
					}
					else
					{
						objAddressBooks.Gender = "Male";
					}
					objAddressBooks.Address = Data[7].ToString();
				}
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine(" Error : AddressDSL : GetAddressBookIds() " + ex.Message.ToString());
			}
			finally
			{
				con.Close();
				adapter.Dispose();
			}
			return objAddressBooks;
		}
		public static string GetLastContactId()
		{
			string sql = "";
			SqlConnection con = null;
			SqlDataAdapter adapter = null;
			DataSet dsStudents = null;
			string lastStudentId = null;
			Object[] Data = null;
			try
			{
				sql = "select contactId from AddressBookDetails order by contactId desc";
				con = DBHelper.GetConnection();
				con.Open();
				dsStudents = new DataSet();
				adapter = new SqlDataAdapter(sql, con);
				adapter.Fill(dsStudents);

				if (dsStudents.Tables[0].Rows.Count > 0)
				{
					Data = dsStudents.Tables[0].Rows[0].ItemArray;
					lastStudentId = Data[0].ToString();
				}
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine("Error : AddressDSL : GetLastContactId() " + ex.Message.ToString());
			}
			finally
			{
				con.Close();
				adapter.Dispose();
			}

			return lastStudentId;
		}
	}
}
