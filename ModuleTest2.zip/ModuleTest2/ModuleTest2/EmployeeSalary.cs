﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModuleTest2
{
    class EmployeeSalary
    {
        public static void Main()
        {
            Employee objEmployee = new Employee();
            
            int option;
            int number = objEmployee.ReadData();
            do
            {
                Console.WriteLine("\n------------ Employee Salary ------------\n1. Read the Details\n2. Display all Employee Details\n3. Particular Employee Details\n4. Exit\n---------------------------------");
                Console.Write("\nEnter the Option : ");
                option = Convert.ToInt32(Console.ReadLine());
                switch (option)
                {
                    case 1:
                        for(int index = 0;index < number;index++)
                        {
                            Console.Write("Enter the Salary : ");
                            objEmployee[index] = Convert.ToInt32(Console.ReadLine());
                        }
                        
                        break;

                    case 2:
                        for (int index = 0; index < number; index++)
                        {
                            Console.Write("\nSalary of Employee {0} : {1}" ,index+1,  objEmployee[index]);
                        }
                        break;
                    case 3:
                        int indexer;
                        Console.Write("\nEnter the Index of the particular Employee : ");
                        indexer = Convert.ToInt16(Console.ReadLine());    
                        Console.Write("Salary : " + objEmployee[indexer-1]);
                        break;

                    case 4:
                        System.Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid operation");
                        break;
                }
            } while (true);
        }
    }
    class Employee
    {
        public int noOfEmployees;
        public int[] salary;

        public int ReadData()
        {
            Console.WriteLine("Enter the No Of Employees ");
            noOfEmployees = Convert.ToInt32(Console.ReadLine());
            salary = new int[noOfEmployees];

            return noOfEmployees;
        }

        public int this[int index]
        {
            get{ return salary[index]; }
            set { salary[index] = value;}
        } 
    }
}
