﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModuleTest2
{
    class MOBException : Exception
    {
        public MOBException()
        {
            Console.WriteLine("!!!... Wrong input | Please Enter a Value Greater than 0\n");
        }
    }
    class SalesAmountOfNMonths
    {
        int noOfMonths;
        int[] salesAmount;
        public void ReadData()
        {
            Console.WriteLine("Enter the No Of Months ");
            noOfMonths = Convert.ToInt32(Console.ReadLine());
            salesAmount = new int[noOfMonths];
            Console.WriteLine("---- Enter the Sales amount in each Month ----\n");
            for(int index = 0;index < noOfMonths;index++)
            {
                try
                {
                    Console.Write("Enter the Sales report in Month {0} : ", index+1);
                    salesAmount[index] = Convert.ToInt32(Console.ReadLine());
                    if (salesAmount[index] < 0)
                    {
                        throw new MOBException();
                    }
                }
                catch(Exception e)
                {
                    Console.WriteLine("!!!... Wrong input | Please Enter a valid Integer\n");
                    index--;
                }
                
            }
        }
        public void SortSalesAmount()
        {
            int[] sortSalesAmount = salesAmount;
            for (int index = 0; index < noOfMonths-1; index++)
            {
                for(int next = index+1;next < noOfMonths;next++)
                {
                    if(sortSalesAmount[next] < sortSalesAmount[index])
                    {
                        int temp = sortSalesAmount[next];
                        sortSalesAmount[next] = sortSalesAmount[index];
                        sortSalesAmount[index] = temp;
                    }
                }
            }

            Console.WriteLine("\n----------SALES REPORT-------------\n");
            foreach(int index in sortSalesAmount)
            { 
                Console.Write(index + " ");
            }
        }
        public static void Main()
        {
            SalesAmountOfNMonths objSalesAmount = new SalesAmountOfNMonths();
            objSalesAmount.ReadData();
            objSalesAmount.SortSalesAmount();

            Console.ReadKey();
        }
    }
}
