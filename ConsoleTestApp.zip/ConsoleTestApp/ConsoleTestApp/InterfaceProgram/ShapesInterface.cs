﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class ShapesInterface
    {
        public static void Main()
        {
            ShapesClass shapes = new ShapesClass();
            shapes.AreaCircle();
            shapes.DisplayArea();
            shapes.AreaSquare();
            shapes.DisplayArea();
            shapes.AreaTriangle();
            shapes.DisplayArea();

            Console.ReadKey();
        }
        
    }
    interface ShapeCircleInterface
    {
        void AreaCircle();

    }
    interface ShapeSquareInterface
    {
        void AreaSquare();

    }
    interface ShapeTriangleInterface
    {
        void AreaTriangle();
  
    }
    class ShapesClass : ShapeCircleInterface,ShapeSquareInterface,ShapeTriangleInterface
    {
        double area;
        const double PI = 3.14;
        public void AreaCircle()
        {
            int radius;
            Console.WriteLine("\nEnter Radius of Circle");
            radius = Convert.ToInt32(Console.ReadLine());
            area = PI * (int)Math.Pow(radius, 2);
        }
        public void AreaSquare()
        {
            int side;
            Console.WriteLine("\nEnter Side of Square");
            side = Convert.ToInt32(Console.ReadLine());
            area = (int)Math.Pow(side, 2);
        }
        public void AreaTriangle()
        {
            int base_val,height;
            Console.WriteLine("\nEnter Base of Triangle");
            base_val = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Height of Triangle");
            height = Convert.ToInt32(Console.ReadLine());
            area = (base_val * height) / 2;
        }
        public void DisplayArea()
        {
            Console.WriteLine("Area : " + area);
        }
    }
}
