﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class InterfaceDemo
    {
        public static void Main()
        {
            SubB s = new SubB();
            s.Display();
            s.Display1();
            s.Display2();

            /*BaseA b1 = new BaseA();
            b1.Display1();
            */

            Console.ReadKey();
        }
    }
    interface Base1
    {
        void Display();

    }
    interface Base2
    {
        void Display2();

    }
    class BaseA
    {
        public void Display1()
        {
            Console.WriteLine("ccccI am in Display method of BaseA");
        }
    }
    class SubB : BaseA,Base1, Base2
    {
      public void Display()
        {
            Console.WriteLine("iiiiiI am in Display method of SubB");
        }
        public void Display2()
        {
            Console.WriteLine("2222I am in Display method of SubB");
        }
    }
}
