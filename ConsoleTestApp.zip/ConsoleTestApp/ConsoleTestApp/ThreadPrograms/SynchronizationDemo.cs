﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ConsoleTestApp
{
    class SynchronizationDemo
    {
        public static void Main()
        {
            Printer objPrinter = new Printer();
            Thread objThread = new Thread(objPrinter.PrintNumbers);
            objThread.Start();

            Thread objThread1 = new Thread(objPrinter.PrintNumbers);
            objThread1.Start();

            Console.ReadKey();
        }
    }
    class Printer
    {
        public void PrintNumbers()
        {
            lock(this)
            {
                for(int i=1;i<=10;i++)
                {
                    Thread.Sleep(100);
                    Console.WriteLine(i);
                }
            }
        }
    }
}
