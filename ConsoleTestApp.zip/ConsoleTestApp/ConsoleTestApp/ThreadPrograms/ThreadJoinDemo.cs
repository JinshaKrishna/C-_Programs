﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ConsoleTestApp
{
    class ThreadJoinDemo
    {
        public static void Main()
        {
            Thread objThread1 = new Thread(ThreadJoin.ChildThread1);
            Thread objThread2 = new Thread(ThreadJoin.ChildThread2);

            objThread1.Start();
            objThread2.Start();
            //objThread1.Join();
            objThread2.Join();
            Console.WriteLine("main Method Completed");
            Console.ReadKey();
        }
    }
    class ThreadJoin
    {
        public static void ChildThread1()
        {
            Console.WriteLine("Iam in Child Thread 1");
            for(int i=1;i<=10;i++)
            { 
                Console.Write(" " + i);
            }
            Console.WriteLine("\nChild Thread 1 Completed");
        }
        public static void ChildThread2()
        {
            Console.WriteLine("Iam in Child Thread 2");
            for (int i = 11; i <= 50; i++)
            {
                Thread.Sleep(200);
                Console.Write(" " + i);
            }
            Console.WriteLine("\nChild Thread 2 Completed");
        }
    }
}
