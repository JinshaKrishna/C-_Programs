﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ConsoleTestApp
{
    class ThreadTableDemo
    {
        public static void Main()
        {
            Table objTable1 = new Table(5,30);
            Thread objThread1 = new Thread(objTable1.GenerateTable);
            objThread1.Start();

            Table objTable2 = new Table(10,200);
            Thread objThread2 = new Thread(objTable2.GenerateTable);
            objThread2.Start();

            //Table objTable3 = new Table(3);
            //Thread objThread3 = new Thread(objTable3.GenerateTable);
            //objThread3.Start();

            Console.ReadKey();
        }
    }
    class Table
    {
        private int _number;
        private int _sleep;
        public Table(int target,int sleep)
        {
            _number = target;
            _sleep = sleep;
        }
        public void GenerateTable()
        {
                for (int mul = 1; mul <= 10; mul++)
                {
                    Thread.Sleep(_sleep);
                    Console.WriteLine("{0} * {1} = {2}", mul, _number, mul * _number);
                }
        }
    }
}
