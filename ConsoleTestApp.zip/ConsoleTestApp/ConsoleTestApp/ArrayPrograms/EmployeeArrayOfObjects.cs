﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class EmployeeArrayOfObjects
    {
        public static void Main()
        {
            int limit = 2;
            Employee[] arrayEmployee = new Employee[limit];
            Console.WriteLine("Enter Employee Details");
            for(int employee = 0;employee < arrayEmployee.Length;employee++)
            {
                Console.WriteLine("\nEnter Details of Employee {0}" ,employee+1);
                Console.WriteLine("******************************");
                arrayEmployee[employee] = new Employee();
                arrayEmployee[employee].ReadEmployee();
                //arrayEmployee[employee].Calculate();
            }
            Console.WriteLine("\n\nEmployee Details");
            for (int employee = 0; employee < arrayEmployee.Length; employee++)
            {
                Console.WriteLine("Details of Employee {0}", employee + 1);
                Console.WriteLine(arrayEmployee[employee]);
            }

            Console.ReadKey();
        }

    }
    class Employee
    {
        int employeeId, basicSalary;
        String name;
        public double hra, ta, da;
        public void ReadEmployee()
        {
            Console.Write("Enter Employee Id : ");
            employeeId = Convert.ToInt32(Console.ReadLine());
            Console.Write("\nEnter Employee Name : ");
            name = Console.ReadLine();
            Console.Write("\nEnter Employee Basic Salary : ");
            basicSalary = Convert.ToInt32(Console.ReadLine());
            hra = (20 / 100) * basicSalary;
            da = (70 / 100) * basicSalary;
            ta = (15 / 100) * basicSalary;
        }
        public override string ToString()
        {
            String output = "";
            output += "*******************************\n";
            output += "Employee ID : " + employeeId;
            output += "\nEmployee Name : " + name;
            output += "\nEmployee Basic Salary : " + basicSalary;
            output += "\nEmployee HRA : " + hra;
            output += "\nEmployee DA : " + da;
            output += "\nEmployee TA : " + ta;
            output += "\n*******************************\n";

            return output;
        }
        //public void Calculate()
        //{
        //    hra = (20 / 100) * basicSalary;
        //    da = (70 / 100) * basicSalary;
        //    ta = (15 / 100) * basicSalary;
        //}
    }
}
