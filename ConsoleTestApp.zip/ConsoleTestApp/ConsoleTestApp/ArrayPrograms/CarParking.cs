﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class CarParking
    {
        int[] parkingArea = new int[5];
        int parkingSlotNo;
        public void ParkCar()
        {
            bool flag = false;
            for(int parkingSlot = 0;parkingSlot < 5;parkingSlot++)
            {
                if(parkingArea[parkingSlot]==0)
                {
                    flag = true;
                    parkingArea[parkingSlot] = 1;
                    Console.WriteLine("\nYour Car is parked Successfully at Slot No : {0}.\n" , parkingSlot+1);
                    break;
                }
            }
            if(!flag)
            {
                Console.WriteLine("\n!!!... Sorry.. There is no Slot for Park your Car.\n");
            }
        }
        public void UnParkCar()
        {
            Console.WriteLine("\nPlease Enter the Parking slot number of your car Parked.");
            parkingSlotNo = Convert.ToInt32(Console.ReadLine());
            parkingSlotNo = parkingSlotNo - 1;
            if (parkingArea[parkingSlotNo] == 1)
            {
                parkingArea[parkingSlotNo] = 0;
                Console.WriteLine("\nYour Car is Unparked Successfully.\n");
            }
            else
            {
                Console.WriteLine("\n!!!... Sorry.. There is no Car Parked at this Slot.\n");
            }
        }
        public void ViewSlots()
        {
            bool flag = false;
            for (int parkingSlot = 0; parkingSlot < 5; parkingSlot++)
            {
                if (parkingArea[parkingSlot] == 0)
                {
                    flag = true;
                    Console.WriteLine("Slot No : " + parkingSlot);
                }
            }
            if(!flag)
            {
                Console.WriteLine("\n!!!... Sorry.. There is no Parking Slot available.\n");
            }
        }
        public static void Main()
        {
            CarParking objCarParking = new CarParking();
            int option;
            do
            {
                Console.WriteLine("**********************");
                Console.WriteLine("1. Park Car");
                Console.WriteLine("2. Unpark Car");
                Console.WriteLine("3. View Parking Slots");
                Console.WriteLine("4. Exit");
                Console.WriteLine("**********************");
                Console.WriteLine("Enter the Option (1-4)");
                option = Convert.ToInt32(Console.ReadLine());

                switch (option)
                {
                    case 1:
                        objCarParking.ParkCar();
                        break;
                    case 2:
                        objCarParking.UnParkCar();
                        break;
                    case 3:
                        objCarParking.ViewSlots();
                        break;
                    case 4:
                        System.Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("\n!!!... Wrong option , Please enter 1-4.");
                        break;
                }
            } while (true);

        }
    }
}
