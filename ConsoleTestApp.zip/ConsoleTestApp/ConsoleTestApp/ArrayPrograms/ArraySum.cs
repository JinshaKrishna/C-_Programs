﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class ArraySum
    {
        int numberOfElements, sum = 0;
        int[] arraySum;
        public void ReadArrayElements()
        {
            Console.WriteLine("Enter The Number of elements in the Array");
            numberOfElements = Convert.ToInt32(Console.ReadLine());
            arraySum = new int[numberOfElements];
            Console.WriteLine("Enter Array Elements"); 
            for (int index = 0; index < numberOfElements; index++)
            {
                arraySum[index] = Convert.ToInt32(Console.ReadLine());
            }
        }
        public void FindSum()
        {
            foreach (int index in arraySum)
            {
                sum = sum + index;
            }
        }
        public void DisplayArray()
        {
            Console.WriteLine("\n****************************");
            Console.WriteLine("The Input array is\n");
            for (int index = 0; index < numberOfElements; index++)
            {
                Console.Write(arraySum[index] + " " );
            }
            Console.WriteLine("\n\nSum of Elements in the Array : " + sum);
        }
        public static void Main()
        {
            ArraySum objArraySum = new ArraySum();
            objArraySum.ReadArrayElements();
            objArraySum.FindSum();
            objArraySum.DisplayArray();

            Console.ReadKey();
        }
    }
}
