﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class SumAndAverage
    {
        int[] numbers;
        int sum = 0,noOfElements;
        double average;
        public void ReadNumbers()
        {
            Console.WriteLine("Enter the Number of Elements in the Array");
            noOfElements = Convert.ToInt32(Console.ReadLine());
            numbers = new int[noOfElements];
            Console.WriteLine("Enter Elements in the Array");
            for (int index = 0; index < noOfElements; index++)
            {
                numbers[index] = Convert.ToInt32(Console.ReadLine());
            }
        }
        public void FindSumAndAverage()
        {
            for (int start = 0; start < noOfElements; start++)
            {
                sum = sum + numbers[start];
            }
            average = sum / noOfElements;
        }
        public void DisplayData()
        {
            Console.WriteLine("The Sum of the given Array : {0} ", sum);
            Console.WriteLine("The Average of the given Array : {0} ", average);
        }
        public static void Main()
        {
            SumAndAverage objSumAndAverage = new SumAndAverage();
            objSumAndAverage.ReadNumbers();
            objSumAndAverage.FindSumAndAverage();
            objSumAndAverage.DisplayData();

            Console.ReadKey();
        }
    }
}
