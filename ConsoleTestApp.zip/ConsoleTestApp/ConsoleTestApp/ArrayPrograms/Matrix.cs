﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Matrix
    {
        int row, column;
        int[,] values;

        public void ReadMatrix()
        {
            Console.Write("Enter The Number of Rows : ");
            row = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter The Number of Columns : ");
            column = Convert.ToInt32(Console.ReadLine());
            values = new int[row, column];
            Console.WriteLine("Enter The Elements of Matrix");
            for (int indexRow = 0; indexRow < row; indexRow++)
            {
                for (int indexColumn = 0; indexColumn < column; indexColumn++)
                {
                    values[indexRow, indexColumn] = Convert.ToInt32(Console.ReadLine());
                }
            }
        }
        public void FindSumMatrix(Matrix matrix1, Matrix matrix2)
        {
            if (matrix1.row != matrix2.row && matrix1.column != matrix2.column)
            {
                Console.WriteLine("Row and Column of both Matrices should be Equal");
            }
            else
            {
                row = matrix1.row;
                column = matrix1.column;
                values = new int[row, column];

                for (int indexRow = 0; indexRow < row; indexRow++)
                {
                    for (int indexColumn = 0; indexColumn < column; indexColumn++)
                    {
                        values[indexRow, indexColumn] = matrix1.values[indexRow, indexColumn] + matrix2.values[indexRow, indexColumn];

                    }

                }
            }
        }
        public void FindDifferenceMatrix(Matrix matrix1, Matrix matrix2)
        {
            if (matrix1.row != matrix2.row && matrix1.column != matrix2.column)
            {
                Console.WriteLine("Row and Column of both Matrices should be Equal");
            }
            else
            {
                row = matrix1.row;
                column = matrix1.column;
                values = new int[row, column];

                for (int indexRow = 0; indexRow < row; indexRow++)
                {
                    for (int indexColumn = 0; indexColumn < column; indexColumn++)
                    {
                        values[indexRow, indexColumn] = matrix1.values[indexRow, indexColumn] - matrix2.values[indexRow, indexColumn];

                    }

                }
            }
        }
        public void DisplayMatrix()
        {

            for (int indexRow = 0; indexRow < row; indexRow++)
            {
                for (int indexColumn = 0; indexColumn < column; indexColumn++)
                {
                    Console.Write(values[indexRow, indexColumn] + " ");
                }
                Console.WriteLine("\n");
            }
        }
        public static void Main()
        {
            Matrix matrix1 = new Matrix();
            Matrix matrix2 = new Matrix();
            Matrix matrix3 = new Matrix();
            Matrix matrix4 = new Matrix();

            Console.WriteLine("\nEnter Matrix 1");
            matrix1.ReadMatrix();
            Console.WriteLine("\nEnter Matrix 2");
            matrix2.ReadMatrix();

            Console.WriteLine("\n---------MATRIX 1----------");
            matrix1.DisplayMatrix();
            Console.WriteLine("\n---------MATRIX 2----------");
            matrix2.DisplayMatrix();

            Console.WriteLine("\n---------MATRIX 3----------");
            matrix3.FindSumMatrix(matrix1, matrix2);
            matrix3.DisplayMatrix();

            Console.WriteLine("\n---------MATRIX 4----------");
            matrix4.FindDifferenceMatrix(matrix1, matrix2); 
            matrix4.DisplayMatrix();


            Console.ReadKey();
        }
    }
}
