﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Sorting
    {
        int limit;
        int[] sort;
        public void ReadNumbers()
        {
            Console.WriteLine("Enter The limit of the Array ");
            limit = Convert.ToInt32(Console.ReadLine());
            sort = new int[limit];
            Console.WriteLine("Enter Array Elements");
            for (int index = 0; index < limit; index++)
            {
                sort[index] = Convert.ToInt32(Console.ReadLine());
            }
        }
        public void SortNumbers()
        {
            for (int start = 0; start < limit - 1; start++)
            {
                for (int next = start + 1; next < limit; next++)
                {
                    if (sort[start] > sort[next])
                    {
                        int temp = sort[start];
                        sort[start] = sort[next];
                        sort[next] = temp;
                    }
                }
            }
        }
        public void DisplayResult()
        { 
            Console.WriteLine("\n-------- Sorted Array ----------\n");
            for (int index = 0; index < limit; index++)
            {
                Console.Write(" " + sort[index]);
            }

        }
        public static void Main()
        {
            Sorting objSort = new Sorting();
            objSort.ReadNumbers();
            objSort.SortNumbers();
            objSort.DisplayResult();
            Console.ReadKey();
        }
    }
}
