﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class BinarySearch
    {
        int limit,number;
        int[] search;

        public void ReadNumbers()
        {
            Console.WriteLine("Enter The limit of the Array ");
            limit = Convert.ToInt32(Console.ReadLine());
            search = new int[limit];

            Console.WriteLine("Enter Array Elements");
            for (int index = 0; index < limit; index++)
            {
                search[index] = Convert.ToInt32(Console.ReadLine());
            }
        }


        public void SortNumbers()
        {
            for (int start = 0; start < limit - 1; start++)
            {
                for (int next = start + 1; next < limit; next++)
                {
                    if (search[start] > search[next])
                    {
                        int temp = search[start];
                        search[start] = search[next];
                        search[next] = temp;
                    }
                }
            }
        }


        public void SearchNumber()
        {
            Console.WriteLine("Enter the Number to be Searched ");
            number = Convert.ToInt32(Console.ReadLine());
            bool flag = false;
            int low = 0;
            int high = limit - 1;

            while (low <= high )
            {
                int middle = (high + low) / 2;
                
                if (search[middle] == number)
                {
                    flag = true;
                    Console.WriteLine("Number {0} Exists at location {1}", number, middle+1);
                    break;
                }
                if(number < search[middle])
                {
                    high = middle - 1;
                }
                else
                {
                    low = middle + 1;
                }
            }
            if (!flag)
            {
                Console.WriteLine("Number {0} does not Exist in the Array", number);
            }
        }

        public static void Main()
        {
            BinarySearch objBinarySearch = new BinarySearch();
            objBinarySearch.ReadNumbers();
            objBinarySearch.SortNumbers();
            objBinarySearch.SearchNumber();

            Console.ReadKey();
        }
    }
}

