﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class AbstractDemo
    {
        public static void Main()
        {
            XYZ xyz = new XYZ();
            xyz.Display();
            xyz.Check();

            int sum = ABC.FindSum(10, 20);
            Console.WriteLine("Sum : " + sum);
            xyz.Print();

            Console.ReadKey();
        }
    }
    abstract class ABC
    {
        //int val1;
        //static int val2;
        public abstract void Display();
        public static int FindSum(int v1,int v2)
        {
            return v1 + v2;
        }
        public void Print()
        {
            Console.WriteLine("I am in Print Method");
        }
    }
    class XYZ : ABC
    {
        //int val3;
        public override void Display()
        {
            Console.WriteLine("I am in Display Method");
        }
        public void Check()
        {
            Console.WriteLine("I am in Check Method");
            
        }
    }
}
