﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class DelegateEmployee
    {
        public static void Main()
        {
            List<EmployeePromotion> employeesList = new List<EmployeePromotion>();
            employeesList.Add(new EmployeePromotion { ID = 101, Name = "Jinsha", Experience = 2, Salary = 20000 });
            employeesList.Add(new EmployeePromotion { ID = 102, Name = "Akhil", Experience = 6, Salary = 50000 });
            employeesList.Add(new EmployeePromotion { ID = 103, Name = "Anjana", Experience = 3, Salary = 25000 });
            employeesList.Add(new EmployeePromotion { ID = 104, Name = "Ammu", Experience = 5, Salary = 34000 });

            Console.WriteLine("List of Employees eligible for Promotion");
            EmployeePromotion.GetPromotedList(employeesList);

            Console.ReadKey();
        }
    }
    class EmployeePromotion
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public int Experience { get; set; }
        public int Salary { get; set; }

        public static void GetPromotedList(List<EmployeePromotion> employees)
        {
            foreach(EmployeePromotion employee in employees)
            {
                if(employee.Experience >= 5)
                {
                    Console.WriteLine("\nEmployee ID : {0}", employee.ID);
                    Console.WriteLine("Employee Name : {0}", employee.Name);
                    Console.WriteLine("Employee Experience : {0}", employee.Experience);
                    Console.WriteLine("Employee Salary : {0}", employee.Salary);
                }
            }
        }
    }
}
