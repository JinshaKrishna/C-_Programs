﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    public delegate void Find(int value1, int value2);
    class DelegateDemo
    {
        static void Main()
        {
            CalculatorAdd objAdd = new CalculatorAdd();
            Find objFind = new Find(CalculatorAdd.Sum);
            objFind += CalculatorDiff.Sub;
            objFind += objAdd.Mul;
            objFind -= CalculatorDiff.Sub;
            objFind(3, 7);
            Console.ReadKey();
        }
    }
    class CalculatorAdd
    {
        public static void Sum(int num1,int num2)
        {
            Console.WriteLine(num1 + num2);
        }
        public void Mul(int num1, int num2)
        {
            Console.WriteLine(num1 * num2);
        }
    }
    class CalculatorDiff
    {
        public static void Sub(int num1, int num2)
        {
            Console.WriteLine(num1 - num2);
        }
    }
}
