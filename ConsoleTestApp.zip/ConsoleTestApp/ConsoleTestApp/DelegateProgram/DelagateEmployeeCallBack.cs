﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    public delegate bool IsPromotableDelagate(Employee1 employee);
    class DelagateEmployeeCallBack
    {
        public static void Main()
        {
            
            List<Employee1> employeesList = new List<Employee1>();
            employeesList.Add(new Employee1 { ID = 101, Name = "Jinsha", Experience = 2, Salary = 20000 });
            employeesList.Add(new Employee1 { ID = 102, Name = "Akhil", Experience = 6, Salary = 50000 });
            employeesList.Add(new Employee1 { ID = 103, Name = "Anjana", Experience = 3, Salary = 25000 });
            employeesList.Add(new Employee1 { ID = 104, Name = "Ammu", Experience = 5, Salary = 34000 });

            IsPromotableDelagate objIsPromotableDelegate = new IsPromotableDelagate(IsPromotable);
            Console.WriteLine("List of Employees eligible for Promotion");
            Employee1.GetPromotedList(employeesList,objIsPromotableDelegate);

            Console.ReadKey();
        }
        public static bool IsPromotable(Employee1 employee)
        {
            bool eligible = false;
            if(employee.Experience >= 4 && employee.Salary > 30000)
            {
                eligible = true;
            }
            return eligible;
        }
    }
    public class Employee1
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public int Experience { get; set; }
        public int Salary { get; set; }

        public static void GetPromotedList(List<Employee1> employees,IsPromotableDelagate isPromotableDelagate)
        {
            foreach (Employee1 employee in employees)
            {
                if (isPromotableDelagate(employee))
                {
                    Console.WriteLine("\nEmployee ID : {0}", employee.ID);
                    Console.WriteLine("Employee Name : {0}", employee.Name);
                    Console.WriteLine("Employee Experience : {0}", employee.Experience);
                    Console.WriteLine("Employee Salary : {0}", employee.Salary);
                }
            }
        }
    }
}
