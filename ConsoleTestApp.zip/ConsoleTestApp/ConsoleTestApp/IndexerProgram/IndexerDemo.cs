﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class IndexerDemo
    {
        public static void Main()
        {
            Marks mark1 = new Marks();
            mark1[0] = 1;
            for(int i = 1;i < 10;i++)
            {
                mark1[i] += 10;
            }
            for (int i = 0; i < 10; i++)
            {
                Console.Write(mark1[i] + " ");
            }
            Console.ReadKey();
        }
    }
    class Marks
    {
        static int noOfStudents = 10;
        public int[] mark = new int[noOfStudents];

        public int this[int index]
        {
            get {return mark[index]; }
            set {mark[index]= value; }
        }
    }
}
