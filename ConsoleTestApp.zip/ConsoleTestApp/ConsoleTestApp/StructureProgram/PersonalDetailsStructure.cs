﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.StructureProgram
{
    public struct Personal
    {
        public int id;
        public string name;
        public string email;
        public double mobileNo;
        public string dob;
    }
    class PersonalDetails
    {
        Personal objPersonal;
        public bool ReadDetails()
        {
            Console.WriteLine("-----------------------------------------");
            Console.WriteLine("    Please Enter the Details   ");
            Console.WriteLine("-----------------------------------------");
            Console.Write("Enter ID : ");
            objPersonal.id = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Name : ");
            objPersonal.name = Console.ReadLine();
            Console.Write("Enter Email ID : ");
            objPersonal.email = Console.ReadLine();
            Console.Write("Enter Mobile No. : ");
            objPersonal.mobileNo = Convert.ToInt64(Console.ReadLine());
            Console.Write("Enter Date Of Birth (DD/MM/YYYY) : ");
            objPersonal.dob = Console.ReadLine();
            string afterDate = objPersonal.dob[2].ToString();
            string afterMonth = objPersonal.dob[5].ToString();
            if(afterDate == "/" && afterMonth == "/")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public int CalculateAge()
        {
            string lastFourDigits = objPersonal.dob.Substring((objPersonal.dob.Length - 4), 4);
            int year = Convert.ToInt32(lastFourDigits);
            int age = 2019 - year;
            Console.WriteLine(age);
            return age;
        }
        public void Display(int age)
        {
            Console.WriteLine("----------------------------------------------");
            Console.WriteLine("            PERSONAL DETAILS                  ");
            Console.WriteLine("----------------------------------------------");
            Console.WriteLine(" ID :\t" + objPersonal.id);
            Console.WriteLine(" Name :\t" + objPersonal.name);
            Console.WriteLine(" Email ID :\t" + objPersonal.email);
            Console.WriteLine(" Mobile No. :\t" + objPersonal.mobileNo);
            Console.WriteLine(" Age :\t" + age);
            Console.WriteLine("----------------------------------------------");
        }
    }
    class PersonalDetailsStructure
    {
       public static void Main()
       {
            PersonalDetails obj = new PersonalDetails();
            bool flag = obj.ReadDetails();
            do
            {
                if (!flag)
                {
                    Console.WriteLine("!!..Sorry.. Please Enter DOB in Required format");
                    bool flag1 = obj.ReadDetails();
                }
                else
                {
                    int ageCalculated = obj.CalculateAge();
                    obj.Display(ageCalculated);
                }
            } while (true);

       }
    }
}
