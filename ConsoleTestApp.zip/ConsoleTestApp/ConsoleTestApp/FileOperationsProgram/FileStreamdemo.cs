﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ConsoleTestApp
{
    class FileStreamdemo
    {
        public static void Main()
        {
            FileStream data1file = new FileStream("D:\\JINSHA\\data\\data1.txt",FileMode.OpenOrCreate);
            for(int num=65; num <= 90; num++)
            {
                data1file.WriteByte((byte)num);
            }
            data1file.Close();
            Console.WriteLine("File Created Successfully");
            Console.WriteLine("File Read Operation...");
            FileStream data1OutFile = new FileStream("D:\\JINSHA\\data\\data1.txt", FileMode.OpenOrCreate);
            int i = 0;
            while((i= data1OutFile.ReadByte())!=-1)
            {
                Console.WriteLine((char)i);
            }
            data1OutFile.Close();

            Console.ReadKey();
        }
    }
}
