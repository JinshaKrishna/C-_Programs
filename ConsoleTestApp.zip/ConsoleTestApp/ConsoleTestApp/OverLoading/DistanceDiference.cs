﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class DistanceDiference
    {
        int feet, inches;
        public void ReadDistance()
        {
            Console.WriteLine("Enter feet");
            feet = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter inches");
            inches = Convert.ToInt32(Console.ReadLine());
        }
        public void DisplayDistance()
        {
            Console.WriteLine("Feet : {0}   Inches : {1}", feet, inches);
        }
        public void DifferenceDistance(DistanceDiference d1, DistanceDiference d2)
        {
            if(d1.feet>d2.feet && d1.inches>d2.inches)
            {
                feet = d1.feet - d2.feet;
                inches = d1.inches - d2.inches;
            }
            else if(d1.feet < d2.feet && d1.inches < d2.inches)
            {
                feet = d2.feet - d1.feet;
                inches = d2.inches - d1.inches;
            }
            else if(d1.feet<d2.feet && d1.inches>d2.inches)
            {
                feet = d2.feet - d1.feet;
                inches = d1.inches - d2.inches;
            }
            else
            {
                d1.inches = 12 + d1.inches;
                d1.feet = d1.feet - 1;
                feet = d1.feet - d2.feet;
                inches = d1.inches - d2.inches;

            }
        }
        public static void Main()
        {
            DistanceDiference distance1 = new DistanceDiference();
            DistanceDiference distance2 = new DistanceDiference();
            DistanceDiference distance3 = new DistanceDiference();
           // DistanceDiference distance4;
           // DistanceDiference distance5;
            Console.WriteLine("Enter the Value of Distance 1");
            Console.WriteLine("------------------------------");
            distance1.ReadDistance();
            Console.WriteLine("\nEnter the Value of Distance 2");
            Console.WriteLine("------------------------------");
            distance2.ReadDistance();
            Console.WriteLine("\nDistance 1");
            Console.WriteLine("------------");
            distance1.DisplayDistance();
            Console.WriteLine("Distance 2");
            Console.WriteLine("------------");
            distance2.DisplayDistance();
            distance3.DifferenceDistance(distance1, distance2);            
            Console.WriteLine("Distance 3");
            Console.WriteLine("------------");
            distance3.DisplayDistance();

            /*Console.WriteLine("\nDistance 1");
            Console.WriteLine("------------");
            distance1.DisplayDistance();
            Console.WriteLine("Distance 2");
            Console.WriteLine("------------");
            distance2.DisplayDistance();
            distance4 = distance1.DifferenceDistance(distance2);            
            Console.WriteLine("Distance 3");
            Console.WriteLine("------------");
            distance4.DisplayDistance();

            Console.WriteLine("\nDistance 1");
            Console.WriteLine("------------");
            distance1.DisplayDistance();
            Console.WriteLine("Distance 2");
            Console.WriteLine("------------");
            distance2.DisplayDistance();
            distance5 = distance1 - distance2;         
            Console.WriteLine("Distance 3");
            Console.WriteLine("------------");
            distance5.DisplayDistance();*/

            Console.ReadKey();
        }
        /*public DistanceDiference DifferenceDistance(DistanceDiference d1)
        {
            DistanceDiference d = new DistanceDiference();
            if (feet > d1.feet)
            {
                d.feet = feet - d1.feet;
            }
            else
            {
                d.feet = d1.feet - feet;
            }
            if (inches > d1.inches)
            {
                d.inches = inches - d1.inches; ;
            }
            else
            {
                d.inches = d1.inches - inches;
            }
            return d;
        }
        public static DistanceDiference operator -(DistanceDiference d1, DistanceDiference d2)
        {
            DistanceDiference d = new DistanceDiference();
            if (d1.feet > d2.feet)
            {
                d.feet = d1.feet - d2.feet;
            }
            else
            {
                d.feet = d2.feet - d1.feet;
            }
            if (d1.inches > d2.inches)
            {
                d.inches = d1.inches - d2.inches; ;
            }
            else
            {
                d.inches = d2.inches - d1.inches;
            }
            return d;
        }*/
    }
}
