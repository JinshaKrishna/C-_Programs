﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class ComplexNumber
    {
        int real, imaginary;
        public void ReadComplexNumber()
        {
            Console.WriteLine("Enter Real part");
            real = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Imaginary part");
            imaginary = Convert.ToInt32(Console.ReadLine());
        }
        public void DisplayComplexNumber()
        {
            Console.WriteLine("Complex Number : {0}+{1}i", real, imaginary);
        }
        public static ComplexNumber operator + (ComplexNumber num1, ComplexNumber num2)
        {
            ComplexNumber cn = new ComplexNumber();
            cn.real = num1.real + num2.real;
            cn.imaginary = num1.imaginary + num2.imaginary;
            return cn;
        }
        public static void Main()
        {
            ComplexNumber objComplexNumber1 = new ComplexNumber();
            ComplexNumber objComplexNumber2 = new ComplexNumber();
            ComplexNumber objComplexNumber3;

            Console.WriteLine("Enter the Value of Complex Number 1");
            Console.WriteLine("------------------------------");
            objComplexNumber1.ReadComplexNumber();
            Console.WriteLine("\nEnter the Value of Complex Number 2");
            Console.WriteLine("------------------------------");
            objComplexNumber2.ReadComplexNumber();
            objComplexNumber3 = objComplexNumber1 + objComplexNumber2;
            Console.WriteLine("\nComplex Number 1");
            Console.WriteLine("------------");
            objComplexNumber1.DisplayComplexNumber();
            Console.WriteLine("Complex Number 2");
            Console.WriteLine("------------");
            objComplexNumber2.DisplayComplexNumber();
            Console.WriteLine("Complex Number 3");
            Console.WriteLine("------------");
            objComplexNumber3.DisplayComplexNumber();

            Console.ReadKey();
        }
    }
}