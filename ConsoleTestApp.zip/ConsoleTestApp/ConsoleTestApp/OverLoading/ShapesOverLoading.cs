﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class ShapesOverLoading
    {
        double area;
        const double PI = 3.14;
        double radius;
        int side, tri_base, height;
        public void DisplayAreaCircle(double radius)
        {
            this.radius = radius;
            area = PI * radius * radius;
            Console.WriteLine("\nArea of Circle with Radius {0} : {1}", radius, area);
        }
        public void DisplayAreaSquare(int side)
        {
            this.side=side;
            area = side * side;
            Console.WriteLine("\nArea of Square with Side{0} : {1}", side, area);
        }
        public void DisplayAreaTriangle(int tri_base,int height)
        {
            this.tri_base = tri_base;
            this.height = height;
            area = (tri_base * height) / 2;
            Console.WriteLine("\nArea of Triangle with Base {0} and Height {1} : {2}", tri_base, height, area);
        }
        public static void Main()
        {
            ShapesOverLoading objShapes = new ShapesOverLoading();
            Console.WriteLine("\n-----------CIRCLE-----------");
            objShapes.DisplayAreaCircle(3.2);
            Console.WriteLine("\n-----------SQUARE-----------");
            objShapes.DisplayAreaSquare(3);
            Console.WriteLine("\n-----------TRIANGLE-----------");
            objShapes.DisplayAreaTriangle(5,3);

            Console.ReadKey();
        }
    }
}
