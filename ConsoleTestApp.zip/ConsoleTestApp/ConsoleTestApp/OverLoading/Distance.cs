﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Distance
    {
        int feet, inches;
        public void ReadDistance()
        {
            Console.WriteLine("Enter feet");
            feet = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter inches");
            inches = Convert.ToInt32(Console.ReadLine());
        }
        public void DisplayDistance()
        {
            Console.WriteLine("Feet : {0}   Inches : {1}", feet, inches);
        }
        public void AddDistance(Distance d1,Distance d2)
        {
            feet = d1.feet + d2.feet;
            inches = d1.inches + d2.inches;

            if(inches>=12)
            {
                feet++;
                inches = inches % 12;
            }
        }
        public static void Main()
        {
            Distance distance1 = new Distance();
            Distance distance2 = new Distance();
            Distance distance3 = new Distance();
            Distance distance4;
            Distance distance5;
            Console.WriteLine("Enter the Value of Distance 1");
            Console.WriteLine("------------------------------");
            distance1.ReadDistance();
            Console.WriteLine("\nEnter the Value of Distance 2");
            Console.WriteLine("------------------------------");
            distance2.ReadDistance();
            distance3.AddDistance(distance1, distance2);
            Console.WriteLine("\nDistance 1");
            Console.WriteLine("------------");
            distance1.DisplayDistance();
            Console.WriteLine("Distance 2");
            Console.WriteLine("------------");
            distance2.DisplayDistance();
            Console.WriteLine("Distance 3");
            Console.WriteLine("------------");
            distance3.DisplayDistance();

            distance4 = distance1.AddDistance(distance2);
            Console.WriteLine("\nDistance 1");
            Console.WriteLine("------------");
            distance1.DisplayDistance();
            Console.WriteLine("Distance 2");
            Console.WriteLine("------------");
            distance2.DisplayDistance();
            Console.WriteLine("Distance 3");
            Console.WriteLine("------------");
            distance4.DisplayDistance();

            distance5 = distance1 + distance2;
            Console.WriteLine("\nDistance 1");
            Console.WriteLine("------------");
            distance1.DisplayDistance();
            Console.WriteLine("Distance 2");
            Console.WriteLine("------------");
            distance2.DisplayDistance();
            Console.WriteLine("Distance 3");
            Console.WriteLine("------------");
            distance5.DisplayDistance();

            Console.ReadKey();
        }
        public Distance AddDistance(Distance d1)
        {
            Distance d = new Distance();
            d.feet = feet + d1.feet;
            d.inches = inches + d1.inches;
            if (d.inches >= 12)
            {
                d.feet++;
                d.inches = d.inches % 12;
            }
            return d;
        }
        public static Distance operator +(Distance d1,Distance d2)
        {
            Distance d = new Distance();
            d.feet = d1.feet + d2.feet;
            d.inches = d1.inches + d2.inches;
            if (d.inches >= 12)
            {
                d.feet++;
                d.inches = d.inches % 12;
            }
            return d;
        }
    }
    
}
