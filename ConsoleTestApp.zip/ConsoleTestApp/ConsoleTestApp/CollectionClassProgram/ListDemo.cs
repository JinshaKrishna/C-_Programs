﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace ConsoleTestApp
{
    class ListDemo
    {
        public static void Main()
        {
            List<string> names = new List<string>();
            names.Add("anjana");
            names.Add("jinsha");
            names.Add("sanoob");
            names.Add("ashanth");
            names.Add("abhishesk");
            //names.Remove("jinsha");
            //names.RemoveAt(0);
            //names.RemoveRange(3, 2);
            //names.Reverse();
            names.Sort();
            names.Insert(5, "sanooj");

            foreach (var name in names)
            {
                Console.WriteLine(name);
            }
            Console.ReadKey();
        }
        public static void DemoProgram()
        {
            Hashtable objHashTable = new Hashtable();
            objHashTable.Add("001", "jinsha");


        }
    }
    
}
