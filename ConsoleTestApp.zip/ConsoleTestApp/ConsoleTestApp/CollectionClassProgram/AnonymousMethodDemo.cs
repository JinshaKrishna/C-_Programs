﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    public delegate void Print(int value);
    class AnonymousMethodDemo
    {
        public static void PrintHelperMethod(Print printDel,int val)
        {
            val += 10;
            printDel(val);
        }
        public static void Main()
        {
            
            PrintHelperMethod( delegate (int val)
              {
                  Console.WriteLine("Inside Anonymous method. Value : {0}", val);
              },100);

            Console.ReadKey();
        }

    }
}
