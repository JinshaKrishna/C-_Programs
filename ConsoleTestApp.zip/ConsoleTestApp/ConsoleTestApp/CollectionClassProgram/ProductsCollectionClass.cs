﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace ConsoleTestApp
{
    class ProductsCollectionClass
    {
        public static void Main()
        {
            Hashtable products = new Hashtable();
            Hashtable cart = new Hashtable() ;
            products.Add(1, new Item(101, "Pista", 450));
            products.Add(2, new Item(102, "Nuts", 320));
            products.Add(3, new Item(103, "Soap", 50));
            products.Add(4, new Item(104, "Rice", 600));
            products.Add(5, new Item(105, "Cake", 150));
            Item item ;
            int option;
            do
            {
                Console.WriteLine("**********************");
                Console.WriteLine("1. Add Cart");
                Console.WriteLine("2. View Cart");
                Console.WriteLine("3. Checkout");
                Console.WriteLine("4. Exit");
                Console.WriteLine("**********************");
                Console.WriteLine("Enter the Option (1-4)");
                option = Convert.ToInt32(Console.ReadLine());
                
                switch (option)
                {
                    case 1:
                        Console.WriteLine("                        PRODUCT DETAILS                         ");
                        Console.WriteLine("------------------------------------------------------");
                        Console.WriteLine(" Product ID\t Product Name\t Unit Price");
                        Console.WriteLine("------------------------------------------------------");
                        ICollection keys = products.Keys;
                        foreach (int key in keys)
                        { 
                            item = ((Item)products[key]);
                            Console.WriteLine(" " + item.ProductID + "\t\t  " + item.ProductName + "\t\t  " + item.UnitPrice);
                        }
                        Console.WriteLine("------------------------------------------------------");
                    start:  Console.WriteLine("Enter Product ID");
                        int product_ID = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter Product Quantity");
                        int quantity = Convert.ToInt32(Console.ReadLine());
                        bool flag = false;
                        foreach (int key in keys)
                        {
                             item = ((Item)products[key]);
                             if (item.ProductID == product_ID)
                             {
                                 int amount = item.UnitPrice * quantity;
                                 string productName = item.ProductName;
                                 int unitPrice = item.UnitPrice;
                                 cart.Add(key, new Item(product_ID, productName, quantity, unitPrice, amount));
                                 Console.WriteLine("Product added to Cart Successfully");
                             }
                            else
                            {
                                flag = true;
                            }
                        }
                        if(flag)
                        {
                            Console.WriteLine("!!! Sorry.. No Proucts available with this Product ID");
                        }
                        Console.Write("Do you want to add more products to the cart ? (Y / N) : ");
                        string moreItemAdd = Console.ReadLine();
                        if (moreItemAdd == "Y")
                        {
                            goto start;
                        }
                        break;
                    case 2:
                        ICollection keysCart = cart.Keys;
                        foreach (int key in keysCart)
                        {
                            Console.WriteLine("******************************\n", key);
                            item = ((Item)cart[key]);
                            Console.WriteLine("------------------------------------------------------");
                            Console.WriteLine(" Product ID\t Quantity\t Unit Price");
                            Console.WriteLine("------------------------------------------------------");
                            Console.WriteLine(" " + item.ProductID + "\t\t  " + item.Quantity + "\t\t  " + item.UnitPrice);
                        }
                        Console.WriteLine("------------------------------------------------------");
                        break;
                    case 3:
                        Console.WriteLine("                        PRODUCTS PURCHASED                         ");
                        ICollection keyCart = cart.Keys;
                        Console.WriteLine("-----------------------------------------------------------------------");
                        Console.WriteLine(" Product ID\t Product Name\t Quantity\t Unit Price\t Amount");
                        Console.WriteLine("-----------------------------------------------------------------------");
                        int totalAmount = 0;
                        foreach (int key in keyCart)
                        {
                            item = ((Item)cart[key]);
                            totalAmount = totalAmount + item.Amount;
                            Console.WriteLine(" "+ item.ProductID + "\t\t  " + item.ProductName + "\t\t  " + item.Quantity + "\t\t  " + item.UnitPrice + "\t\t  " + item.Amount);
                        }
                        Console.WriteLine("-----------------------------------------------------------------------");
                        Console.WriteLine("\nTotal Amount = " + totalAmount  + "\n");
                        break;
                    case 4:
                        System.Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("\n!!!... Wrong option , Please enter 1-4.");
                        break;
                }
            } while (true);
        }
    }
    public class Item
    {
        public int ProductID { get; set; }
        public string ProductName { get; set; }
        public int UnitPrice { get; set; }
        public int Quantity { get; set; }
        public int Amount { get; set; }

        public Item(int id,string name,int price)
        {
            ProductID = id;
            ProductName = name;
            UnitPrice = price;
        }
        public Item(int id,string productName, int quantity,int unitPrice,int amount)
        {
            ProductID = id;
            ProductName = productName;
            Quantity = quantity;
            UnitPrice = unitPrice;
            Amount = amount;
        }
        public void AddCart()
        {
            Console.WriteLine("Enter Product Key");
            int key = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Product Quantity");
            int quantity = Convert.ToInt32(Console.ReadLine());
            
        }
       
    }
}
