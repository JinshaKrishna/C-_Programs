﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class NcrValue
    {
        int n, r,ncrValue;
        public void ReadData()
        {
            Console.WriteLine("Enter the Number of Items");
            n = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Numbr of items chosen at a time");
            r = Convert.ToInt32(Console.ReadLine());
        }
        public void FindNcrValue()
        {
            ncrValue=FindFactorial(n)/((FindFactorial(r))*(FindFactorial(n-r)));
        }
        public int FindFactorial(int num)
        {
            int factorial = 1;
            for (int i = 1; i <= num; i++)
            {
                factorial = factorial * i;
            }
            return factorial;
        }
        public void DisplayData()
        {
            Console.WriteLine("When {0} items are chosen from a number of {1} item, The nCr value will be {2}", r, n, ncrValue);
        }
        public static void Main(string[] args)
        {
            NcrValue objNcrValue = new NcrValue();
            objNcrValue.ReadData();
            objNcrValue.FindNcrValue();
            objNcrValue.DisplayData();
            Console.ReadKey();
        }
    }
}
