﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class FibonacciRecursion
    {
        int noOfElements;
        public int ReadData()
        {
            Console.WriteLine("Enter the Number of Elements in the Series");
            noOfElements = Convert.ToInt32(Console.ReadLine());
            return noOfElements;
        }
        public void DisplayFibonacciSeries(int first,int second,int count)
        {
            Console.Write(first + " ");
            count++;
            if (count != noOfElements)
            {
                DisplayFibonacciSeries(second, first + second, count);
            }
        }
        public static void Main()
        {
            FibonacciRecursion objFibonacciRecursion = new FibonacciRecursion();
            int num = objFibonacciRecursion.ReadData();
            Console.WriteLine("\nFibonacci Series with {0} Elements\n", num);
            objFibonacciRecursion.DisplayFibonacciSeries(0, 1, 0);

            Console.ReadKey();
        }
    }
}
