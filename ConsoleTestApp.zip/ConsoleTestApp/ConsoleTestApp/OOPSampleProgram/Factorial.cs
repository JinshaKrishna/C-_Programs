﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Factorial
    {
        int n, factorial=1;
        public void ReadNumber()
        {
            Console.WriteLine("Enter the Number");
            n = Convert.ToInt32(Console.ReadLine());
        }
        public void FindFactorial()
        {
           for(int i = 1;i <= n;i++)
            {
                factorial = factorial * i;
            }
        }
        public void DisplayResult()
        {
            Console.WriteLine("\nFactorial = " + factorial);
        }
        public static void Main(string[] args)
        {
            Factorial objfact = new Factorial();
            objfact.ReadNumber();
            objfact.FindFactorial();
            objfact.DisplayResult();
            Console.ReadKey();
        }
    }
}
