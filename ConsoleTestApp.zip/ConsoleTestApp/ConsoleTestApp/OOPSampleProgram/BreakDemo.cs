﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class BreakDemo
    {
        public static void Main()
        {
            int a = 10;
            while(a<20)
            {
                Console.WriteLine(a);
                a++;
                if(a>15)
                {
                    break;
                }
            }
            Console.ReadKey();
        }
    }
}
