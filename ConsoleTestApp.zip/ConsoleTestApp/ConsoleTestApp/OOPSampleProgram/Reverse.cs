﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Reverse
    {
        int number, reverse=0;
        public void ReadData()
        {
            Console.WriteLine("Enter the Number");
            number = Convert.ToInt32(Console.ReadLine());
        }
        public void FindDigitSum()
        {
            int n = number;
            int lastDigit;
            do
            {
                lastDigit = n % 10;
                reverse = reverse * 10 + lastDigit;
                n /= 10;
            } while (n > 0);
        }
        public void DisplayData()
        {
            Console.WriteLine("The Reverse of the given number {0} is {1} ", number, reverse);
            Console.ReadKey();
        }
        public static void Main(string[] args)
        {
            Reverse objReverse = new Reverse();
            objReverse.ReadData();
            objReverse.FindDigitSum();
            objReverse.DisplayData();
            Console.ReadKey();
        }
    }
}
