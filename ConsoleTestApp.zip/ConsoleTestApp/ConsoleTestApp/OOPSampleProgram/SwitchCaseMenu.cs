﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class SwitchCaseMenu
    {
        public static void Main()
        {
            int option;
            do
            {
                Console.WriteLine("**********************");
                Console.WriteLine("1. Digit Sum");
                Console.WriteLine("2. Check Prime");
                Console.WriteLine("3. Exit");
                Console.WriteLine("**********************");
                Console.WriteLine("Enter the Option (1-3)");
                option = Convert.ToInt32(Console.ReadLine());

                switch (option)
                {
                    case 1:
                        DigitSum objDigitSum1 = new DigitSum();
                        objDigitSum1.ReadData();
                        objDigitSum1.FindDigitSum();
                        objDigitSum1.DisplayData();
                        break;
                    case 2:
                        PrimeOrNot objPrimeOrNot = new PrimeOrNot();
                        objPrimeOrNot.ReadData();
                        objPrimeOrNot.FindResult();
                        objPrimeOrNot.DisplayResult();
                        break;
                    case 3:
                        System.Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Wrong option , Please enter 1-3");
                        break;
                }
            } while (true);
        }
    }
}
