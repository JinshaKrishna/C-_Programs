﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class DigitSum
    {
        int number;
        int digitSum=0;
        public void ReadData()
        {
            Console.WriteLine("Enter the Number");
            number = Convert.ToInt32(Console.ReadLine());
        }
        public void FindDigitSum()
        {
            int n = number;
            int lastDigit;
            do
            {
                lastDigit = n % 10;
                digitSum += lastDigit;
                n /= 10;
            } while (n > 0);
        }
        public void DisplayData()
        {
            Console.WriteLine("The Digit Sum of the given number {0} is {1} ", number, digitSum);
            Console.ReadKey();
        }
        public static void Main(string[] args)
        {
            DigitSum objDigitSum = new DigitSum();
            objDigitSum.ReadData();
            objDigitSum.FindDigitSum();
            objDigitSum.DisplayData();
            Console.ReadKey();
        }
    }
}
