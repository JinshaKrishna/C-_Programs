﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class PrimeOrNot
    {
        int p;
        string result;
        public void ReadData()
        {
            Console.WriteLine("Enter the Number");
            p = Convert.ToInt32(Console.ReadLine());
        }
        public void FindResult()
        {
            bool flag = true;
            for (int no = 2; no < p; no++)
            {
                
                if(p % no == 0)
                {
                    flag = false;
                    break;
                }
            }
            if(flag)
            {
                result = "prime";
            }
            else
            {
                result = "not prime";
            }
        }
        public void DisplayResult()
        {
            Console.WriteLine("The given Number {0} is {1}",p,result);
        }
        public static void Main(string[] args)
        {
            PrimeOrNot objprime = new PrimeOrNot();
            objprime.ReadData();
            objprime.FindResult();
            objprime.DisplayResult();
            Console.ReadKey();
        }
    }
}
