﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class BinaryToDecimal
    {
        int binary_val;
        int decimal_val=0;
        public void ReadData()
        {
            Console.WriteLine("Enter the Binary number");
            binary_val = Convert.ToInt32(Console.ReadLine());
        }
        public void FindDecimal()
        {
            int base_val = 1,remainder;
            int num = binary_val;
            while(num>0)
            {
                remainder = num % 10;
                decimal_val = decimal_val + remainder * base_val;
                num = num / 10;
                base_val = base_val * 2;
            }
        }
        public void DisplayData()
        {
            Console.WriteLine("The Decimal Equivalent of the given Binary number {0} is {1} ", binary_val, decimal_val);
            Console.ReadKey();
        }
        public static void Main(string[] args)
        {
            BinaryToDecimal objBinToDec = new BinaryToDecimal();
            objBinToDec.ReadData();
            objBinToDec.FindDecimal();
            objBinToDec.DisplayData();
            Console.ReadKey();
        }
    }
}
