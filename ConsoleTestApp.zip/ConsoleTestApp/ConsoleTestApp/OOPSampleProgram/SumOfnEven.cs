﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class SumOfnEven
    {
        int n,sum=0;
        public void ReadLimit()
        {
            Console.WriteLine("Enter the Limit");
            n = Convert.ToInt32(Console.ReadLine());
        }
        public void FindResult()
        {
            for(int i = 2;i <= n;i = i+2)
            {
                sum = sum + i;
            } 
        }
        public void DisplayResult()
        {
            Console.WriteLine("\nSum of N even numbers = " + sum);
        }
        public static void Main(string[] args)
        {
            SumOfnEven objsumeven = new SumOfnEven();
            objsumeven.ReadLimit();
            objsumeven.FindResult();
            objsumeven.DisplayResult();
            Console.ReadKey();
        }
    }
}
