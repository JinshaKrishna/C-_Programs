﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Pattern2
    {
        int number = 5;
        public void MakePattern()
        {
            for (int count = 1; count <= number; count++)
            {
                for (int p_no = 1; p_no <= count; p_no++)
                {
                    Console.Write(p_no);
                }
                Console.WriteLine("\n");
            }
        }
        public static void Main()
        {
            Pattern2 objpt2 = new Pattern2();
            objpt2.MakePattern();
            Console.ReadKey();
        }
    }
}
