﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class SimpleInterest
    {
        float p, n, r,simpleInterest;
        public void ReadData()
        {
            Console.WriteLine("Enter the Principal Amount");
            p = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Rate of interest");
            r = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Time period");
            n = Convert.ToInt32(Console.ReadLine());
        }
        public void FindSimpleInterest()
        {
            simpleInterest = (p * (1 + (r * n)));
        }
        public void DisplayData()
        {
            Console.WriteLine("The Simple Interest for the amount {0} for {1} time period with a interest rate of {2} is {3} ", p,n,r,simpleInterest);
        }
        public static void Main(string[] args)
        {
            SimpleInterest objSimpleInterest = new SimpleInterest();
            objSimpleInterest.ReadData();
            objSimpleInterest.FindSimpleInterest();
            objSimpleInterest.DisplayData();
            Console.ReadKey();
        }
    }
}
