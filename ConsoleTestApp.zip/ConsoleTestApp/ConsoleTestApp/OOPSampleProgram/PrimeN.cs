﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class PrimeN
    {
        int limit;
        public void ReadData()
        {
            Console.WriteLine("Enter the Number of Prime Numbers to be printed");
            limit = Convert.ToInt32(Console.ReadLine());
        }
        public void FindResult()
        {
            int count =0;
            int no = 2;
            Console.WriteLine("Prime Numbers between 1 and {0} are", limit);
            while( count < limit)
            {
                bool flag = true;
                for (int div = 2; div < no; div++)
                {
                    if (no % div == 0)
                    {
                        flag = false;
                        //no++;
                        break;
                    }  
                }
                if (flag)
                {
                    Console.WriteLine("\n" + no);
                    count++;
                }
                no++;
            }
        }
        public static void Main(string[] args)
        {
            PrimeN objprime = new PrimeN();
            objprime.ReadData();
            objprime.FindResult();
            Console.ReadKey();
        }
    }
}
