﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class EvenOrOddInterval
    {
        int stnum, endnum;
        public void ReadNumber()
        {
            Console.WriteLine("Enter the Starting Number");
            stnum = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Starting Number");
            endnum = Convert.ToInt32(Console.ReadLine());
        }
        public void FindResult()
        {
            Console.WriteLine("Odd numbers between " + stnum + "and" + endnum + " are ");
            for(int i = stnum;i <= endnum;i++)
            {
                if(i%2 != 0)
                {
                    Console.WriteLine("\n" + i);
                }
            }
        }
        public static void Main(string[] args)
        {
            EvenOrOddInterval objeo = new EvenOrOddInterval();
            objeo.ReadNumber();
            objeo.FindResult();
            Console.ReadKey();
        }
    }
}
