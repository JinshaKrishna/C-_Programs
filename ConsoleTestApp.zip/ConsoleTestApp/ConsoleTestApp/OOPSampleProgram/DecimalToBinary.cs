﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class DecimalToBinary
    {
        int binary_val=0;
        int decimal_val;
        public void ReadData()
        {
            Console.WriteLine("Enter the decimal number");
            decimal_val = Convert.ToInt32(Console.ReadLine());
        }
        public void FindBinary()
        {
            int number = decimal_val;
            int remainder,base_val=1;
            while(number>0)
            {
                remainder = number % 2;
                binary_val = remainder * base_val+binary_val;
                number = number / 2;
                base_val = base_val * 10;
            }
            
        }
        public void DisplayData()
        {
            Console.WriteLine("The Binary Equivalent of the given Decimal number {0} is {1} ", decimal_val, binary_val);
            Console.ReadKey();
        }
        public static void Main(string[] args)
        {
            DecimalToBinary objDecToBin = new DecimalToBinary();
            objDecToBin.ReadData();
            objDecToBin.FindBinary();
            objDecToBin.DisplayData();
            Console.ReadKey();
        }
    }
}
