﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Circle
    {
        double radius, pi = 3.14,area,circumference;
        public void ReadRadius()
        {
            Console.WriteLine("Enter the Radius");
            radius = Convert.ToInt32(Console.ReadLine());
        }
        public void FindArea()
        {
            area = pi * radius * radius;
        }
        public void FindCircumference()
        {
            circumference = 2 * pi * radius;
        }
        public void DisplayResult()
        {
            Console.WriteLine("\nArea = " + area);
            Console.WriteLine("\nCircumference = " + circumference);
        }
        public static void Main(string[] args)
        {
            Circle objcircle = new Circle();
            objcircle.ReadRadius();
            objcircle.FindArea();
            objcircle.FindCircumference();
            objcircle.DisplayResult();
            Console.ReadKey();
        }
    }
}
