﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Pattern4
    {
        int number = 5;
        public void MakePattern()
        {          
            for (int count = 1; count <= number; count++)
            {
                int star = 0;
                for (int st_no = 1; st_no <= number - count; st_no++)
                {
                    Console.Write(" ");
                }
                for (int end_no = 1; end_no <= count; end_no++)
                {                  
                    Console.Write("*");
                    star++;
                }
                while(star>1)
                {
                    Console.Write("*");
                    --star;
                }
                Console.WriteLine("");
            }
        }
        public static void Main()
        {
            Pattern4 objpt4 = new Pattern4();
            objpt4.MakePattern();
            Console.ReadKey();
        }
    }
}
