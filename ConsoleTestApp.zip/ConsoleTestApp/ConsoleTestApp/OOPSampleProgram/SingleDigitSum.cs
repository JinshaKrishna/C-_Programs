﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class SingleDigitSum
    {
        int number;
        int digitSum = 0;
        public int ReadData()
        {
            Console.WriteLine("Enter the Number");
            number = Convert.ToInt32(Console.ReadLine());
            return number;
        }
        public int FindSingleDigitSum(int num)
        {
            int n = num;
            digitSum = 0;
            int lastDigit;
            do
            {
                lastDigit = n % 10;
                digitSum += lastDigit;
                n /= 10;
            } while (n > 0);
            return digitSum;
        }
    
        public void DisplayData()
        {
            Console.WriteLine("The Digit Sum of the given number {0} is {1} ", number, digitSum);
            Console.ReadKey();
        }
        public static void Main(string[] args)
        {
            int n, sum;
            SingleDigitSum objSingleDigitSum = new SingleDigitSum();
            n = objSingleDigitSum.ReadData();
            sum = objSingleDigitSum.FindSingleDigitSum(n);
            do
            {
                n = sum;
                sum = objSingleDigitSum.FindSingleDigitSum(n);
            } while (sum > 9);

            objSingleDigitSum.DisplayData();
            Console.ReadKey();
        }
    }
}
