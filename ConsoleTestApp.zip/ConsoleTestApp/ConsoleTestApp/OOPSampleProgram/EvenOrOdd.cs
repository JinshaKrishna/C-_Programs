﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class EvenOrOdd
    {
        int num;
        string result;
        public void ReadNumber()
        {
            Console.WriteLine("Enter the Number");
            num = Convert.ToInt32(Console.ReadLine());
        }
        public void FindResult()
        {
            if(num%2 == 0)
            {
                result = "even";
            }
            else
            {
                result = "odd";
            }
        }
        public void DisplayReult()
        {
            Console.WriteLine("the given Number " + num + " is " + result);
        }
        public static void Main(string[] args)
        {
            EvenOrOdd objeo = new EvenOrOdd();
            objeo.ReadNumber();
            objeo.FindResult();
            objeo.DisplayReult();
            Console.ReadKey();
        }
    }
}
