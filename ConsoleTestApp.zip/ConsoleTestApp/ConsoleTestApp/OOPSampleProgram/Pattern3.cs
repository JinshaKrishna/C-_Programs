﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Pattern3
    {
        int number = 5;
        public void MakePattern()
        {
            for (int count = 1; count <= number; count++)
            {
                for (int st_no = 1; st_no <= number - count; st_no++)
                {
                    Console.Write(" ");
                }
                for (int end_no = 1; end_no <= count; end_no++)
                {
                    Console.Write("*");
                }
                Console.WriteLine("");
            }
        }
        public static void Main()
        {
            Pattern3 objpt3 = new Pattern3();
            objpt3.MakePattern();
            Console.ReadKey();
        }
    }
}
