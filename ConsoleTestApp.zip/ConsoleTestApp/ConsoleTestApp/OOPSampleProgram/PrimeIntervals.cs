﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class PrimeIntervals
    {
        int f_num,l_num;
        public void ReadData()
        {
            Console.WriteLine("Enter the Starting Number");
            f_num = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Ending Number");
            l_num = Convert.ToInt32(Console.ReadLine());
        }
        public void FindResult()
        {
            Console.WriteLine("Prime Numbers between " + f_num + " and " + l_num + " are");
            for (int no = f_num; no <= l_num; no++)               //taking the numbers between the limit
            {
                bool flag = true;                    
                for (int div = 2; div < no; div++)
                {
                    if (no % div == 0)
                    {
                        flag=false;                       
                        break;
                    }
                }
                if (flag)
                {
                    Console.WriteLine("\n" + no);
                }
            }
        }
        public static void Main(string[] args)
        {
            PrimeIntervals objprime = new PrimeIntervals();
            objprime.ReadData();
            objprime.FindResult();
            Console.ReadKey();
        }
    }
}
