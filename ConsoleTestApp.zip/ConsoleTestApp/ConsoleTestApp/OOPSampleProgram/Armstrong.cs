﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Armstrong
    {
        int number;
        String result;
        public void ReadData()
        {
            Console.WriteLine("Enter the Number");
            number = Convert.ToInt32(Console.ReadLine());
        }
        public void FindDigitSum()
        {
            int sum = 0;
            bool flag = true;
            int n = number;
            int c_no,lastDigit;
            int count = 0;
            int num = number;
            do
            {  
                c_no = num % 10;
                count++;
                num /= 10;
            } while (num > 0);
            do
            {
                 lastDigit = n % 10;
                 sum = sum+(int) Math.Pow(lastDigit,count);
                 n /= 10;
            } while (n > 0);
            
            if (sum==number)
            {
                flag=false;
            }
            if(flag)
            {
                result = "NOT ARMSTRONG";
            }
            else
            {
                result = "ARMSTRONG";
            }
        }
        public void DisplayData()
        {
            Console.WriteLine("The given number {0} is {1} ", number, result);
            Console.ReadKey();
        }
        public static void Main(string[] args)
        {
            Armstrong objArmstrong = new Armstrong();
            objArmstrong.ReadData();
            objArmstrong.FindDigitSum();
            objArmstrong.DisplayData();
            Console.ReadKey();
        }
    }
}
