﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class LCM_GCD
    {
        int number1, number2, LCM, GCD;
        public void ReadNumbers()
        {
            Console.WriteLine("Enter Number 1");
            number1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Number 2");
            number2 = Convert.ToInt32(Console.ReadLine());
        }
        public int FindGCD()
        {
            int num1 = number1;
            int num2 = number2;
            while (num1 != num2)
            {
                if (num1 > num2)
                {
                    num1 = num1 - num2;
                }
                if (num1 < num2)
                {
                    num2 = num2 - num1;
                }
            }
            GCD = num1;
            return GCD;
        }
        public void FindLCM(int gcd)
        {
            LCM = ((number1 * number2) / gcd);
        }
        public void Display(int gcd)
        {
            GCD = gcd;
            Console.WriteLine("\nGCD of {0} and {1} : {2}",number1, number2, GCD);
            Console.WriteLine("\nLCM of {0} and {1} : {2}", number1, number2, LCM);
        }
        public static void Main()
        {
            LCM_GCD objLcmGcd = new LCM_GCD();
            int lcm, gcd;
            objLcmGcd.ReadNumbers();
            gcd = objLcmGcd.FindGCD();
            objLcmGcd.FindLCM(gcd);
            objLcmGcd.Display(gcd);
            Console.ReadKey();
        }
    }
}
