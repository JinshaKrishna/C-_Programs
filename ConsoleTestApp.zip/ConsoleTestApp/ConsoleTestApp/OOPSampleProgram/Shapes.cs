﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    abstract class Shapes
    {
        public const double PI= 3.14;
        public double area;

        public abstract void FindArea();

        public void Display()
        {
            Console.WriteLine("Area : " + area);
        }
        public static void Main()
        {
            Console.WriteLine("\n------------CIRCLE-------------\n");
            ShapeCircle circle = new ShapeCircle();
            circle.ReadData();
            circle.FindArea();
            circle.Display();
            Console.WriteLine("\n------------SQUARE-------------\n");
            ShapeSquare square = new ShapeSquare();
            square.ReadData();
            square.FindArea();
            square.Display();
            Console.WriteLine("\n------------TRIANGLE-------------\n");
            ShapeTriangle triangle = new ShapeTriangle();
            triangle.ReadData();
            triangle.FindArea();
            triangle.Display();

            Console.ReadKey();
        }

    }
    class ShapeCircle : Shapes
    {
        int radius;
        public void ReadData()
        {
            Console.WriteLine("Enter the Radius of Circle");
            radius = Convert.ToInt32(Console.ReadLine());
        }
        public override void FindArea()
        {
            area = PI * radius * radius;
        }
    }
    class ShapeSquare : Shapes
    {
        int side;
        public void ReadData()
        {
            Console.WriteLine("Enter the Side of the Square");
            side = Convert.ToInt32(Console.ReadLine());
        }
        public override void FindArea()
        {
            area = side*side;
        }
    }
    class ShapeTriangle : Shapes
    {
        int tri_base,height;
        public void ReadData()
        {
            Console.WriteLine("Enter the Base of the Triangle");
            tri_base = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Height of the Triangle");
            height = Convert.ToInt32(Console.ReadLine());
        }
        public override void FindArea()
        {
            area = ((tri_base * height)/2);
        }
    }
}
