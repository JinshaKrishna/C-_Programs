﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Fibonacci
    {
        int limit;
        public void ReadData()
        {
            Console.WriteLine("Enter the Limit of the series");
            limit = Convert.ToInt32(Console.ReadLine());
        }
        public void FindResult()
        {
            while (limit <= 0)
            {
                Console.WriteLine("!!!  Entered number is invalid, Please Enter a valid number...\n");
                Console.ReadKey();
                ReadData();
            }
            
            int first = 1, second = 1, third,count=2;
            Console.WriteLine("Fibonacci series :\n{0}\n\n{1}", first, second);
            do
            {

                third = first + second;
                Console.WriteLine("\n" + third);
                count++;
                first = second;
                second = third;
            } while (count!=limit);

        }
        public static void Main(string[] args)
        {
            Fibonacci objFibonacci = new Fibonacci();
            objFibonacci.ReadData();
            objFibonacci.FindResult();
            Console.ReadKey();
        }
    }
}
