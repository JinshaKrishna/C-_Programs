﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class PerfectNumber
    {
        int number,sum=0;
        public void ReadData()
        {
            Console.WriteLine("Enter the Number");
            number = Convert.ToInt32(Console.ReadLine());
        }
        public void CheckPerfectNumber()
        {
            for(int div = 1;div < number;div++)
            {
                if(number % div == 0)
                {
                    sum += div;
                }
            }
        }
        public void DisplayData()
        {
            Console.WriteLine("The sum of Divisors of the given number {0} is {1} ", number, sum);
            if (sum == number)
            {
                Console.WriteLine("\nThe given number {0} is a Perfect NUmber", number);
            }
            else
            {
                Console.WriteLine("\nThe given number {0} is Not a Perfect NUmber", number);
            }
        }
        public static void Main(string[] args)
        {
            PerfectNumber objPerfectNumber = new PerfectNumber();
            objPerfectNumber.ReadData();
            objPerfectNumber.CheckPerfectNumber();
            objPerfectNumber.DisplayData();
            Console.ReadKey();
        }
    }
}
