﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Pattern1
    {
        int number = 5;
        public void MakePattern()
        { 
            for(int count=1;count<=number;count++)
            {
                for (int p_st=0;p_st!=count;p_st++)
                {
                    Console.Write("*");
                }
                Console.WriteLine("\n");
            }
        }
        public static void Main()
        {
            Pattern1 objpt1 = new Pattern1();
            objpt1.MakePattern();
            Console.ReadKey();
        }
    }
}
