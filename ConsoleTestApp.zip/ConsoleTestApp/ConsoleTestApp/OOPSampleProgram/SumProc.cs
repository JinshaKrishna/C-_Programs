﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class SumProc
    {
        public static void Main(String[] args)
        {
            int value1, value2, value3;
            //value1 = 10;
            //value2 = 20;
            Console.WriteLine("Enter the Value 1");
            value1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Value 2");
            value2 = Convert.ToInt32(Console.ReadLine());
            value3 = value1 + value2;
            Console.WriteLine("Value 1 : " + value1);
            Console.WriteLine("Value 2 : " + value2);
            Console.WriteLine("Value 3 : " + value3);
            Console.ReadKey();
        }

    }
}
