﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class PersonStudentInheritance
    {
        public static void Main()
        {
            Person objPerson = new Person();
            Student objStudent = new Student();
            objStudent.ReadPerson();
            objStudent.DisplayPerson();
            objStudent.ReadStudent();
            objStudent.DiplayMarks();
            objStudent.FindResult();
            objStudent.DisplayStudent();
            Console.ReadKey();
        }
    }
    class Person
    {
        public int id;
        public String name;
        public void ReadPerson()
        {
            Console.WriteLine("Enter the ID Number");
            id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Name");
            name = Console.ReadLine();
        }
        public void DisplayPerson()
        {
            Console.WriteLine("Peron Details");
            Console.WriteLine("--------------");
            Console.WriteLine("ID Number : {0}\nName : {1}\n", id, name);
        }
    }
    class Student : Person
    {
        int mark1, mark2, mark3,total;
        String result;
        public void ReadStudent()
        {
            Console.WriteLine("Enter the Mark 1");
            mark1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Mark 2");
            mark2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Mark 3");
            mark3 = Convert.ToInt32(Console.ReadLine());
        }
        public void DiplayMarks()
        {
            Console.WriteLine("Mark Details");
            Console.WriteLine("--------------");
            Console.WriteLine("Mark 1 : {0}\nMark 2 : {1}\nMark 3 : {2}\n", mark1, mark2, mark3);
        }
        public void FindResult()
        {
            total = mark1 + mark2 + mark3;
            if(mark1>40&&mark2>40&&mark3>40)
            {
                result = "PASS";
            }
            else
            {
                result = "FAILED";
            }
        }
        public void DisplayStudent()
        {
            base.DisplayPerson();
            Console.WriteLine("Student Details");
            Console.WriteLine("--------------");
            Console.WriteLine("ID Number : {0}\nName : {1}\n", id, name);
            Console.WriteLine("Mark 1 : {0}\nMark 2 : {1}\nMark 3 : {2}\nTotal Marks obtained : {3}\nResult : {4}", mark1, mark2, mark3,total,result);
        }
    }
}
