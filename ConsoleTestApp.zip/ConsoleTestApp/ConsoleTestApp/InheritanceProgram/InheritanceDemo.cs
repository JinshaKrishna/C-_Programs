﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class InheritanceDemo
    {
        public static void Main()
        {
            //A a1 = new A();
            B b1 = new B();
            b1.DisplayA();
            b1.DisplayB();
            Console.ReadKey();
        }

    }
    class A
    {
        public int val1;
        public A()
        {
            val1 = 10;
        }
        public void DisplayA()
        {
            Console.WriteLine("I am in Base class A val1 : " + val1);
        }
    }
    class B : A
    {
        int val2;
        public B()
        {
            val2 = 20;
        }
        public void DisplayB()
        {
            Console.WriteLine("I am in Base class A val1 : " + val1);
            Console.WriteLine("I am in Derived class B val2 : " + val2);
        }
    }
}
