﻿#define FOOL

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class AttributeDemo
    {
        public static void Main()
        {
            Greet.GreetDebug();
            Greet.GreetTrace();

            Console.ReadKey();
        }
    }
    class Greet
    {
        [Conditional("DEBUG")]
        public static void GreetDebug()
        {
            Console.WriteLine("Greeting from Debug");
        }

        [Conditional("FOOL")]
        public static void GreetTrace()
        {
            Console.WriteLine("Greeting from Trace");
        }
    }
}
