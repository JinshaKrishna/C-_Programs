﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class AttributeObsoleteDemo
    {
        public static void Main()
        {
            List<int> list = new List<int>();
            list.Add(10);
            list.Add(20);
            list.Add(30);
            list.Add(40);

            int result1 = Calculator1.Add(1, 2);
            int result2 = Calculator1.Add(list);

            Console.WriteLine("Sum : " + result1);
            Console.WriteLine("Sum : " + result2);

            Console.ReadKey();
        }
    }
    [Obsolete("depricated class")]
    class Calculator1
    {
        [Obsolete("new method : int Add(List<int> numbers")]
        public static int Add(int value1,int value2)
        {
            return (value1 + value2);
        }
        public static int Add(List<int> numbers)
        {
            int sum = 0;
            foreach(int number in numbers)
            {
                sum += number;
            }
            return sum;
        }
    }
}
