﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class DebuggingDemoProgram
    {
        public static void Main(string[] args)
        {
            EvenNumbers objEven = new EvenNumbers();
            objEven.ReadNumber();
            objEven.FindResult();
            Console.ReadKey();
        }
    }
    class EvenNumbers
    {
        int stnum, endnum;
        public void ReadNumber()
        {
            Console.WriteLine("Enter the Starting Number");
            stnum = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Starting Number");
            endnum = Convert.ToInt32(Console.ReadLine());
        }
        public void FindResult()
        {
            int j = 10;
            Console.WriteLine("Even numbers between " + stnum + "and" + endnum + " are ");
            for (int i = stnum; i <= endnum; i++)
            {
                if (i % 2 == 0)
                {
                    Console.WriteLine("\n" + i);
                    j++;
                }
            }
        }
    }
}
