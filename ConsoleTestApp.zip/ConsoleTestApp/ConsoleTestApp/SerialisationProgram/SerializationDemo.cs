﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace ConsoleTestApp
{
    class SerializationDemo
    {
        public static void Main()
        {
            FileStream stream = new FileStream("D:\\JINSHA\\data\\account.data", FileMode.OpenOrCreate);
            BinaryFormatter formatter = new BinaryFormatter();

            Account account1 = new Account(101021, 12000);
            formatter.Serialize(stream, account1);
            stream.Close();

            
        }
        public static void Deserializable()
        {
            FileStream stream = new FileStream("D:\\JINSHA\\data\\account.data", FileMode.OpenOrCreate);
            BinaryFormatter formatter = new BinaryFormatter();

            Account account = (Account)formatter.Deserialize(stream);
            account.Display();

            stream.Close();

            Console.ReadKey();
        }
    }
    [Serializable]
    class Account
    {
        public int ID { get; set; }
        public int Balance { get; set; }
        public Account(int id,int balance)
        {
            ID = id;
            Balance = balance;
        }
        public void Display()
        {
            Console.WriteLine("Account ID : " + ID);
            Console.WriteLine("Account Balane : " + Balance);
        }
    }
}
