﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class ExceptionDemo2
    {
        public static void Main()
        {
            int[] num = new int[5];
            for(int index = 0;index < 5;index++)
            {
                num[index] = Input.ReadI();
            }
            Console.ReadKey();
        }
    }
    class Input
    {
        public static int ReadI()
        {
            int value = 0;bool flag = true;
            do
            {
                try
                {
                    Console.WriteLine("Enter Marks");
                    value = Convert.ToInt32(Console.ReadLine());
                    if(value < 0 || value > 100)
                    {
                        
                    }
                    flag = false;
                }
                catch(Exception)
                {
                    Console.WriteLine("!!! Wrong Value | Please Enter a valid Integer");
                }
            } while (flag);
            return value;
        }
        public static void Display()
        {
            try
            {
               
            }
            catch
            {
                Console.WriteLine("!!! Wrong Value | Please Enter a valid Integer");
            }
        }
    }
}
