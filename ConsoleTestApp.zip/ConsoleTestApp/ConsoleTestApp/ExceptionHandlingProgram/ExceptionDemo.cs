﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class ExceptionDemo
    {
        public static void Main()
        {
            int a, b, c;
            a = 10;
            b = 5;
            Console.WriteLine("Iam Beore try");

            try
            {
                Console.WriteLine("A : " + a);
                Console.WriteLine("B : " + b);
                c = a / (b - 5);
                c = a / (b);
                Console.WriteLine("C : " + c);
            }
            catch(DivideByZeroException e)
            {
                Console.WriteLine("Iam within catch" + e.Message.ToString());
                //c = a / b;
                //Console.WriteLine("C : " + c);
            }
            Console.WriteLine("Iam outside the catch");
            Console.ReadKey();
        }     
    }
}
