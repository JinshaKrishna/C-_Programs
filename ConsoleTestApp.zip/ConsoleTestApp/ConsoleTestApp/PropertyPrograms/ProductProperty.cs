﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class ProductProperty
    {
        int productId;
        static int count = 101;
        private string productName;
        private int price, supplierId;
        public ProductProperty()
        {
            productId = count;
            count++;
        }
        public String ProductName
        {
            get { return productName; }
            set { productName = value; }
        }
        public int Price
        {
            get { return price; }
            set { price = value; }
        }

        public int SupplierId
        {
            get { return supplierId; }
            set { supplierId = value; }
        }
        public void ReadProducts()
        {
            Console.WriteLine("Enter Product Name");
            productName = Console.ReadLine();
            Console.WriteLine("Enter Product Price");
            price = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Supplier ID");
            supplierId = Convert.ToInt32(Console.ReadLine());
        }
        public void DisplayProducts()
        {
            Console.WriteLine("\n---------Product Details-----------");
            Console.WriteLine("Product ID : " + productId);
            Console.WriteLine("Product Name : " + ProductName);
            Console.WriteLine("Product Price : " + price);
            Console.WriteLine("Supplier ID : " + supplierId);
            Console.WriteLine("-----------------------------------");
        }
        public static void Main()
        {
            ProductProperty objProduct = new ProductProperty();
            objProduct.ReadProducts();
            objProduct.DisplayProducts();
            ProductProperty objProduct1 = new ProductProperty();
            objProduct1.ReadProducts();
            objProduct1.DisplayProducts();

            Console.ReadKey();
        }
    }
}
