﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.StringProgram
{
    class CodeGeneration
    {
        public static void Main()
        {
            StudentCodes objStudent = new StudentCodes();
            objStudent.ReadStudentId();
            objStudent.GenerateCodes();

            Console.ReadKey();
        }
    }
    class StudentCodes
    {
        string id;
        public void ReadStudentId()
        {
            Console.WriteLine("Enter the Student Code ");
            id = Console.ReadLine();
        }
        public void GenerateCodes()
        {
            string first = id.Substring(2);
            string last = id.Substring(3);
            Console.WriteLine(first);
            Console.WriteLine(last);
            int lastDigits = Convert.ToInt32(last);
            lastDigits++;
            last = lastDigits.ToString();
            id = String.Concat(first,last);

            Console.WriteLine(id);
        }
    }
}
