﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class NumberToWords
    {
        int number;
        String word;
        public void ReadNumber()
        {
            Console.WriteLine("Enter the Number to be converted into Words");
            number = Convert.ToInt32(Console.ReadLine());
        }
        public void ConvertNumberToWord()
        {
            
        }
    }
}
