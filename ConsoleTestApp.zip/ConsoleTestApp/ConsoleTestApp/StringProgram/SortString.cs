﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class SortString
    {
        //char[] sort = new char[] { 'j', 'i', 'n', 's', 'h', 'a' };
        char[] sort;
        String readString;
        char[] lj;
        public void ReadString()
        {
            Console.WriteLine("Enter the String to sort");
            readString = Console.ReadLine();
            String sf = readString.ToString();
            sort = new char[sf.Length];
            lj = readString.ToString().ToCharArray();
            for(int index = 0;index < sf.Length;index++)
            {
                sort[index] = lj[index];
            }
            Console.WriteLine(sort);
        }
        public void StringSort()
        {
            for (int start = 0; start < sort.Length - 1; start++)
            {
                for (int next = start + 1; next < sort.Length; next++)
                {
                    //Console.WriteLine(String.Compare(sort[start], sort[next]));
                    /*if ()
                    {
                        char temp = sort[start];
                        sort[start] = sort[next];
                        sort[next] = temp;
                    }*/
                }
            }
            Console.WriteLine(sort);
        }
        public static void Main()
        {
            SortString objSortString = new SortString();
            objSortString.ReadString();
            objSortString.StringSort();

            Console.ReadKey();
        }
    }
}
