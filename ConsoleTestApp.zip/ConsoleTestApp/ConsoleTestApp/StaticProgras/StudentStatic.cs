﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class StudentStatic
    {
        int id, mark, total;
        String name, result;
        static int minMark = 0, maxMark = 100, passMark = 40;
        public void ReadData()
        {
            Console.WriteLine("\nEnter Student ID");
            id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("\nEnter Student Name");
            name = Console.ReadLine();
        }
        public int ReadMarks()
        {
            bool flag;
            do
            {
                flag = false;
                mark = Convert.ToInt32(Console.ReadLine());
                if(mark<minMark || mark>maxMark)
                {
                    flag = true;
                    Console.WriteLine("\nEntered Mark is Invalid, Please Enter a Mark between 0 - 100");
                }
            } while (flag);
            return mark;
        }
        public void FindResult(int mark1, int mark2, int mark3)
        {
            total = mark1 + mark2 + mark3;
            if(mark1> passMark && mark2> passMark && mark3> passMark)
            {
                result = "PASS";
            }
            else
            {
                result = "FAILED";
            }
        }
        public void DisplayStudent()
        {
            Console.WriteLine("\nId : " + id);
            Console.WriteLine("\nName : " + name);
        }
        public void DisplayResult()
        {
            Console.WriteLine("\nTotal : " + total);
            Console.WriteLine("\nResult : " + result);
        }
        public static void Main()
        {
            int m1, m2, m3;
            StudentStatic objStudent = new StudentStatic();
            objStudent.ReadData();
            Console.WriteLine("\nEnter Mark 1");
            m1 = objStudent.ReadMarks();
            Console.WriteLine("\nEnter Mark 2");
            m2 = objStudent.ReadMarks();
            Console.WriteLine("\nEnter Mark 3");
            m3 = objStudent.ReadMarks();
            Console.WriteLine("\nStudent Details");
            Console.WriteLine("\n----------------");
            objStudent.DisplayStudent();
            Console.WriteLine("\nMark 1 : " + m1);
            Console.WriteLine("\nMark 2 : " + m2);
            Console.WriteLine("\nMark 3 : " + m3);
            objStudent.FindResult(m1, m2, m3);
            objStudent.DisplayResult();

            Console.ReadKey();
        }
    }
}
