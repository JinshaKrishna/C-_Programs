﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class StaticDemo
    {
        int number = 1;
        static int demo_number = 5;
        public void Display()
        {
           
            Console.WriteLine("{0} : {1}", number, demo_number);
            number++;
            demo_number++;
        }
        public static void Main()
        {
            StaticDemo sd1 = new StaticDemo();
            StaticDemo sd2 = new StaticDemo();
            StaticDemo sd3 = new StaticDemo();
            StaticDemo sd4 = new StaticDemo();
            sd1.Display();
            sd2.Display();
            sd3.Display();
            sd4.Display();
            Console.ReadKey();
        }
    }
}
