﻿namespace StudentProject
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.comboBoxIds = new System.Windows.Forms.ComboBox();
			this.lblMessage = new System.Windows.Forms.Label();
			this.btnDelete = new System.Windows.Forms.Button();
			this.btnUpdate = new System.Windows.Forms.Button();
			this.btnClear = new System.Windows.Forms.Button();
			this.btnSave = new System.Windows.Forms.Button();
			this.panel2 = new System.Windows.Forms.Panel();
			this.textBoxMark3 = new System.Windows.Forms.TextBox();
			this.textBoxMark2 = new System.Windows.Forms.TextBox();
			this.textBoxMark1 = new System.Windows.Forms.TextBox();
			this.textBoxName = new System.Windows.Forms.TextBox();
			this.textBoxId = new System.Windows.Forms.TextBox();
			this.lblMark3 = new System.Windows.Forms.Label();
			this.lblMark2 = new System.Windows.Forms.Label();
			this.lblMark1 = new System.Windows.Forms.Label();
			this.lblName = new System.Windows.Forms.Label();
			this.panel1 = new System.Windows.Forms.Panel();
			this.lblId = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.studentTableBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.studentTableBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
			this.lblmsg = new System.Windows.Forms.Label();
			this.dataGridViewStudent = new System.Windows.Forms.DataGridView();
			this.database1DataSet = new StudentProject.Database1DataSet();
			this.studentTableBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
			this.studentTableTableAdapter = new StudentProject.Database1DataSetTableAdapters.StudentTableTableAdapter();
			this.studentIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.studentNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.mark1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.mark2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.mark3DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.totalDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.resultDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.panel2.SuspendLayout();
			this.panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.studentTableBindingSource)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.studentTableBindingSource1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dataGridViewStudent)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.database1DataSet)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.studentTableBindingSource2)).BeginInit();
			this.SuspendLayout();
			// 
			// comboBoxIds
			// 
			this.comboBoxIds.FormattingEnabled = true;
			this.comboBoxIds.Location = new System.Drawing.Point(204, 20);
			this.comboBoxIds.Name = "comboBoxIds";
			this.comboBoxIds.Size = new System.Drawing.Size(121, 21);
			this.comboBoxIds.TabIndex = 10;
			// 
			// lblMessage
			// 
			this.lblMessage.AutoSize = true;
			this.lblMessage.ForeColor = System.Drawing.Color.Red;
			this.lblMessage.Location = new System.Drawing.Point(323, -9);
			this.lblMessage.Name = "lblMessage";
			this.lblMessage.Size = new System.Drawing.Size(0, 13);
			this.lblMessage.TabIndex = 18;
			// 
			// btnDelete
			// 
			this.btnDelete.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
			this.btnDelete.Location = new System.Drawing.Point(371, 40);
			this.btnDelete.Name = "btnDelete";
			this.btnDelete.Size = new System.Drawing.Size(75, 23);
			this.btnDelete.TabIndex = 13;
			this.btnDelete.Text = "DELETE";
			this.btnDelete.UseVisualStyleBackColor = true;
			// 
			// btnUpdate
			// 
			this.btnUpdate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
			this.btnUpdate.Location = new System.Drawing.Point(250, 40);
			this.btnUpdate.Name = "btnUpdate";
			this.btnUpdate.Size = new System.Drawing.Size(75, 23);
			this.btnUpdate.TabIndex = 12;
			this.btnUpdate.Text = "UPDATE";
			this.btnUpdate.UseVisualStyleBackColor = true;
			// 
			// btnClear
			// 
			this.btnClear.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
			this.btnClear.Location = new System.Drawing.Point(130, 40);
			this.btnClear.Name = "btnClear";
			this.btnClear.Size = new System.Drawing.Size(75, 23);
			this.btnClear.TabIndex = 11;
			this.btnClear.Text = "CLEAR";
			this.btnClear.UseVisualStyleBackColor = true;
			// 
			// btnSave
			// 
			this.btnSave.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
			this.btnSave.Location = new System.Drawing.Point(24, 40);
			this.btnSave.Name = "btnSave";
			this.btnSave.Size = new System.Drawing.Size(75, 23);
			this.btnSave.TabIndex = 10;
			this.btnSave.Text = "SAVE";
			this.btnSave.UseVisualStyleBackColor = true;
			this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
			// 
			// panel2
			// 
			this.panel2.Controls.Add(this.btnDelete);
			this.panel2.Controls.Add(this.btnUpdate);
			this.panel2.Controls.Add(this.btnClear);
			this.panel2.Controls.Add(this.btnSave);
			this.panel2.Location = new System.Drawing.Point(133, 426);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(535, 114);
			this.panel2.TabIndex = 17;
			// 
			// textBoxMark3
			// 
			this.textBoxMark3.Location = new System.Drawing.Point(204, 278);
			this.textBoxMark3.Name = "textBoxMark3";
			this.textBoxMark3.Size = new System.Drawing.Size(121, 20);
			this.textBoxMark3.TabIndex = 9;
			// 
			// textBoxMark2
			// 
			this.textBoxMark2.Location = new System.Drawing.Point(204, 230);
			this.textBoxMark2.Name = "textBoxMark2";
			this.textBoxMark2.Size = new System.Drawing.Size(121, 20);
			this.textBoxMark2.TabIndex = 8;
			// 
			// textBoxMark1
			// 
			this.textBoxMark1.Location = new System.Drawing.Point(204, 178);
			this.textBoxMark1.Name = "textBoxMark1";
			this.textBoxMark1.Size = new System.Drawing.Size(121, 20);
			this.textBoxMark1.TabIndex = 7;
			// 
			// textBoxName
			// 
			this.textBoxName.Location = new System.Drawing.Point(204, 123);
			this.textBoxName.Name = "textBoxName";
			this.textBoxName.Size = new System.Drawing.Size(121, 20);
			this.textBoxName.TabIndex = 6;
			// 
			// textBoxId
			// 
			this.textBoxId.Location = new System.Drawing.Point(204, 67);
			this.textBoxId.Name = "textBoxId";
			this.textBoxId.Size = new System.Drawing.Size(121, 20);
			this.textBoxId.TabIndex = 5;
			// 
			// lblMark3
			// 
			this.lblMark3.AutoSize = true;
			this.lblMark3.Location = new System.Drawing.Point(21, 285);
			this.lblMark3.Name = "lblMark3";
			this.lblMark3.Size = new System.Drawing.Size(40, 13);
			this.lblMark3.TabIndex = 4;
			this.lblMark3.Text = "Mark 3";
			// 
			// lblMark2
			// 
			this.lblMark2.AutoSize = true;
			this.lblMark2.Location = new System.Drawing.Point(21, 237);
			this.lblMark2.Name = "lblMark2";
			this.lblMark2.Size = new System.Drawing.Size(40, 13);
			this.lblMark2.TabIndex = 3;
			this.lblMark2.Text = "Mark 2";
			// 
			// lblMark1
			// 
			this.lblMark1.AutoSize = true;
			this.lblMark1.Location = new System.Drawing.Point(21, 185);
			this.lblMark1.Name = "lblMark1";
			this.lblMark1.Size = new System.Drawing.Size(40, 13);
			this.lblMark1.TabIndex = 2;
			this.lblMark1.Text = "Mark 1";
			// 
			// lblName
			// 
			this.lblName.AutoSize = true;
			this.lblName.Location = new System.Drawing.Point(21, 130);
			this.lblName.Name = "lblName";
			this.lblName.Size = new System.Drawing.Size(35, 13);
			this.lblName.TabIndex = 1;
			this.lblName.Text = "Name";
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.comboBoxIds);
			this.panel1.Controls.Add(this.textBoxMark3);
			this.panel1.Controls.Add(this.textBoxMark2);
			this.panel1.Controls.Add(this.textBoxMark1);
			this.panel1.Controls.Add(this.textBoxName);
			this.panel1.Controls.Add(this.textBoxId);
			this.panel1.Controls.Add(this.lblMark3);
			this.panel1.Controls.Add(this.lblMark2);
			this.panel1.Controls.Add(this.lblMark1);
			this.panel1.Controls.Add(this.lblName);
			this.panel1.Controls.Add(this.lblId);
			this.panel1.Location = new System.Drawing.Point(133, 90);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(535, 307);
			this.panel1.TabIndex = 16;
			// 
			// lblId
			// 
			this.lblId.AutoSize = true;
			this.lblId.Location = new System.Drawing.Point(21, 74);
			this.lblId.Name = "lblId";
			this.lblId.Size = new System.Drawing.Size(58, 13);
			this.lblId.TabIndex = 0;
			this.lblId.Text = "Student ID";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.Maroon;
			this.label1.Location = new System.Drawing.Point(350, -50);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(263, 24);
			this.label1.TabIndex = 15;
			this.label1.Text = "Student Information System";
			// 
			// studentTableBindingSource
			// 
			this.studentTableBindingSource.DataMember = "StudentTable";
			// 
			// studentTableBindingSource1
			// 
			this.studentTableBindingSource1.DataMember = "StudentTable";
			// 
			// lblmsg
			// 
			this.lblmsg.AutoSize = true;
			this.lblmsg.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.lblmsg.Location = new System.Drawing.Point(260, 47);
			this.lblmsg.Name = "lblmsg";
			this.lblmsg.Size = new System.Drawing.Size(0, 13);
			this.lblmsg.TabIndex = 11;
			// 
			// dataGridViewStudent
			// 
			this.dataGridViewStudent.AutoGenerateColumns = false;
			this.dataGridViewStudent.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridViewStudent.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.studentIdDataGridViewTextBoxColumn,
            this.studentNameDataGridViewTextBoxColumn,
            this.mark1DataGridViewTextBoxColumn,
            this.mark2DataGridViewTextBoxColumn,
            this.mark3DataGridViewTextBoxColumn,
            this.totalDataGridViewTextBoxColumn,
            this.resultDataGridViewTextBoxColumn});
			this.dataGridViewStudent.DataSource = this.studentTableBindingSource2;
			this.dataGridViewStudent.Location = new System.Drawing.Point(687, 110);
			this.dataGridViewStudent.Name = "dataGridViewStudent";
			this.dataGridViewStudent.Size = new System.Drawing.Size(240, 150);
			this.dataGridViewStudent.TabIndex = 19;
			// 
			// database1DataSet
			// 
			this.database1DataSet.DataSetName = "Database1DataSet";
			this.database1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			// 
			// studentTableBindingSource2
			// 
			this.studentTableBindingSource2.DataMember = "StudentTable";
			this.studentTableBindingSource2.DataSource = this.database1DataSet;
			// 
			// studentTableTableAdapter
			// 
			this.studentTableTableAdapter.ClearBeforeFill = true;
			// 
			// studentIdDataGridViewTextBoxColumn
			// 
			this.studentIdDataGridViewTextBoxColumn.DataPropertyName = "studentId";
			this.studentIdDataGridViewTextBoxColumn.HeaderText = "studentId";
			this.studentIdDataGridViewTextBoxColumn.Name = "studentIdDataGridViewTextBoxColumn";
			// 
			// studentNameDataGridViewTextBoxColumn
			// 
			this.studentNameDataGridViewTextBoxColumn.DataPropertyName = "studentName";
			this.studentNameDataGridViewTextBoxColumn.HeaderText = "studentName";
			this.studentNameDataGridViewTextBoxColumn.Name = "studentNameDataGridViewTextBoxColumn";
			// 
			// mark1DataGridViewTextBoxColumn
			// 
			this.mark1DataGridViewTextBoxColumn.DataPropertyName = "mark1";
			this.mark1DataGridViewTextBoxColumn.HeaderText = "mark1";
			this.mark1DataGridViewTextBoxColumn.Name = "mark1DataGridViewTextBoxColumn";
			// 
			// mark2DataGridViewTextBoxColumn
			// 
			this.mark2DataGridViewTextBoxColumn.DataPropertyName = "mark2";
			this.mark2DataGridViewTextBoxColumn.HeaderText = "mark2";
			this.mark2DataGridViewTextBoxColumn.Name = "mark2DataGridViewTextBoxColumn";
			// 
			// mark3DataGridViewTextBoxColumn
			// 
			this.mark3DataGridViewTextBoxColumn.DataPropertyName = "mark3";
			this.mark3DataGridViewTextBoxColumn.HeaderText = "mark3";
			this.mark3DataGridViewTextBoxColumn.Name = "mark3DataGridViewTextBoxColumn";
			// 
			// totalDataGridViewTextBoxColumn
			// 
			this.totalDataGridViewTextBoxColumn.DataPropertyName = "total";
			this.totalDataGridViewTextBoxColumn.HeaderText = "total";
			this.totalDataGridViewTextBoxColumn.Name = "totalDataGridViewTextBoxColumn";
			// 
			// resultDataGridViewTextBoxColumn
			// 
			this.resultDataGridViewTextBoxColumn.DataPropertyName = "result";
			this.resultDataGridViewTextBoxColumn.HeaderText = "result";
			this.resultDataGridViewTextBoxColumn.Name = "resultDataGridViewTextBoxColumn";
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(948, 552);
			this.Controls.Add(this.dataGridViewStudent);
			this.Controls.Add(this.lblmsg);
			this.Controls.Add(this.lblMessage);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.label1);
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.panel2.ResumeLayout(false);
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.studentTableBindingSource)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.studentTableBindingSource1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dataGridViewStudent)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.database1DataSet)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.studentTableBindingSource2)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.BindingSource studentTableBindingSource;
		private System.Windows.Forms.ComboBox comboBoxIds;
		private System.Windows.Forms.Label lblMessage;
		private System.Windows.Forms.Button btnDelete;
		private System.Windows.Forms.Button btnUpdate;
		private System.Windows.Forms.Button btnClear;
		private System.Windows.Forms.Button btnSave;
		private System.Windows.Forms.BindingSource studentTableBindingSource1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.TextBox textBoxMark3;
		private System.Windows.Forms.TextBox textBoxMark2;
		private System.Windows.Forms.TextBox textBoxMark1;
		private System.Windows.Forms.TextBox textBoxName;
		private System.Windows.Forms.TextBox textBoxId;
		private System.Windows.Forms.Label lblMark3;
		private System.Windows.Forms.Label lblMark2;
		private System.Windows.Forms.Label lblMark1;
		private System.Windows.Forms.Label lblName;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Label lblId;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label lblmsg;
		private System.Windows.Forms.DataGridView dataGridViewStudent;
		private Database1DataSet database1DataSet;
		private System.Windows.Forms.BindingSource studentTableBindingSource2;
		private Database1DataSetTableAdapters.StudentTableTableAdapter studentTableTableAdapter;
		private System.Windows.Forms.DataGridViewTextBoxColumn studentIdDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn studentNameDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn mark1DataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn mark2DataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn mark3DataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn totalDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn resultDataGridViewTextBoxColumn;
	}
}

