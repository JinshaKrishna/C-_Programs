﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StudentProject.StudentDTO;

namespace StudentProject.StudentDAO
{
	class StudentDetailsDAO
	{
		public static int StudentMarkInsert(StudentDetails objStudent)
		{
			int output = 0;
			string sql = "";
			SqlConnection con = null;
			SqlCommand cmd = null;
			try
			{
				sql = "insert into StudentTable(studentId,studentName,mark1,mark2,mark3,total,result) values(";
				sql = sql + "'" + objStudent.StudentId + "',";
				sql = sql + "'" + objStudent.StudentName + "',";
				sql = sql + objStudent.Mark1 + ",";
				sql = sql + objStudent.Mark2 + ",";
				sql = sql + objStudent.Mark3 + ",";
				sql = sql + objStudent.Total + ",";
				sql = sql + "'" + objStudent.Result + "')";

				con = DBHelper.GetConnection();
				con.Open();
				cmd = new SqlCommand(sql, con);
				output = cmd.ExecuteNonQuery();
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine("Error : StudentMarkDao : StudentMarkInsert() " + ex.Message.ToString());
			}
			finally
			{
				con.Close();
				cmd.Dispose();
			}
			return output;
		}

		public static DataSet GetStudentIds()
		{
			string sql = "";
			SqlConnection con = null;
			SqlDataAdapter adapter = null;
			DataSet dsStudents = null;
			try
			{
				sql = "select studentId from StudentTable";
				con = DBHelper.GetConnection();
				con.Open();
				dsStudents = new DataSet();
				adapter = new SqlDataAdapter(sql, con);
				adapter.Fill(dsStudents);

			}
			catch (Exception ex)
			{
				Console.Out.WriteLine("Error : StudentMarkDao : GetStudentIds() " + ex.Message.ToString());
			}
			finally
			{
				con.Close();
				adapter.Dispose();
			}

			return dsStudents;
		}
	}
}
