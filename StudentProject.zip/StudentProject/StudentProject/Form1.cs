﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using StudentProject.StudentDTO;
using StudentProject.StudentBL;

namespace StudentProject
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void btnSave_Click(object sender, EventArgs e)
		{
			StudentDetails objStudent = new StudentDetails();

			int output = 0;
			try
			{
				objStudent = new StudentDetails();
				objStudent.StudentId = textBoxId.Text;
				objStudent.StudentName = textBoxName.Text;
				objStudent.Mark1 = Convert.ToInt32(textBoxMark1.Text);
				objStudent.Mark2 = Convert.ToInt32(textBoxMark2.Text);
				objStudent.Mark3 = Convert.ToInt32(textBoxMark3.Text);

				//output = StudentDetailsBL.StudentInsertMark(objStudent);

				if (objStudent.Mark1 < 0 || objStudent.Mark2 > 100)
				{
					lblmsg.Text = "Mark should be between 0-100";
					textBoxMark1.Focus();
				}
				else
				{
					output = StudentDetailsBL.StudentInsertMark(objStudent);
					if (output > 0)
					{
						lblmsg.Text = "ADDED SUCCESSFULLY";
					}
					else
					{
						lblmsg.Text = "FAILED";
					}
				}
			}
			catch (Exception ex)
			{
				lblmsg.Text = ex.Message.ToString();
			}
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			// TODO: This line of code loads data into the 'database1DataSet.StudentTable' table. You can move, or remove it, as needed.
			//this.studentTableTableAdapter.Fill(this.database1DataSet.StudentTable);
			LoadStudentIds();
		}
		private void LoadStudentIds()
		{
			DataSet dsStudentIds = null;
			try
			{

				dsStudentIds = StudentDetailsBL.GetStudentIds();
				if (dsStudentIds != null)
				{
					comboBoxIds.DataSource = dsStudentIds.Tables[0];
					comboBoxIds.ValueMember = "student_id";
					comboBoxIds.DisplayMember = "student_id";
				}
				else
				{
					lblMessage.Text = "No students available";
				}


			}
			catch (Exception ex)
			{
				lblmsg.Text = ex.Message.ToString();
			}
		}
	}
}
