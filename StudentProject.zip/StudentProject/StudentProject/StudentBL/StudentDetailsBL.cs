﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StudentProject.StudentDTO;
using StudentProject.StudentDAO;
using System.Data;

namespace StudentProject.StudentBL
{
	class StudentDetailsBL
	{
		public static int StudentInsertMark(StudentDetails objStudent)
		{
			int output = 0;
			try
			{
				objStudent.Total = objStudent.Mark1 + objStudent.Mark2 + objStudent.Mark3;
				if (objStudent.Mark1 < 50 || objStudent.Mark2 < 50 || objStudent.Mark3 < 50)
				{
					objStudent.Result = "FAIL";
				}
				else
				{
					objStudent.Result = "PASS";
				}
				output = StudentDetailsDAO.StudentMarkInsert(objStudent);
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine("Error : StudentMarkBl : StudentInsertMark() " + ex.Message.ToString());
			}
			return output;
		}

		public static DataSet GetStudentIds()
		{
			DataSet dsStudents = null;
			try
			{
				dsStudents = StudentDetailsDAO.GetStudentIds();

			}
			catch (Exception ex)
			{
				Console.Out.WriteLine("Error : StudentMarkBl:GetStudentIds : " + ex.Message.ToString());
			}
			return dsStudents;
		}
	}
}
