﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PocketMoneyDTO.PocketMoneyDTObject;
using PocketMoneyDSL.Helper;
using System.Data;

namespace PocketMoneyDSL.PocketMoneyDSLayer
{
	public class PocketMoneyDS
	{
		public static int InsertTransactionDetails(PocketMoney objPocketMoney)
		{
			int output = 0;
			string sql = "";
			SqlConnection con = null;
			SqlCommand cmd = null;
			try
			{
				sql = "insert into PocketMoneyTable(slNo,description,dateOfTransaction,transactionType,amount,balanceAmount) values(";
				sql = sql + "" + objPocketMoney.SlNo + ",";
				sql = sql + "'" + objPocketMoney.Description + "',";
				sql = sql + "'" + objPocketMoney.DateOfTransaction + "',";
				sql = sql + "'" + objPocketMoney.TransactionType + "',";
				sql = sql + "" + objPocketMoney.Amount + ",";
				sql = sql + "" + objPocketMoney.BalanceAmount + ")";

				con = DBHelper.GetConnection();
				con.Open();
				cmd = new SqlCommand(sql, con);
				output = cmd.ExecuteNonQuery();
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine("Error : PocketMoneyDS : InsertTransactionDetails() " + ex.Message.ToString());
			}
			finally
			{
				con.Close();
				cmd.Dispose();
			}
			return output;
		}
		public static int UpdateTransactionDetails(PocketMoney objPocketMoney)
		{
			int output = 0;
			string sql = "";
			SqlConnection con = null;
			SqlCommand cmd = null;
			try
			{
				sql = "update PocketMoneyTable set ";
				//sql = sql + "slNo=" + objPocketMoney.SlNo + ",";
				sql = sql + "description='" + objPocketMoney.Description + "',";
				sql = sql + "dateOfTransaction='" + objPocketMoney.DateOfTransaction + "',";
				sql = sql + "transactionType='" + objPocketMoney.TransactionType + "',";
				sql = sql + "amount=" + objPocketMoney.Amount + ",";
				sql = sql + "balanceAmount=" + objPocketMoney.BalanceAmount + " ";
				sql = sql + "where slNo=" + objPocketMoney.SlNo;

				con = DBHelper.GetConnection();
				con.Open();
				cmd = new SqlCommand(sql, con);
				output = cmd.ExecuteNonQuery();
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine("Error : PocketMoneyDS : UpdateTransactionDetails() " + ex.Message.ToString());
			}
			finally
			{
				con.Close();
				cmd.Dispose();
			}
			return output;
		}
		public static DataSet LoadTransactionSlNos()
		{
			string sql = "";
			SqlConnection con = null;
			SqlDataAdapter adapter = null;
			DataSet dsTransactionNos = null;
			try
			{
				sql = "select slNo from PocketMoneyTable";

				con = DBHelper.GetConnection();
				con.Open();
				dsTransactionNos = new DataSet();
				adapter = new SqlDataAdapter(sql, con);
				adapter.Fill(dsTransactionNos);
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine(" Error : PocketMoneyDS : LoadTransactionSlNos() " + ex.Message.ToString());
			}
			finally
			{
				con.Close();
				adapter.Dispose();
			}
			return dsTransactionNos;
		}
		public static PocketMoney GetTransactionByNos(string slNo)
		{
			string sql = "";
			SqlConnection con = null;
			SqlDataAdapter adapter = null;
			DataSet dsTransactionDetails = null;
			PocketMoney objPocketMoney = null;
			try
			{
				sql = "select * from pocketMoneyTable where slNo=" + slNo;

				con = DBHelper.GetConnection();
				con.Open();
				dsTransactionDetails = new DataSet();
				adapter = new SqlDataAdapter(sql, con);
				adapter.Fill(dsTransactionDetails);

				Object[] Data = null;

				if (dsTransactionDetails.Tables[0].Rows.Count > 0)
				{
					Data = dsTransactionDetails.Tables[0].Rows[0].ItemArray;
					objPocketMoney = new PocketMoney();
					objPocketMoney.SlNo = Convert.ToInt32(Data[0].ToString());
					objPocketMoney.Description = Data[1].ToString();			
					if (Data[3].ToString() == "Credit")
					{
						objPocketMoney.TransactionType = "Credit";
					}
					else
					{
						objPocketMoney.TransactionType = "Debit";
					}
					objPocketMoney.Amount = Convert.ToInt64(Data[4].ToString());
				}
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine(" Error : PocketMoneyDS : GetTransactionByNos() " + ex.Message.ToString());
			}
			finally
			{
				con.Close();
				adapter.Dispose();
			}
			return objPocketMoney;
		}
		public static int GetLastSlNo()
		{
			string sql = "";
			SqlConnection con = null;
			SqlDataAdapter adapter = null;
			DataSet dsTransactions = null;
			int lastSlNo = 0;
			Object[] Data = null;
			try
			{
				sql = "select slNo from PocketMoneyTable order by slNo desc";
				con = DBHelper.GetConnection();
				con.Open();
				dsTransactions = new DataSet();
				adapter = new SqlDataAdapter(sql, con);
				adapter.Fill(dsTransactions);

				if (dsTransactions.Tables[0].Rows.Count > 0)
				{
					Data = dsTransactions.Tables[0].Rows[0].ItemArray;
					lastSlNo = Convert.ToInt32(Data[0].ToString());
				}
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine("Error : PocketMoneyDS : GetLastSlNo() " + ex.Message.ToString());
			}
			finally
			{
				con.Close();
				adapter.Dispose();
			}

			return lastSlNo;
		}
		public static double GetBalanceAmount()
		{
			string sql = "";
			SqlConnection con = null;
			SqlDataAdapter adapter = null;
			DataSet dsTransactions = null;
			double balanceAmount = 0;
			Object[] Data = null;
			try
			{
				sql = "select balanceAmount from PocketMoneyTable";
				con = DBHelper.GetConnection();
				con.Open();
				dsTransactions = new DataSet();
				adapter = new SqlDataAdapter(sql, con);
				adapter.Fill(dsTransactions);

				if (dsTransactions.Tables[0].Rows.Count > 0)
				{
					Data = dsTransactions.Tables[0].Rows[0].ItemArray;
					balanceAmount = Convert.ToInt32(Data[0].ToString());
				}
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine("Error : PocketMoneyDS : GetBalanceAmount() " + ex.Message.ToString());
			}
			finally
			{
				con.Close();
				adapter.Dispose();
			}

			return balanceAmount;
		}
		public static int DeleteTransactionDetails(int  slNo)
		{
			int output = 0;
			string sql = "";
			SqlConnection con = null;
			SqlCommand cmd = null;
			try
			{
				sql = "delete from PocketMoneyTable where slNo=" + slNo;
				

				con = DBHelper.GetConnection();
				con.Open();
				cmd = new SqlCommand(sql, con);
				output = cmd.ExecuteNonQuery();
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine("Error : PocketMoneyDS : UpdateTransactionDetails() " + ex.Message.ToString());
			}
			finally
			{
				con.Close();
				cmd.Dispose();
			}
			return output;
		}
		public static DataSet GetTransactionLike(string category, string like)
		{
			string sql = "";
			SqlConnection con = null;
			SqlDataAdapter adapter = null;
			DataSet dsTransactionDetails = null;
			try
			{
				sql = "select * from PocketMoneyTable where " + category + " like '" + like + "%'";

				con = DBHelper.GetConnection();
				con.Open();
				dsTransactionDetails = new DataSet();
				adapter = new SqlDataAdapter(sql, con);
				adapter.Fill(dsTransactionDetails);
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine(" Error : PocketMoneyDS : GetTransactionLike() " + ex.Message.ToString());
			}
			finally
			{
				con.Close();
				adapter.Dispose();
			}
			return dsTransactionDetails;
		}
		public static DataSet GetTransactionDetails()
		{
			string sql = "";
			SqlConnection con = null;
			SqlDataAdapter adapter = null;
			DataSet dsTransactions = null;
			try
			{
				sql = "select * from PocketMoneyTable";

				con = DBHelper.GetConnection();
				con.Open();
				dsTransactions = new DataSet();
				adapter = new SqlDataAdapter(sql, con);
				adapter.Fill(dsTransactions);
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine(" Error : PocketMoneyDS : LoadTransactionSlNos() " + ex.Message.ToString());
			}
			finally
			{
				con.Close();
				adapter.Dispose();
			}
			return dsTransactions;
		}
	}
}
