﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PocketMoneyDSL.Helper
{
	public class DBHelper
	{
		public static SqlConnection GetConnection()
		{
			SqlConnection con = null;
			String ConnectionString = null;
			try
			{
				ConnectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=D:\\JINSHA\\PocketMoneyDSL\\Data\\PocketMoneyDB.mdf;Integrated Security=True";
				con = new SqlConnection(ConnectionString);
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine(ex.Message.ToString());
			}
			return con;
		}
	}
}
