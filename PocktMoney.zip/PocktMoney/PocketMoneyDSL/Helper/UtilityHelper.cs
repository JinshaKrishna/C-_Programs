﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PocketMoneyDSL.Helper
{
	public class UtilityHelper
	{
		public static int GenerateSlNo(int oldSlNo)
		{
			int newSlNo=0;
			try
			{
				newSlNo = oldSlNo + 1;
			}
			catch (Exception e3)
			{
				Console.Out.WriteLine(" Error : UtilityHelper : GenerateSlNo()" + e3.Message.ToString());

			}
			return newSlNo;
		}
	}
}
