﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PocketMoneyDTO.PocketMoneyDTObject
{
	public class PocketMoney
	{
		private int slNo;
		public int SlNo
		{
			get { return slNo; }
			set { slNo = value; }
		}
		private string description;

		public string Description
		{
			get { return description; }
			set { description = value; }
		}
		private string dateOfTransaction;

		public string DateOfTransaction
		{
			get { return dateOfTransaction; }
			set { dateOfTransaction = value; }
		}
		private string transactionType;

		public string TransactionType
		{
			get { return transactionType; }
			set { transactionType = value; }
		}
		private double amount;

		public double Amount
		{
			get { return amount; }
			set { amount = value; }
		}
		private double balanceAmount;

		public double BalanceAmount
		{
			get { return balanceAmount; }
			set { balanceAmount = value; }
		}

	}
}
