﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PocketMoneyDTO.PocketMoneyDTObject;
using PocketMoneyBLL.PocketMoneyBLLayer;

namespace PocketMoneyPLayer.PocketMoneyPL
{
	public partial class SearchForm : Form
	{
		public SearchForm()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			this.Visible = false;
			PocketMoneyPLF objPL = new PocketMoneyPLF();
			objPL.Visible = true;
		}

		private void buttonSearch_Click(object sender, EventArgs e)
		{
			if (comboBoxSearch.Text == string.Empty)
			{
				labelSearchMessage.Text = "Please select an option to search.";
			}
			else if (textBoxSearch.Text == string.Empty)
			{
				labelSearchMessage.Text = "Please Enter atleast first character.";
			}
		
		}

		private void SearchForm_Load(object sender, EventArgs e)
		{
			comboBoxSearch.Items.Add("Sl No");
			comboBoxSearch.Items.Add("Description");
			comboBoxSearch.Items.Add("Date of Transaction");
			comboBoxSearch.Items.Add("Transaction Type");
			comboBoxSearch.Items.Add("Transaction Amount");
		}

		private void textBoxSearch_TextChanged(object sender, EventArgs e)
		{
			if (comboBoxSearch.Text == string.Empty)
			{
				labelSearchMessage.Text = "Please select an option to search.";
			}
			else
			{
				labelSearchMessage.Text = "";
				DataSet dsPocketMoney = null;
				string category = null;
				try
				{
					if (comboBoxSearch.Text == "Sl No")
					{
						category = "slNo";
					}
					if (comboBoxSearch.Text == "Description")
					{
						category = "description";
					}
					if (comboBoxSearch.Text == "Date of Transaction")
					{
						category = "dateOfTransaction";
					}
					if (comboBoxSearch.Text == "Transaction Type")
					{
						category = "transactionType";
					}
					if (comboBoxSearch.Text == "Transaction Amount")
					{
						category = "amount";
					}

					string like = textBoxSearch.Text;
					dsPocketMoney = PocketMoneyBL.GetTransactionLike(category, like);
					if (dsPocketMoney != null)
					{
						dataGridViewSearch.DataSource = dsPocketMoney.Tables[0];
					}
					else
					{
						labelSearchMessage.Text = "No Details Available in Transaction Details";
					}
				}
				catch (Exception ex)
				{
					Console.Out.WriteLine(ex.Message.ToString());
				}
			}
		}
	}
}
