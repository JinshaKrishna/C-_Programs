﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PocketMoneyPLayer.PocketMoneyPL
{
	public partial class PocketMoneyPLF : Form
	{
		public PocketMoneyPLF()
		{
			InitializeComponent();
		}

		private void buttonInsert_Click(object sender, EventArgs e)
		{
			this.Visible = false;
			InsertForm objInsertForm = new InsertForm();
			objInsertForm.Visible = true;
		}

		private void buttonUpdate_Click(object sender, EventArgs e)
		{
			this.Visible = false;
			UpdateForm objUpdateForm = new UpdateForm();
			objUpdateForm.Visible = true;
		}

		private void buttonDelete_Click(object sender, EventArgs e)
		{
			this.Visible = false;
			DeleteForm objDeleteForm = new DeleteForm();
			objDeleteForm.Visible = true;
		}

		private void buttonSearch_Click(object sender, EventArgs e)
		{
			this.Visible = false;
			SearchForm objSearchForm = new SearchForm();
			objSearchForm.Visible = true;
		}

		private void buttonView_Click(object sender, EventArgs e)
		{
			this.Visible = false;
			ViewForm objViewForm = new ViewForm();
			objViewForm.Visible = true;
		}
	}
}
