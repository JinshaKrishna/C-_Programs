﻿namespace PocketMoneyPLayer.PocketMoneyPL
{
	partial class UpdateForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.panel1 = new System.Windows.Forms.Panel();
			this.buttonEdit = new System.Windows.Forms.Button();
			this.textBoxAmountEdit = new System.Windows.Forms.TextBox();
			this.label7 = new System.Windows.Forms.Label();
			this.radioButtonDebitEdit = new System.Windows.Forms.RadioButton();
			this.radioButtonCreditEdit = new System.Windows.Forms.RadioButton();
			this.label6 = new System.Windows.Forms.Label();
			this.comboBoxDescriptionEdit = new System.Windows.Forms.ComboBox();
			this.label4 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.labelUpdateMessage = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.buttonBack = new System.Windows.Forms.Button();
			this.comboBoxSlNoEdit = new System.Windows.Forms.ComboBox();
			this.panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.comboBoxSlNoEdit);
			this.panel1.Controls.Add(this.buttonEdit);
			this.panel1.Controls.Add(this.textBoxAmountEdit);
			this.panel1.Controls.Add(this.label7);
			this.panel1.Controls.Add(this.radioButtonDebitEdit);
			this.panel1.Controls.Add(this.radioButtonCreditEdit);
			this.panel1.Controls.Add(this.label6);
			this.panel1.Controls.Add(this.comboBoxDescriptionEdit);
			this.panel1.Controls.Add(this.label4);
			this.panel1.Controls.Add(this.label3);
			this.panel1.Controls.Add(this.labelUpdateMessage);
			this.panel1.Controls.Add(this.label2);
			this.panel1.Location = new System.Drawing.Point(57, 61);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(691, 456);
			this.panel1.TabIndex = 1;
			// 
			// buttonEdit
			// 
			this.buttonEdit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.buttonEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.buttonEdit.ForeColor = System.Drawing.Color.White;
			this.buttonEdit.Location = new System.Drawing.Point(342, 343);
			this.buttonEdit.Name = "buttonEdit";
			this.buttonEdit.Size = new System.Drawing.Size(95, 39);
			this.buttonEdit.TabIndex = 18;
			this.buttonEdit.Text = "EDIT";
			this.buttonEdit.UseVisualStyleBackColor = false;
			this.buttonEdit.Click += new System.EventHandler(this.buttonEdit_Click);
			// 
			// textBoxAmountEdit
			// 
			this.textBoxAmountEdit.Location = new System.Drawing.Point(262, 262);
			this.textBoxAmountEdit.Name = "textBoxAmountEdit";
			this.textBoxAmountEdit.Size = new System.Drawing.Size(200, 20);
			this.textBoxAmountEdit.TabIndex = 17;
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label7.Location = new System.Drawing.Point(56, 262);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(120, 13);
			this.label7.TabIndex = 16;
			this.label7.Text = "Transaction Amount";
			// 
			// radioButtonDebitEdit
			// 
			this.radioButtonDebitEdit.AutoSize = true;
			this.radioButtonDebitEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.radioButtonDebitEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.radioButtonDebitEdit.Location = new System.Drawing.Point(342, 205);
			this.radioButtonDebitEdit.Name = "radioButtonDebitEdit";
			this.radioButtonDebitEdit.Size = new System.Drawing.Size(50, 17);
			this.radioButtonDebitEdit.TabIndex = 15;
			this.radioButtonDebitEdit.TabStop = true;
			this.radioButtonDebitEdit.Text = "Debit";
			this.radioButtonDebitEdit.UseVisualStyleBackColor = true;
			// 
			// radioButtonCreditEdit
			// 
			this.radioButtonCreditEdit.AutoSize = true;
			this.radioButtonCreditEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.radioButtonCreditEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.radioButtonCreditEdit.Location = new System.Drawing.Point(262, 205);
			this.radioButtonCreditEdit.Name = "radioButtonCreditEdit";
			this.radioButtonCreditEdit.Size = new System.Drawing.Size(52, 17);
			this.radioButtonCreditEdit.TabIndex = 14;
			this.radioButtonCreditEdit.TabStop = true;
			this.radioButtonCreditEdit.Text = "Credit";
			this.radioButtonCreditEdit.UseVisualStyleBackColor = true;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label6.Location = new System.Drawing.Point(56, 209);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(102, 13);
			this.label6.TabIndex = 13;
			this.label6.Text = "Transaction type";
			// 
			// comboBoxDescriptionEdit
			// 
			this.comboBoxDescriptionEdit.FormattingEnabled = true;
			this.comboBoxDescriptionEdit.Location = new System.Drawing.Point(262, 141);
			this.comboBoxDescriptionEdit.Name = "comboBoxDescriptionEdit";
			this.comboBoxDescriptionEdit.Size = new System.Drawing.Size(200, 21);
			this.comboBoxDescriptionEdit.TabIndex = 10;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label4.Location = new System.Drawing.Point(56, 149);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(71, 13);
			this.label4.TabIndex = 9;
			this.label4.Text = "Description";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label3.Location = new System.Drawing.Point(56, 102);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(42, 13);
			this.label3.TabIndex = 7;
			this.label3.Text = "Sl.No.";
			// 
			// labelUpdateMessage
			// 
			this.labelUpdateMessage.AutoSize = true;
			this.labelUpdateMessage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.labelUpdateMessage.Location = new System.Drawing.Point(219, 52);
			this.labelUpdateMessage.Name = "labelUpdateMessage";
			this.labelUpdateMessage.Size = new System.Drawing.Size(0, 13);
			this.labelUpdateMessage.TabIndex = 6;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.ForeColor = System.Drawing.Color.Navy;
			this.label2.Location = new System.Drawing.Point(208, 12);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(259, 20);
			this.label2.TabIndex = 0;
			this.label2.Text = "EDIT TRANSACTION DETAILS";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Lucida Calligraphy", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.Purple;
			this.label1.Location = new System.Drawing.Point(253, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(256, 31);
			this.label1.TabIndex = 19;
			this.label1.Text = "POCKET MONEY";
			// 
			// buttonBack
			// 
			this.buttonBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.buttonBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.buttonBack.ForeColor = System.Drawing.Color.White;
			this.buttonBack.Location = new System.Drawing.Point(12, 9);
			this.buttonBack.Name = "buttonBack";
			this.buttonBack.Size = new System.Drawing.Size(38, 29);
			this.buttonBack.TabIndex = 20;
			this.buttonBack.Text = "<-";
			this.buttonBack.UseVisualStyleBackColor = false;
			this.buttonBack.Click += new System.EventHandler(this.buttonBack_Click);
			// 
			// comboBoxSlNoEdit
			// 
			this.comboBoxSlNoEdit.FormattingEnabled = true;
			this.comboBoxSlNoEdit.Location = new System.Drawing.Point(262, 94);
			this.comboBoxSlNoEdit.Name = "comboBoxSlNoEdit";
			this.comboBoxSlNoEdit.Size = new System.Drawing.Size(200, 21);
			this.comboBoxSlNoEdit.TabIndex = 19;
			this.comboBoxSlNoEdit.SelectedIndexChanged += new System.EventHandler(this.comboBoxSlNoEdit_SelectedIndexChanged);
			// 
			// UpdateForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 531);
			this.Controls.Add(this.buttonBack);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.panel1);
			this.Name = "UpdateForm";
			this.Text = "UpdateForm";
			this.Load += new System.EventHandler(this.UpdateForm_Load);
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Button buttonEdit;
		private System.Windows.Forms.TextBox textBoxAmountEdit;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.RadioButton radioButtonDebitEdit;
		private System.Windows.Forms.RadioButton radioButtonCreditEdit;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.ComboBox comboBoxDescriptionEdit;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label labelUpdateMessage;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button buttonBack;
		private System.Windows.Forms.ComboBox comboBoxSlNoEdit;
	}
}