﻿namespace PocketMoneyPLayer.PocketMoneyPL
{
	partial class SearchForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.panelSearch = new System.Windows.Forms.Panel();
			this.label2 = new System.Windows.Forms.Label();
			this.labelSearchMessage = new System.Windows.Forms.Label();
			this.dataGridViewSearch = new System.Windows.Forms.DataGridView();
			this.labelSearchBy = new System.Windows.Forms.Label();
			this.comboBoxSearch = new System.Windows.Forms.ComboBox();
			this.textBoxSearch = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.button1 = new System.Windows.Forms.Button();
			this.panelSearch.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridViewSearch)).BeginInit();
			this.SuspendLayout();
			// 
			// panelSearch
			// 
			this.panelSearch.Controls.Add(this.label2);
			this.panelSearch.Controls.Add(this.labelSearchMessage);
			this.panelSearch.Controls.Add(this.dataGridViewSearch);
			this.panelSearch.Controls.Add(this.labelSearchBy);
			this.panelSearch.Controls.Add(this.comboBoxSearch);
			this.panelSearch.Controls.Add(this.textBoxSearch);
			this.panelSearch.Location = new System.Drawing.Point(112, 86);
			this.panelSearch.Name = "panelSearch";
			this.panelSearch.Size = new System.Drawing.Size(551, 486);
			this.panelSearch.TabIndex = 28;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.ForeColor = System.Drawing.Color.Navy;
			this.label2.Location = new System.Drawing.Point(150, 14);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(292, 20);
			this.label2.TabIndex = 29;
			this.label2.Text = "SEARCH TRANSACTION DETAILS";
			// 
			// labelSearchMessage
			// 
			this.labelSearchMessage.AutoSize = true;
			this.labelSearchMessage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.labelSearchMessage.Location = new System.Drawing.Point(182, 52);
			this.labelSearchMessage.Name = "labelSearchMessage";
			this.labelSearchMessage.Size = new System.Drawing.Size(0, 13);
			this.labelSearchMessage.TabIndex = 27;
			// 
			// dataGridViewSearch
			// 
			this.dataGridViewSearch.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridViewSearch.Location = new System.Drawing.Point(32, 197);
			this.dataGridViewSearch.Name = "dataGridViewSearch";
			this.dataGridViewSearch.Size = new System.Drawing.Size(496, 268);
			this.dataGridViewSearch.TabIndex = 25;
			// 
			// labelSearchBy
			// 
			this.labelSearchBy.AutoSize = true;
			this.labelSearchBy.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.labelSearchBy.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.labelSearchBy.Location = new System.Drawing.Point(29, 110);
			this.labelSearchBy.Name = "labelSearchBy";
			this.labelSearchBy.Size = new System.Drawing.Size(71, 15);
			this.labelSearchBy.TabIndex = 22;
			this.labelSearchBy.Text = "Search By";
			// 
			// comboBoxSearch
			// 
			this.comboBoxSearch.FormattingEnabled = true;
			this.comboBoxSearch.Location = new System.Drawing.Point(185, 104);
			this.comboBoxSearch.Name = "comboBoxSearch";
			this.comboBoxSearch.Size = new System.Drawing.Size(190, 21);
			this.comboBoxSearch.TabIndex = 3;
			// 
			// textBoxSearch
			// 
			this.textBoxSearch.Location = new System.Drawing.Point(32, 151);
			this.textBoxSearch.Name = "textBoxSearch";
			this.textBoxSearch.Size = new System.Drawing.Size(343, 20);
			this.textBoxSearch.TabIndex = 23;
			this.textBoxSearch.TextChanged += new System.EventHandler(this.textBoxSearch_TextChanged);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Lucida Calligraphy", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.Purple;
			this.label1.Location = new System.Drawing.Point(260, 18);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(256, 31);
			this.label1.TabIndex = 29;
			this.label1.Text = "POCKET MONEY";
			// 
			// button1
			// 
			this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button1.ForeColor = System.Drawing.Color.White;
			this.button1.Location = new System.Drawing.Point(12, 12);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(38, 29);
			this.button1.TabIndex = 30;
			this.button1.Text = "<-";
			this.button1.UseVisualStyleBackColor = false;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// SearchForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 650);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.panelSearch);
			this.Name = "SearchForm";
			this.Text = "SearchForm";
			this.Load += new System.EventHandler(this.SearchForm_Load);
			this.panelSearch.ResumeLayout(false);
			this.panelSearch.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridViewSearch)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Panel panelSearch;
		private System.Windows.Forms.Label labelSearchMessage;
		private System.Windows.Forms.DataGridView dataGridViewSearch;
		private System.Windows.Forms.Label labelSearchBy;
		private System.Windows.Forms.ComboBox comboBoxSearch;
		private System.Windows.Forms.TextBox textBoxSearch;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button button1;
	}
}