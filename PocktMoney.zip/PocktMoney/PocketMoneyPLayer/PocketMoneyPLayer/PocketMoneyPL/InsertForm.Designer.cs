﻿namespace PocketMoneyPLayer.PocketMoneyPL
{
	partial class InsertForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.panel1 = new System.Windows.Forms.Panel();
			this.buttonSave = new System.Windows.Forms.Button();
			this.textBoxAmount = new System.Windows.Forms.TextBox();
			this.label7 = new System.Windows.Forms.Label();
			this.radioButtonDebit = new System.Windows.Forms.RadioButton();
			this.radioButtonCredit = new System.Windows.Forms.RadioButton();
			this.label6 = new System.Windows.Forms.Label();
			this.comboBoxDescription = new System.Windows.Forms.ComboBox();
			this.label4 = new System.Windows.Forms.Label();
			this.textBoxSlNo = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.labelInsertMessage = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.button1 = new System.Windows.Forms.Button();
			this.labelBalanceMessage = new System.Windows.Forms.Label();
			this.panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.labelBalanceMessage);
			this.panel1.Controls.Add(this.buttonSave);
			this.panel1.Controls.Add(this.textBoxAmount);
			this.panel1.Controls.Add(this.label7);
			this.panel1.Controls.Add(this.radioButtonDebit);
			this.panel1.Controls.Add(this.radioButtonCredit);
			this.panel1.Controls.Add(this.label6);
			this.panel1.Controls.Add(this.comboBoxDescription);
			this.panel1.Controls.Add(this.label4);
			this.panel1.Controls.Add(this.textBoxSlNo);
			this.panel1.Controls.Add(this.label3);
			this.panel1.Controls.Add(this.labelInsertMessage);
			this.panel1.Controls.Add(this.label2);
			this.panel1.Location = new System.Drawing.Point(21, 60);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(691, 456);
			this.panel1.TabIndex = 0;
			// 
			// buttonSave
			// 
			this.buttonSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.buttonSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.buttonSave.ForeColor = System.Drawing.Color.White;
			this.buttonSave.Location = new System.Drawing.Point(342, 343);
			this.buttonSave.Name = "buttonSave";
			this.buttonSave.Size = new System.Drawing.Size(95, 39);
			this.buttonSave.TabIndex = 18;
			this.buttonSave.Text = "SAVE";
			this.buttonSave.UseVisualStyleBackColor = false;
			this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
			// 
			// textBoxAmount
			// 
			this.textBoxAmount.Location = new System.Drawing.Point(262, 255);
			this.textBoxAmount.Name = "textBoxAmount";
			this.textBoxAmount.Size = new System.Drawing.Size(200, 20);
			this.textBoxAmount.TabIndex = 17;
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label7.Location = new System.Drawing.Point(56, 262);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(120, 13);
			this.label7.TabIndex = 16;
			this.label7.Text = "Transaction Amount";
			// 
			// radioButtonDebit
			// 
			this.radioButtonDebit.AutoSize = true;
			this.radioButtonDebit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.radioButtonDebit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.radioButtonDebit.Location = new System.Drawing.Point(342, 211);
			this.radioButtonDebit.Name = "radioButtonDebit";
			this.radioButtonDebit.Size = new System.Drawing.Size(50, 17);
			this.radioButtonDebit.TabIndex = 15;
			this.radioButtonDebit.TabStop = true;
			this.radioButtonDebit.Text = "Debit";
			this.radioButtonDebit.UseVisualStyleBackColor = true;
			// 
			// radioButtonCredit
			// 
			this.radioButtonCredit.AutoSize = true;
			this.radioButtonCredit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.radioButtonCredit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.radioButtonCredit.Location = new System.Drawing.Point(262, 211);
			this.radioButtonCredit.Name = "radioButtonCredit";
			this.radioButtonCredit.Size = new System.Drawing.Size(52, 17);
			this.radioButtonCredit.TabIndex = 14;
			this.radioButtonCredit.TabStop = true;
			this.radioButtonCredit.Text = "Credit";
			this.radioButtonCredit.UseVisualStyleBackColor = true;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label6.Location = new System.Drawing.Point(56, 211);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(102, 13);
			this.label6.TabIndex = 13;
			this.label6.Text = "Transaction type";
			// 
			// comboBoxDescription
			// 
			this.comboBoxDescription.FormattingEnabled = true;
			this.comboBoxDescription.Location = new System.Drawing.Point(262, 141);
			this.comboBoxDescription.Name = "comboBoxDescription";
			this.comboBoxDescription.Size = new System.Drawing.Size(200, 21);
			this.comboBoxDescription.TabIndex = 10;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label4.Location = new System.Drawing.Point(56, 149);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(71, 13);
			this.label4.TabIndex = 9;
			this.label4.Text = "Description";
			// 
			// textBoxSlNo
			// 
			this.textBoxSlNo.Location = new System.Drawing.Point(262, 95);
			this.textBoxSlNo.Name = "textBoxSlNo";
			this.textBoxSlNo.Size = new System.Drawing.Size(200, 20);
			this.textBoxSlNo.TabIndex = 8;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.label3.Location = new System.Drawing.Point(56, 102);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(42, 13);
			this.label3.TabIndex = 7;
			this.label3.Text = "Sl.No.";
			// 
			// labelInsertMessage
			// 
			this.labelInsertMessage.AutoSize = true;
			this.labelInsertMessage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.labelInsertMessage.Location = new System.Drawing.Point(219, 52);
			this.labelInsertMessage.Name = "labelInsertMessage";
			this.labelInsertMessage.Size = new System.Drawing.Size(0, 13);
			this.labelInsertMessage.TabIndex = 6;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.ForeColor = System.Drawing.Color.Navy;
			this.label2.Location = new System.Drawing.Point(208, 12);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(256, 20);
			this.label2.TabIndex = 0;
			this.label2.Text = "ADD TRANSACTION DETAILS";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Lucida Calligraphy", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.Purple;
			this.label1.Location = new System.Drawing.Point(227, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(256, 31);
			this.label1.TabIndex = 5;
			this.label1.Text = "POCKET MONEY";
			// 
			// button1
			// 
			this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button1.ForeColor = System.Drawing.Color.White;
			this.button1.Location = new System.Drawing.Point(12, 9);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(38, 29);
			this.button1.TabIndex = 19;
			this.button1.Text = "<-";
			this.button1.UseVisualStyleBackColor = false;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// labelBalanceMessage
			// 
			this.labelBalanceMessage.AutoSize = true;
			this.labelBalanceMessage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.labelBalanceMessage.Location = new System.Drawing.Point(209, 309);
			this.labelBalanceMessage.Name = "labelBalanceMessage";
			this.labelBalanceMessage.Size = new System.Drawing.Size(35, 13);
			this.labelBalanceMessage.TabIndex = 19;
			this.labelBalanceMessage.Text = "label5";
			// 
			// InsertForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(755, 571);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.panel1);
			this.Name = "InsertForm";
			this.Text = "InsertForm";
			this.Load += new System.EventHandler(this.InsertForm_Load);
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Button buttonSave;
		private System.Windows.Forms.TextBox textBoxAmount;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.RadioButton radioButtonDebit;
		private System.Windows.Forms.RadioButton radioButtonCredit;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.ComboBox comboBoxDescription;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox textBoxSlNo;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label labelInsertMessage;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Label labelBalanceMessage;
	}
}