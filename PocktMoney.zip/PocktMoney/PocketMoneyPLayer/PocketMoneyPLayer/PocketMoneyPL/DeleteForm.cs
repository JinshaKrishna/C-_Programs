﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PocketMoneyDTO.PocketMoneyDTObject;
using PocketMoneyBLL.PocketMoneyBLLayer;

namespace PocketMoneyPLayer.PocketMoneyPL
{
	public partial class DeleteForm : Form
	{
		public DeleteForm()
		{
			InitializeComponent();
		}

		private void label19_Click(object sender, EventArgs e)
		{

		}

		private void buttonDelete_Click(object sender, EventArgs e)
		{
			LoadTransactionSlNos();
			if (comboBoxSlNo.Text == string.Empty)
			{
				labelMessage.Text = "Please Select one from Sl No To delete.";
			}
			else
			{
				int output = 0;
				try
				{
					if (MessageBox.Show("Do you want to Delete", "S I S", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
					{
						int slNo = Convert.ToInt32(comboBoxSlNo.Text);
						output = PocketMoneyBL.DeleteTransactionDetails(slNo);
						if (output > 0)
						{
							labelMessage.Text = "DATA DELETED SUCCESSULLY";

						}
						else
						{
							labelMessage.Text = "TRY AGAIN LATER";
						}
					}
				}
				catch (Exception ex)
				{
					Console.Out.WriteLine(ex.Message.ToString());
				}
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			this.Visible = false;
			PocketMoneyPLF objPL = new PocketMoneyPLF();
			objPL.Visible = true;
		}

		private void DeleteForm_Load(object sender, EventArgs e)
		{
			LoadTransactionSlNos();
		}
		public void LoadTransactionSlNos()
		{
			DataSet dsTransactionNos = null;
			try
			{
				dsTransactionNos = PocketMoneyBL.LoadTransactionSlNos();
				if (dsTransactionNos != null)
				{
					comboBoxSlNo.DataSource = dsTransactionNos.Tables[0];
					comboBoxSlNo.ValueMember = "slNo";
					comboBoxSlNo.DisplayMember = "slNo";
				}
				else
				{
					labelMessage.Text = "Not available";
				}
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine(ex.Message.ToString());
			}
		}
	}
}
