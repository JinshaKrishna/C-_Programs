﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PocketMoneyDTO.PocketMoneyDTObject;
using PocketMoneyBLL.PocketMoneyBLLayer;


namespace PocketMoneyPLayer.PocketMoneyPL
{
	public partial class UpdateForm : Form
	{
		public UpdateForm()
		{
			InitializeComponent();
		}

		private void buttonEdit_Click(object sender, EventArgs e)
		{
			if (comboBoxSlNoEdit.Text == string.Empty && comboBoxDescriptionEdit.Text == string.Empty && textBoxAmountEdit.Text == "")
			{
				labelUpdateMessage.Text = "All data are mandatory. Please provide it.";
			}
			else if (comboBoxDescriptionEdit.Text == string.Empty)
			{
				labelUpdateMessage.Text = "Please Select one from Description.";
			}

			else if (!radioButtonCreditEdit.Checked && !radioButtonDebitEdit.Checked)
			{
				labelUpdateMessage.Text = "Please check one from Transaction Type.";
			}
			else if (textBoxAmountEdit.Text == string.Empty)
			{
				labelUpdateMessage.Text = "Please Enter Transaction Amount.";
			}
			else
			{
				PocketMoney objPocketMoney = null;
				int output = 0;
				try
				{
					objPocketMoney = new PocketMoney();
					objPocketMoney.SlNo = Convert.ToInt32(comboBoxSlNoEdit.Text);
					objPocketMoney.Description = comboBoxDescriptionEdit.Text;
					DateTime today = DateTime.Today;
					objPocketMoney.DateOfTransaction = today.ToString();

					if (radioButtonCreditEdit.Checked)
					{
						objPocketMoney.TransactionType = radioButtonCreditEdit.Text;
					}
					else
					{
						objPocketMoney.TransactionType = radioButtonDebitEdit.Text;
					}
					objPocketMoney.Amount = Convert.ToInt64(textBoxAmountEdit.Text);
					double balanceAmount = PocketMoneyBL.GetBalanceAmount(objPocketMoney.Amount, objPocketMoney.TransactionType);
					objPocketMoney.BalanceAmount = balanceAmount;
					output = PocketMoneyBL.UpdateTransactionDetails(objPocketMoney);
					
					if (output > 0)
					{
						labelUpdateMessage.Text = "DATA EDITED SUCCESSFULLY";
					}
					else
					{
						labelUpdateMessage.Text = "EDITING FAILED";
					}
				}
				catch (Exception ex)
				{
					labelUpdateMessage.Text = ex.Message.ToString();
				}
			}
		}

		private void buttonBack_Click(object sender, EventArgs e)
		{
			this.Visible = false;
			PocketMoneyPLF objPL = new PocketMoneyPLF();
			objPL.Visible = true;
		}
		public void LoadTransactionSlNos()
		{
			DataSet dsTransactionNos = null;
			try
			{
				dsTransactionNos = PocketMoneyBL.LoadTransactionSlNos();
				if (dsTransactionNos != null)
				{
					comboBoxSlNoEdit.DataSource = dsTransactionNos.Tables[0];
					comboBoxSlNoEdit.ValueMember = "slNo";
					comboBoxSlNoEdit.DisplayMember = "slNo";
				}
				else
				{
					labelUpdateMessage.Text = "Not available";
				}
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine(ex.Message.ToString());
			}
		}

		private void UpdateForm_Load(object sender, EventArgs e)
		{
			comboBoxDescriptionEdit.Items.Add("FOOD");
			comboBoxDescriptionEdit.Items.Add("BANK");
			comboBoxDescriptionEdit.Items.Add("SHOPPING");
			comboBoxDescriptionEdit.Items.Add("RENT");
			comboBoxDescriptionEdit.Items.Add("OTHERS");
			LoadTransactionSlNos();
		}

		private void comboBoxSlNoEdit_SelectedIndexChanged(object sender, EventArgs e)
		{
			PocketMoney objPocketMoney = null;
			try
			{
				objPocketMoney = PocketMoneyBL.GetTransactionByNos(comboBoxSlNoEdit.Text);

				if (objPocketMoney != null)
				{
					comboBoxDescriptionEdit.Text = objPocketMoney.Description;
					if (objPocketMoney.TransactionType == "Credit")
					{
						radioButtonCreditEdit.Checked = true;
					}
					else
					{
						radioButtonDebitEdit.Checked = true;
					}
					textBoxAmountEdit.Text = objPocketMoney.Amount.ToString();
				}
			}
			catch (Exception ex)
			{
				labelUpdateMessage.Text = ex.Message.ToString();
			}
		}
	}
}
