﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PocketMoneyDTO.PocketMoneyDTObject;
using PocketMoneyBLL.PocketMoneyBLLayer;


namespace PocketMoneyPLayer.PocketMoneyPL
{
	public partial class ViewForm : Form
	{
		public ViewForm()
		{
			InitializeComponent();
		}

		private void ViewForm_Load(object sender, EventArgs e)
		{
			LoadTransactionDetails();
		}
		private void LoadTransactionDetails()
		{
			DataSet dsTransactionDetails = null;
			try
			{
				dsTransactionDetails = PocketMoneyBL.GetTransactionDetails();
				if (dsTransactionDetails != null)
				{
					dataGridViewTransaction.DataSource = dsTransactionDetails.Tables[0];
				}
				else
				{
					labelViewMessage.Text = "No Details Available in Address Book";
				}
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine(ex.Message.ToString());
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			this.Visible = false;
			PocketMoneyPLF objPL = new PocketMoneyPLF();
			objPL.Visible = true;
		}
	}
}
