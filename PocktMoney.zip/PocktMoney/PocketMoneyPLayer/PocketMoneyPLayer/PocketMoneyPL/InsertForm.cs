﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PocketMoneyDTO.PocketMoneyDTObject;
using PocketMoneyBLL.PocketMoneyBLLayer;

namespace PocketMoneyPLayer.PocketMoneyPL
{
	public partial class InsertForm : Form
	{
		public InsertForm()
		{
			InitializeComponent();
		}

		private void buttonSave_Click(object sender, EventArgs e)
		{
			if (textBoxSlNo.Text == string.Empty && comboBoxDescription.Text == string.Empty && textBoxAmount.Text == "")
			{
				labelInsertMessage.Text = "All data are mandatory. Please provide it.";
			}
			else if (comboBoxDescription.Text == string.Empty)
			{
				labelInsertMessage.Text = "Please Select one from Description.";
			}
			//else if (!radioButtonCredit.Checked && !radioButtonCredit.Checked)
			//{
			//	labelInsertMessage.Text = "Please check one from Transaction Type.";
			//}
			else if (textBoxAmount.Text == string.Empty)
			{
				labelInsertMessage.Text = "Please Enter Transaction Amount.";
			}
			else
			{
				PocketMoney objPocketMoney = null;
				int output = 0;
				try
				{
					objPocketMoney = new PocketMoney();
					objPocketMoney.SlNo = Convert.ToInt32(textBoxSlNo.Text);
					objPocketMoney.Description = comboBoxDescription.Text;
					DateTime today = DateTime.Today;
					objPocketMoney.DateOfTransaction = today.ToString();

					if (radioButtonCredit.Checked)
					{
						objPocketMoney.TransactionType = radioButtonCredit.Text;
					}
					else
					{
						objPocketMoney.TransactionType = radioButtonDebit.Text;
					}
					objPocketMoney.Amount = Convert.ToInt64(textBoxAmount.Text);
					double balanceAmount = PocketMoneyBL.GetBalanceAmount(objPocketMoney.Amount, objPocketMoney.TransactionType);
					if (balanceAmount < 50)
					{
						labelBalanceMessage.Text = "Sorry.. Can't add Transaction. Minimum Balance is 50.";
						labelInsertMessage.Text = "INSERTION FAILED";
					}
					else
					{
						objPocketMoney.BalanceAmount = balanceAmount;
						output = PocketMoneyBL.InsertTransactionDetails(objPocketMoney);

						if (output > 0)
						{
							labelInsertMessage.Text = "DATA ADDED SUCCESSFULLY";
						}
						else
						{
							labelInsertMessage.Text = "INSERTION FAILED";
						}
					}
				}
				catch (Exception ex)
				{
					labelInsertMessage.Text = ex.Message.ToString();
				}
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			this.Visible = false;
			PocketMoneyPLF objPL = new PocketMoneyPLF();
			objPL.Visible = true;
		}

		private void InsertForm_Load(object sender, EventArgs e)
		{
			comboBoxDescription.Items.Add("FOOD");
			comboBoxDescription.Items.Add("BANK");
			comboBoxDescription.Items.Add("SHOPPING");
			comboBoxDescription.Items.Add("RENT");
			comboBoxDescription.Items.Add("OTHERS");
			textBoxSlNo.Text= PocketMoneyBL.GetNewSlNo().ToString();
		}
	}
}
