﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PocketMoneyDTO.PocketMoneyDTObject;
using PocketMoneyDSL.PocketMoneyDSLayer;
using PocketMoneyDSL.Helper;
using System.Data;

namespace PocketMoneyBLL.PocketMoneyBLLayer
{
	public class PocketMoneyBL
	{
		public static int InsertTransactionDetails(PocketMoney objPocketMoney)
		{
			int output = 0;
			try
			{
				output = PocketMoneyDS.InsertTransactionDetails(objPocketMoney);
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine("Error : PocketMoneyBL : InsertTransactionDetails()" + ex.Message.ToString());
			}
			return output;
		}
		public static int UpdateTransactionDetails(PocketMoney objPocketMoney)
		{
			int output = 0;
			try
			{
				output = PocketMoneyDS.UpdateTransactionDetails(objPocketMoney);
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine("Error : PocketMoneyBL : UpdateTransactionDetails()" + ex.Message.ToString());
			}
			return output;
		}
		public static DataSet LoadTransactionSlNos()
		{
			DataSet dsTransactionNos = null;
			try
			{
				dsTransactionNos = PocketMoneyDS.LoadTransactionSlNos();
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine("Error : PocketMoneyBL : LoadTransactionSlNos()" + ex.Message.ToString());
			}
			return dsTransactionNos;
		}
		public static PocketMoney GetTransactionByNos(string slNo)
		{
			PocketMoney objPocketMoney = null;
			try
			{
				objPocketMoney = PocketMoneyDS.GetTransactionByNos(slNo);
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine(" Error : PocketMoneyBL : GetTransactionByNos() " + ex.Message.ToString());
			}
			return objPocketMoney;
		}
		public static int GetNewSlNo()
		{
			int lastSlNo = 0;
			int newSlNo = 0;
			try
			{
				lastSlNo = Convert.ToInt32(PocketMoneyDS.GetLastSlNo());
				if (lastSlNo != 0)
				{
					newSlNo = lastSlNo+1;
				}
				else
				{
					newSlNo = 101;
				}
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine("Error : PocketMoneyBL : GetNewSlNo() " + ex.Message.ToString());
			}
			return newSlNo;
		}
		public static double GetBalanceAmount(double amount,string type)
		{
			double balanceAmount = 0;
			try
			{
				balanceAmount = Convert.ToInt32(PocketMoneyDS.GetBalanceAmount());
				if (balanceAmount != 0)
				{
					if (type == "Credit")
					{
						balanceAmount = balanceAmount + amount;						
					}
					else
					{
						balanceAmount = balanceAmount - amount;
					}
				}
				else
				{
					if (type == "Credit")
					{
						balanceAmount = 5000 + amount;
					}
					else
					{
						balanceAmount = 5000 - amount;
					}
					
				}
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine("Error : PocketMoneyBL : GetNewSlNo() " + ex.Message.ToString());
			}
			return balanceAmount;
		}
		public static int DeleteTransactionDetails(int slNo)
		{
			int output = 0;
			try
			{
				output = PocketMoneyDS.DeleteTransactionDetails(slNo);
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine("Error : PocketMoneyBL : DeleteTransactionDetails()" + ex.Message.ToString());
			}
			return output;
		}
		public static DataSet GetTransactionLike(string category, string like)
		{
			DataSet dsPocketMoney = null;
			try
			{
				dsPocketMoney = PocketMoneyDS.GetTransactionLike(category, like);
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine(" Error : AddressBLL : GetAddressBookLike() " + ex.Message.ToString());
			}
			return dsPocketMoney;
		}
		public static DataSet GetTransactionDetails()
		{
			DataSet dsTransactions = null;
			try
			{
				dsTransactions = PocketMoneyDS.GetTransactionDetails();
			}
			catch (Exception ex)
			{
				Console.Out.WriteLine("Error : PocketMoneyBL : GetTransactionDetails()" + ex.Message.ToString());
			}
			return dsTransactions;
		}
	}

}
